/**
 * SDK-020: Export Subpaths Validation Test
 * 
 * Este test verifica que todos los subpaths documentados en package.json
 * estén correctamente exportados y sean importables.
 * 
 * Gate de regresión: Build output existe y tiene formato correcto
 */

import { describe, it, expect } from 'vitest';
import { existsSync } from 'fs';
import { resolve } from 'path';

// Path al directorio dist (desde la raíz del proyecto)
const distPath = resolve(process.cwd(), 'dist');
const hasBuiltArtifacts = existsSync(distPath);

describe.skipIf(!hasBuiltArtifacts)('SDK-020: Export Subpaths Documentation', () => {

  describe('CJS/ESM build artifacts exist', () => {
    it('should have Core builds (ESM + CJS + types)', () => {
      expect(existsSync(resolve(distPath, 'core/index.js'))).toBe(true);
      expect(existsSync(resolve(distPath, 'core/index.cjs'))).toBe(true);
      expect(existsSync(resolve(distPath, 'core/index.d.ts'))).toBe(true);
    });

    it('should have React builds (ESM + CJS + types)', () => {
      expect(existsSync(resolve(distPath, 'react/index.js'))).toBe(true);
      expect(existsSync(resolve(distPath, 'react/index.cjs'))).toBe(true);
      expect(existsSync(resolve(distPath, 'react/index.d.ts'))).toBe(true);
    });

    it('should have Server builds (ESM + CJS + types)', () => {
      expect(existsSync(resolve(distPath, 'server/index.js'))).toBe(true);
      expect(existsSync(resolve(distPath, 'server/index.cjs'))).toBe(true);
      expect(existsSync(resolve(distPath, 'server/index.d.ts'))).toBe(true);
    });

    it('should have Backend builds (ESM + CJS + types)', () => {
      expect(existsSync(resolve(distPath, 'backend/index.js'))).toBe(true);
      expect(existsSync(resolve(distPath, 'backend/index.cjs'))).toBe(true);
      expect(existsSync(resolve(distPath, 'backend/index.d.ts'))).toBe(true);
    });

    it('should have CLI build', () => {
      expect(existsSync(resolve(distPath, 'cli/cli.js'))).toBe(true);
    });
  });

  describe('package.json exports are configured', () => {
    it('should have all documented subpaths in package.json', () => {
      // Leer package.json directamente con fs
      const pkgPath = resolve(process.cwd(), 'package.json');
      const pkgContent = require('fs').readFileSync(pkgPath, 'utf8');
      const pkg = JSON.parse(pkgContent);
      
      // Verificar que existen los exports
      expect(pkg.exports).toBeDefined();
      expect(pkg.exports['.']).toBeDefined();
      expect(pkg.exports['./react']).toBeDefined();
      expect(pkg.exports['./server']).toBeDefined();
      expect(pkg.exports['./backend']).toBeDefined();
      
      // Verificar estructura correcta
      const subpaths = ['.', './react', './server', './backend'];
      for (const subpath of subpaths) {
        expect(pkg.exports[subpath].types).toBeDefined();
        expect(pkg.exports[subpath].import).toBeDefined();
        expect(pkg.exports[subpath].require).toBeDefined();
      }
    });

    it('should point to existing files in package.json exports', () => {
      // Leer package.json directamente con fs
      const pkgPath = resolve(process.cwd(), 'package.json');
      const pkgContent = require('fs').readFileSync(pkgPath, 'utf8');
      const pkg = JSON.parse(pkgContent);
      
      const subpaths = ['.', './react', './server', './backend'];
      for (const subpath of subpaths) {
        const config = pkg.exports[subpath];
        
        // Verificar que los archivos apuntados existen
        expect(existsSync(resolve(process.cwd(), config.types))).toBe(true);
        expect(existsSync(resolve(process.cwd(), config.import))).toBe(true);
        expect(existsSync(resolve(process.cwd(), config.require))).toBe(true);
      }
    });
  });
});
