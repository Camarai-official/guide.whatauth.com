import type { NextFunction, Request, RequestHandler, Response } from 'express';
import { createHmac, timingSafeEqual } from 'crypto';

export interface WebhookPayload {
  object: string;
  entry: Array<{
    id: string;
    changes: Array<{
      value: {
        messaging_product: string;
        metadata: {
          display_phone_number: string;
          phone_number_id: string;
        };
        contacts: Array<{
          profile: {
            name: string;
          };
          wa_id: string;
        }>;
        messages: Array<{
          from: string;
          id: string;
          timestamp: string;
          text: {
            body: string;
          };
          type: string;
        }>;
      };
      field: string;
    }>;
  }>;
}

interface WebhookRequest extends Request {
  rawBody?: Buffer;
}

export interface WebhookMiddlewareOptions {
  signatureHeader?: string;
  allowUnsigned?: boolean;
}

export class WebhookValidator {
  constructor(private appSecret: string) {}

  /**
   * Validates the X-Hub-Signature-256 header from WhatsApp.
   */
  validateSignature(payloadRawBody: string | Buffer, signature: string): boolean {
    if (!signature) {
      return false;
    }

    const normalizedSignature = signature.startsWith('sha256=')
      ? signature.slice('sha256='.length)
      : signature;

    if (!/^[a-f0-9]+$/i.test(normalizedSignature)) {
      return false;
    }

    const expected = createHmac('sha256', this.appSecret)
      .update(payloadRawBody)
      .digest('hex');

    const expectedBuffer = Buffer.from(expected, 'hex');
    const providedBuffer = Buffer.from(normalizedSignature, 'hex');

    if (expectedBuffer.length !== providedBuffer.length) {
      return false;
    }

    return timingSafeEqual(expectedBuffer, providedBuffer);
  }

  /**
   * Helper to parse the simplified message content from a payload.
   */
  parseMessage(payload: WebhookPayload): { from: string; text: string; id: string } | null {
    const message = payload.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
    if (message && message.type === 'text') {
      return {
        from: message.from,
        text: message.text.body,
        id: message.id
      };
    }

    return null;
  }
}

export function captureWebhookRawBody(req: Request, _res: Response, buffer: Buffer): void {
  (req as WebhookRequest).rawBody = Buffer.from(buffer);
}

/**
 * Express middleware factory for validating WhatsApp webhooks.
 * For deterministic validation, register express.json({ verify: captureWebhookRawBody }).
 */
export function createWebhookMiddleware(
  appSecret: string,
  options: WebhookMiddlewareOptions = {}
): RequestHandler {
  const validator = new WebhookValidator(appSecret);
  const signatureHeader = (options.signatureHeader || 'x-hub-signature-256').toLowerCase();
  const allowUnsigned = options.allowUnsigned ?? false;

  return (req: Request, res: Response, next: NextFunction) => {
    const headerValue = req.headers[signatureHeader];
    const signature = Array.isArray(headerValue) ? headerValue[0] : headerValue;

    if (!signature) {
      if (allowUnsigned) {
        return next();
      }

      return res.status(401).json({ success: false, error: 'Missing webhook signature' });
    }

    const rawBody = (req as WebhookRequest).rawBody;
    const payload = rawBody ?? Buffer.from(JSON.stringify(req.body ?? {}), 'utf8');

    if (!validator.validateSignature(payload, signature)) {
      return res.status(401).json({ success: false, error: 'Invalid webhook signature' });
    }

    return next();
  };
}
