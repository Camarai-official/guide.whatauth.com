import { createHmac } from 'crypto';
import { describe, expect, it } from 'vitest';
import { WebhookValidator } from './webhook-handler';

describe('WebhookValidator', () => {
  it('validates a correct sha256 signature', () => {
    const validator = new WebhookValidator('secret-key');
    const payload = JSON.stringify({ hello: 'world' });
    const hash = createHmac('sha256', 'secret-key').update(payload).digest('hex');

    const result = validator.validateSignature(payload, `sha256=${hash}`);

    expect(result).toBe(true);
  });

  it('rejects invalid signatures', () => {
    const validator = new WebhookValidator('secret-key');
    const payload = JSON.stringify({ hello: 'world' });

    const result = validator.validateSignature(payload, 'sha256=deadbeef');

    expect(result).toBe(false);
  });
});
