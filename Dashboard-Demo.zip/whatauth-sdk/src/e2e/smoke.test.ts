import { createServer } from 'net';
import { afterEach, describe, expect, it } from 'vitest';
import { CamarauthBackend } from '../backend/index';
import { encodePinToEmojis } from '../core/pin-generator';
import { CamarauthSocketClient } from '../core/socket-client';
import type { AuthResponse } from '../core/types';

async function getFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') {
        server.close();
        reject(new Error('No se pudo obtener puerto libre'));
        return;
      }

      server.close(() => resolve(address.port));
    });
  });
}

async function waitForHealth(baseUrl: string): Promise<void> {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) {
        return;
      }
    } catch {
      // Retry until backend is up.
    }

    await new Promise(resolve => setTimeout(resolve, 50));
  }

  throw new Error('Backend no inicio a tiempo');
}

const startedBackends: CamarauthBackend[] = [];

afterEach(async () => {
  while (startedBackends.length > 0) {
    const backend = startedBackends.pop();
    if (backend) {
      await backend.stop();
    }
  }
});

describe('SDK-009 smoke e2e', () => {
  it('completes happy path backend + frontend socket flow', async () => {
    const port = await getFreePort();
    const baseUrl = `http://127.0.0.1:${port}`;

    const backend = new CamarauthBackend({
      port,
      host: '127.0.0.1',
      jwtSecret: 'sdk-009-jwt-secret',
      evolutionApiUrl: 'https://example.com',
      evolutionApiKey: 'test-api-key',
      evolutionInstanceName: 'test-instance',
      rateLimit: { enabled: false }
    });

    startedBackends.push(backend);
    backend.start();
    await waitForHealth(baseUrl);

    const socketClient = new CamarauthSocketClient({ apiUrl: baseUrl });

    const authSuccessPromise = new Promise<AuthResponse>((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('No llego auth-success en el tiempo esperado'));
      }, 6000);

      socketClient.setCallbacks({
        onSuccess: (response) => {
          clearTimeout(timeout);
          resolve(response);
        },
        onError: (error) => {
          clearTimeout(timeout);
          reject(error);
        }
      });
    });

    await socketClient.connect();

    const pin = 'ABC123';
    const emojiString = encodePinToEmojis(pin).join('');

    await socketClient.registerPin(pin, emojiString);

    const pendingResponse = await fetch(`${baseUrl}/check-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin })
    });

    const pendingBody = await pendingResponse.json();
    expect(pendingResponse.status).toBe(200);
    expect(pendingBody.verified).toBe(false);

    const webhookPayload = {
      event: 'messages.upsert',
      instance: 'test-instance',
      data: {
        key: {
          remoteJid: '34600000000@s.whatsapp.net',
          fromMe: false,
          id: 'msg-e2e-1'
        },
        pushName: 'SDK Smoke User',
        message: {
          conversation: `PIN: ${emojiString}`
        }
      }
    };

    const webhookResponse = await fetch(`${baseUrl}/webhook/evolution`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(webhookPayload)
    });

    expect(webhookResponse.status).toBe(200);

    const authResponse = await authSuccessPromise;

    expect(authResponse.success).toBe(true);
    expect(authResponse.verified).toBe(true);
    expect(typeof authResponse.token).toBe('string');
    expect(typeof authResponse.refreshToken).toBe('string');
    expect(authResponse.user?.id).toBeDefined();

    const verifiedResponse = await fetch(`${baseUrl}/check-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin })
    });

    const verifiedBody = await verifiedResponse.json();
    expect(verifiedResponse.status).toBe(200);
    expect(verifiedBody.verified).toBe(true);

    const refreshResponse = await socketClient.refreshToken(authResponse.refreshToken!);
    expect(typeof refreshResponse.token).toBe('string');

    const logoutResponse = await socketClient.logout(authResponse.token!, String(authResponse.user?.id));
    expect(logoutResponse.success).toBe(true);

    socketClient.disconnect();
  });
});
