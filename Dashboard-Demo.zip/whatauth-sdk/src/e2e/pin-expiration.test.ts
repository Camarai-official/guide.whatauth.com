/**
 * SDK-031: Test de expiración con tiempo controlado
 * 
 * Este test usa FakeTimeProvider para simular el paso del tiempo
 * sin esperar tiempo real.
 */

import { describe, it, expect, vi } from 'vitest';
import { createServer } from 'net';
import { CamarauthBackend, FakeTimeProvider } from '../backend/index';
import { encodePinToEmojis } from '../core/pin-generator';

async function getFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') {
        server.close();
        reject(new Error('No se pudo obtener puerto libre'));
        return;
      }
      server.close(() => resolve(address.port));
    });
  });
}

async function waitForHealth(baseUrl: string): Promise<void> {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) return;
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('Backend no inicio a tiempo');
}

describe('SDK-031: PIN Expiration with FakeTimeProvider', () => {
  it('should handle expired PIN correctly with fake timers', async () => {
    const port = await getFreePort();
    const timeProvider = new FakeTimeProvider(Date.now());
    
    const backend = new CamarauthBackend({
      port,
      host: '127.0.0.1',
      jwtSecret: 'test-secret',
      evolutionApiUrl: 'https://example.com',
      evolutionApiKey: 'test-api-key',
      evolutionInstanceName: 'test-instance',
      rateLimit: { enabled: false },
      pinExpirationMinutes: 1, // 1 minuto = 60000ms
      timeProvider
    });

    backend.start();
    const baseUrl = `http://127.0.0.1:${port}`;
    await waitForHealth(baseUrl);

    try {
      const pin = 'EXP01';
      const emojiString = encodePinToEmojis(pin).join('');

      // Registrar PIN
      await fetch(`${baseUrl}/register-pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });

      // Verificar que el PIN está pendiente
      const pendingCheck = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      expect((await pendingCheck.json()).verified).toBe(false);

      // Avanzar tiempo 2 minutos (más del tiempo de expiración)
      timeProvider.advance(2 * 60 * 1000);

      // Intentar verificar - debería fallar por expiración
      const expiredCheck = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      
      expect(expiredCheck.status).toBe(410); // Gone - PIN expirado
      const body = await expiredCheck.json();
      expect(body.code).toBe('PIN_EXPIRED');
    } finally {
      await backend.stop();
    }
  }, 10000);

  it('should verify PIN before expiration', async () => {
    const port = await getFreePort();
    const timeProvider = new FakeTimeProvider(Date.now());
    
    const backend = new CamarauthBackend({
      port,
      host: '127.0.0.1',
      jwtSecret: 'test-secret',
      evolutionApiUrl: 'https://example.com',
      evolutionApiKey: 'test-api-key',
      evolutionInstanceName: 'test-instance',
      rateLimit: { enabled: false },
      pinExpirationMinutes: 5, // 5 minutos
      timeProvider
    });

    backend.start();
    const baseUrl = `http://127.0.0.1:${port}`;
    await waitForHealth(baseUrl);

    try {
      const pin = 'EXP02';
      const emojiString = encodePinToEmojis(pin).join('');

      // Registrar PIN
      await fetch(`${baseUrl}/register-pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });

      // Avanzar tiempo 2 minutos (dentro del tiempo de expiración)
      timeProvider.advance(2 * 60 * 1000);

      // Verificar con webhook - debería funcionar
      await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'test-instance',
          data: {
            key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-exp' },
            pushName: 'Test User',
            message: { conversation: `PIN: ${emojiString}` }
          }
        })
      });

      // Verificar que el PIN está verificado
      const verifiedCheck = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      
      expect(verifiedCheck.status).toBe(200);
      const body = await verifiedCheck.json();
      expect(body.verified).toBe(true);
    } finally {
      await backend.stop();
    }
  }, 10000);
});
