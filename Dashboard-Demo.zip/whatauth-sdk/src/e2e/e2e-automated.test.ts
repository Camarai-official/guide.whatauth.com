/**
 * SDK-026: E2E Tests Automatizados
 * 
 * Tests end-to-end completos para validar flujos de usuario reales.
 * 
 * Escenarios:
 * - Happy path completo
 * - PIN expirado
 * - Error de webhook
 * - Cancelación de autenticación
 * - Múltiples usuarios simultáneos
 * - Regeneración de PIN
 */

import { createServer } from 'net';
import { afterEach, describe, expect, it } from 'vitest';
import { CamarauthBackend } from '../backend/index';
import { encodePinToEmojis } from '../core/pin-generator';
import { CamarauthSocketClient } from '../core/socket-client';
import type { AuthResponse } from '../core/types';

// Utilidades compartidas
async function getFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') {
        server.close();
        reject(new Error('No se pudo obtener puerto libre'));
        return;
      }
      server.close(() => resolve(address.port));
    });
  });
}

async function waitForHealth(baseUrl: string): Promise<void> {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) return;
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('Backend no inicio a tiempo');
}

interface TestContext {
  backend: CamarauthBackend;
  baseUrl: string;
}

async function setupTestBackend(): Promise<TestContext> {
  const port = await getFreePort();
  const backend = new CamarauthBackend({
    port,
    host: '127.0.0.1',
    jwtSecret: 'e2e-test-secret-' + Date.now(),
    evolutionApiUrl: 'https://example.com',
    evolutionApiKey: 'test-api-key',
    evolutionInstanceName: 'test-instance',
    rateLimit: { enabled: false },
    pinExpirationMinutes: 1 // 1 minuto para tests de expiración
  });

  backend.start();
  const baseUrl = `http://127.0.0.1:${port}`;
  await waitForHealth(baseUrl);

  return { backend, baseUrl };
}

const startedBackends: CamarauthBackend[] = [];

afterEach(async () => {
  while (startedBackends.length > 0) {
    const backend = startedBackends.pop();
    if (backend) await backend.stop();
  }
});

describe('SDK-026: E2E Automated Tests', () => {
  describe('Happy Path', () => {
    it('should complete full authentication flow', async () => {
      const { baseUrl } = await setupTestBackend();
      const client = new CamarauthSocketClient({ apiUrl: baseUrl });
      const pin = 'HAPPY1';
      const emojiString = encodePinToEmojis(pin).join('');

      // Setup auth promise
      const authPromise = new Promise<AuthResponse>((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error('Auth timeout')), 5000);
        client.setCallbacks({
          onSuccess: (response) => {
            clearTimeout(timeout);
            resolve(response);
          },
          onError: (error) => {
            clearTimeout(timeout);
            reject(error);
          }
        });
      });

      await client.connect();
      await client.registerPin(pin, emojiString);

      // Simular webhook de verificación
      await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'test-instance',
          data: {
            key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-1' },
            pushName: 'Test User',
            message: { conversation: `PIN: ${emojiString}` }
          }
        })
      });

      const auth = await authPromise;

      expect(auth.success).toBe(true);
      expect(auth.verified).toBe(true);
      expect(auth.token).toBeTruthy();
      expect(auth.refreshToken).toBeTruthy();
      expect(auth.user).toMatchObject({
        id: expect.any(String),
        nombre: expect.any(String),
        telefono: expect.any(String),
        roles: expect.arrayContaining([expect.any(String)])
      });

      // Verificar que el PIN está verificado vía HTTP
      const checkResponse = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      const checkBody = await checkResponse.json();
      expect(checkBody.verified).toBe(true);

      // Refresh token
      const refresh = await client.refreshToken(auth.refreshToken!);
      expect(refresh.token).toBeTruthy();

      // Logout
      const logout = await client.logout(auth.token!, auth.user!.id);
      expect(logout.success).toBe(true);

      client.disconnect();
    });
  });

  describe('PIN Expiration', () => {
    it.skip('should handle expired PIN correctly [MANUAL ONLY]', async () => {
      // Este test requiere tiempo de expiración real (1 minuto)
      // Se salta en CI - usar pin-expiration.test.ts para tests automatizados
      const { baseUrl } = await setupTestBackend();
      const client = new CamarauthSocketClient({ apiUrl: baseUrl });
      const pin = 'EXP01';
      const emojiString = encodePinToEmojis(pin).join('');

      let expiredReceived = false;
      client.setCallbacks({
        onExpired: () => { expiredReceived = true; }
      });

      await client.connect();
      await client.registerPin(pin, emojiString);

      // Verificar que el PIN está pendiente
      const pendingCheck = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      expect((await pendingCheck.json()).verified).toBe(false);

      // Esperar a que expire (1 minuto configurado en setup)
      await new Promise(resolve => setTimeout(resolve, 65000));

      // Intentar verificar con webhook - debería fallar por expiración
      await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'test-instance',
          data: {
            key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-exp' },
            pushName: 'Expired User',
            message: { conversation: `PIN: ${emojiString}` }
          }
        })
      });

      // El PIN expirado no debería estar verificado
      const expiredCheck = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      expect(expiredCheck.status).toBe(404);

      client.disconnect();
    });
  });

  describe('Webhook Errors', () => {
    it('should handle webhook from different instance', async () => {
      const { baseUrl } = await setupTestBackend();
      const pin = 'INST01';
      const emojiString = encodePinToEmojis(pin).join('');

      // Registrar PIN
      await fetch(`${baseUrl}/register-pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });

      // Webhook de instancia diferente - debería ser ignorado pero retornar 200
      const response = await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'different-instance',
          data: {
            key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-wrong' },
            pushName: 'Wrong Instance',
            message: { conversation: `PIN: ${emojiString}` }
          }
        })
      });

      expect(response.status).toBe(200);

      // Verificar que el PIN sigue pendiente
      const checkResponse = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      const checkBody = await checkResponse.json();
      expect(checkBody.verified).toBe(false);
    });

    it('should handle messages without PIN format', async () => {
      const { baseUrl } = await setupTestBackend();

      const response = await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'test-instance',
          data: {
            key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-normal' },
            pushName: 'Normal User',
            message: { conversation: 'Hello, just a regular message' }
          }
        })
      });

      expect(response.status).toBe(200);
    });
  });

  describe('Auth Cancellation', () => {
    it('should allow cancelling pending authentication', async () => {
      const { baseUrl } = await setupTestBackend();
      const client = new CamarauthSocketClient({ apiUrl: baseUrl });
      const pin = 'CANCEL1';
      const emojiString = encodePinToEmojis(pin).join('');

      await client.connect();
      await client.registerPin(pin, emojiString);

      // Verificar PIN existe
      const beforeCancel = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      expect(beforeCancel.status).toBe(200);

      // Cancelar
      client.cancelAuth(pin);
      await new Promise(resolve => setTimeout(resolve, 100));

      // Verificar PIN fue eliminado
      const afterCancel = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      expect(afterCancel.status).toBe(404);

      client.disconnect();
    });
  });

  describe('Multiple Concurrent Users', () => {
    it('should handle multiple simultaneous authentications', async () => {
      const { baseUrl } = await setupTestBackend();
      const users = [
        { pin: 'MULTI1', phone: '34600111111', name: 'User One' },
        { pin: 'MULTI2', phone: '34600222222', name: 'User Two' },
        { pin: 'MULTI3', phone: '34600333333', name: 'User Three' }
      ];

      // Registrar todos los PINs
      for (const user of users) {
        await fetch(`${baseUrl}/register-pin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: user.pin })
        });
      }

      // Verificar todos pendientes
      for (const user of users) {
        const check = await fetch(`${baseUrl}/check-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: user.pin })
        });
        expect((await check.json()).verified).toBe(false);
      }

      // Verificar usuarios simultáneamente
      await Promise.all(users.map(async (user) => {
        const emojiString = encodePinToEmojis(user.pin).join('');
        
        await fetch(`${baseUrl}/webhook/evolution`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'messages.upsert',
            instance: 'test-instance',
            data: {
              key: { remoteJid: `${user.phone}@s.whatsapp.net`, fromMe: false, id: `msg-${user.pin}` },
              pushName: user.name,
              message: { conversation: `PIN: ${emojiString}` }
            }
          })
        });
      }));

      // Verificar todos verificados
      for (const user of users) {
        const check = await fetch(`${baseUrl}/check-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: user.pin })
        });
        const body = await check.json();
        expect(body.verified).toBe(true);
        expect(body.user.nombre).toBe(user.name);
      }
    });
  });

  describe('PIN Regeneration', () => {
    it('should allow regenerating PIN after cancellation', async () => {
      const { baseUrl } = await setupTestBackend();
      const client = new CamarauthSocketClient({ apiUrl: baseUrl });

      await client.connect();

      // Primer PIN
      const pin1 = 'REGEN1';
      await client.registerPin(pin1, encodePinToEmojis(pin1).join(''));
      
      // Cancelar
      client.cancelAuth(pin1);
      await new Promise(resolve => setTimeout(resolve, 50));

      // Segundo PIN (regeneración)
      const pin2 = 'REGEN2';
      await client.registerPin(pin2, encodePinToEmojis(pin2).join(''));

      // Verificar primer PIN ya no existe
      const check1 = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: pin1 })
      });
      expect(check1.status).toBe(404);

      // Verificar segundo PIN existe
      const check2 = await fetch(`${baseUrl}/check-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: pin2 })
      });
      expect(check2.status).toBe(200);

      client.disconnect();
    });
  });

  describe('Profile and Session Management', () => {
    it('should manage user profile and session lifecycle', async () => {
      const { baseUrl } = await setupTestBackend();
      const client = new CamarauthSocketClient({ apiUrl: baseUrl });
      const pin = 'SESS01';
      const emojiString = encodePinToEmojis(pin).join('');

      const authPromise = new Promise<AuthResponse>((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error('Timeout')), 5000);
        client.setCallbacks({
          onSuccess: (response) => {
            clearTimeout(timeout);
            resolve(response);
          },
          onError: (error) => {
            clearTimeout(timeout);
            reject(error);
          }
        });
      });

      await client.connect();
      await client.registerPin(pin, emojiString);

      await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'test-instance',
          data: {
            key: { remoteJid: '34600444444@s.whatsapp.net', fromMe: false, id: 'msg-sess' },
            pushName: 'Session Test',
            message: { conversation: `PIN: ${emojiString}` }
          }
        })
      });

      const auth = await authPromise;

      // Obtener perfil
      const profileResponse = await fetch(`${baseUrl}/profile`, {
        headers: { Authorization: `Bearer ${auth.token}` }
      });
      const profile = await profileResponse.json();
      expect(profile.success).toBe(true);
      expect(profile.user.id).toBe(auth.user!.id);

      // Refresh token
      const refresh1 = await client.refreshToken(auth.refreshToken!);
      expect(refresh1.token).toBeTruthy();

      // Segundo refresh con el mismo refreshToken
      const refresh2 = await client.refreshToken(auth.refreshToken!);
      expect(refresh2.token).toBeTruthy();

      // Logout
      const logout = await client.logout(auth.token!, auth.user!.id);
      expect(logout.success).toBe(true);

      // Intentar usar token después de logout (opcional, depende de implementación)
      // const afterLogout = await fetch(`${baseUrl}/profile`, {
      //   headers: { Authorization: `Bearer ${auth.token}` }
      // });
      // expect(afterLogout.status).toBe(401);

      client.disconnect();
    });
  });
});

// Exportar utilidades para otros tests E2E
export { getFreePort, waitForHealth, setupTestBackend };
