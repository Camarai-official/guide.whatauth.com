import { useState, useEffect, useCallback } from 'react'
import { AuthContext } from './AuthContext'
import { AuthProviderProps } from '../types'
import {
  type AuthState, 
  type User,
  type AuthContextValue,
  WhatauthError,
  WhatauthSocketClient,
  createAuthStorage,
  getUserFromToken,
  isTokenExpired
} from '../../core'

// Development-only console
const devConsole = {
  log: process.env.NODE_ENV === 'development' ? console.log : () => {},
  warn: process.env.NODE_ENV === 'development' ? console.warn : () => {},
  error: process.env.NODE_ENV === 'development' ? console.error : () => {},
  info: process.env.NODE_ENV === 'development' ? console.info : () => {},
  debug: process.env.NODE_ENV === 'development' ? console.debug : () => {},
}

export function AuthProvider({ 
  apiUrl, 
  storage: storageOptions,
  children 
}: AuthProviderProps) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null
  })

  // Initialize socket client and storage
  const [socketClient] = useState(() => new WhatauthSocketClient({ apiUrl }))
  const [storage] = useState(() => createAuthStorage(storageOptions))

  useEffect(() => {
    // Socket connection disabled - using WhatauthWorkerClient instead
    // Connect socket on mount
    // let isCancelled = false
    
    // const connectSocket = async () => {
    //   try {
    //     await socketClient.connect()
    //   } catch (error) {
    //     if (!isCancelled) {
    //       console.error('Failed to connect socket:', error)
    //     }
    //   }
    // }
    
    // connectSocket()
    
    // return () => {
    //   isCancelled = true
    //   socketClient.disconnect()
    // }
  }, [socketClient])

  useEffect(() => {
    const restoreSession = async () => {
      try {
        const data = await storage.load()
        
        if (data?.token) {
          if (isTokenExpired(data.token)) {
            // Token expired - clear session since we can't refresh without Socket.IO
            await storage.clear()
            setState({
              user: null,
              isAuthenticated: false,
              isLoading: false,
              error: null
            })
          } else {
            // Valid token - restore session
            setState({
              user: data.user,
              isAuthenticated: true,
              isLoading: false,
              error: null
            })
          }
        } else {
          setState({
            user: null,
            isAuthenticated: false,
            isLoading: false,
            error: null
          })
        }
      } catch (error) {
        setState({
          user: null,
          isAuthenticated: false,
          isLoading: false,
          error: error instanceof WhatauthError ? error : new WhatauthError(error instanceof Error ? error.message : 'Session restore failed', 'SESSION_RESTORE_FAILED')
        })
      }
    }

    restoreSession()
  }, [socketClient, storage])

  const login = useCallback(async (user: User) => {
    setState({
      user,
      isAuthenticated: true,
      isLoading: false,
      error: null
    })
  }, [])

  const logout = useCallback(async () => {
    setState(prev => ({ ...prev, isLoading: true }))
    
    try {
      // Socket logout disabled - using WhatauthWorkerClient instead
      // if (state.user?.id) {
      //   const data = await storage.load();
      //   if (data?.token) {
      //     await socketClient.logout(data.token, state.user.id)
      //   }
      // }
    } catch (error) {
    } finally {
      await storage.clear()
      setState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null
      })
    }
  }, [/* socketClient, */ storage, state.user?.id])

  const setLoading = useCallback((loading: boolean) => {
    setState(prev => ({ ...prev, isLoading: loading }))
  }, [])

  const setError = useCallback((error: WhatauthError | null) => {
    setState(prev => ({ ...prev, error }))
  }, [])

  const contextValue: AuthContextValue = {
    ...state,
    login,
    logout,
    setLoading,
    setError
  }

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  )
}
