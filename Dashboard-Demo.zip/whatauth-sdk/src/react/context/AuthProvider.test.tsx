// @vitest-environment jsdom

import { render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { AuthProvider } from './AuthProvider';
import { useAuthContext } from './AuthContext';

const connectMock = vi.fn();
const disconnectMock = vi.fn();
const refreshTokenMock = vi.fn();
const logoutMock = vi.fn();
const saveMock = vi.fn();
const loadMock = vi.fn();
const clearMock = vi.fn();

vi.mock('../../core', () => {
  class CamarauthError extends Error {
    code: string;

    constructor(message: string, code: string) {
      super(message);
      this.code = code;
    }
  }

  class CamarauthSocketClient {
    connect() {
      connectMock();
      return Promise.resolve();
    }

    disconnect() {
      disconnectMock();
    }

    refreshToken(refreshToken: string) {
      return refreshTokenMock(refreshToken);
    }

    logout(accessToken: string, userId: string) {
      return logoutMock(accessToken, userId);
    }
  }

  return {
    CamarauthError,
    CamarauthSocketClient,
    createAuthStorage: () => ({
      load: loadMock,
      save: saveMock,
      clear: clearMock,
      exists: vi.fn().mockResolvedValue(false),
      getKey: vi.fn().mockReturnValue('camarauth_token')
    }),
    getUserFromToken: () => ({ id: 'user-1', name: 'Refreshed User' }),
    isTokenExpired: () => true
  };
});

function AuthStateProbe() {
  const auth = useAuthContext();

  return (
    <div data-testid="auth-state">
      {auth.isLoading ? 'loading' : auth.isAuthenticated ? 'authenticated' : 'anonymous'}
    </div>
  );
}

describe('AuthProvider refresh flow', () => {
  beforeEach(() => {
    connectMock.mockReset();
    disconnectMock.mockReset();
    refreshTokenMock.mockReset();
    logoutMock.mockReset();
    saveMock.mockReset();
    loadMock.mockReset();
    clearMock.mockReset();
  });

  it('refreshes session using refreshToken from storage', async () => {
    loadMock.mockResolvedValue({
      token: 'expired-access-token',
      refreshToken: 'refresh-token-123',
      user: { id: 'user-1', name: 'Old User' }
    });

    refreshTokenMock.mockResolvedValue({
      token: 'new-access-token',
      refreshToken: 'refresh-token-456'
    });

    render(
      <AuthProvider apiUrl="http://localhost:3001">
        <AuthStateProbe />
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.getByTestId('auth-state').textContent).toBe('authenticated');
    });

    expect(refreshTokenMock).toHaveBeenCalledWith('refresh-token-123');
    expect(saveMock).toHaveBeenCalledWith({
      token: 'new-access-token',
      refreshToken: 'refresh-token-456',
      user: { id: 'user-1', name: 'Refreshed User' }
    });
  });
});
