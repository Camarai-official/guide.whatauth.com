import type { ReactNode } from 'react'
import type { AuthStorageOptions } from '../core'

export interface AuthProviderProps {
  apiUrl: string
  storage?: AuthStorageOptions
  children: ReactNode
}
