import { WHATSAPP_BASE_URL, WHATSAPP_MESSAGE_PREFIX } from '../../core'

export function useWhatsAppLink(phoneNumber: string) {
  const generateLink = (message?: string): string => {
    const cleanNumber = phoneNumber.replace(/[\+\s]/g, '')
    let url = `${WHATSAPP_BASE_URL}/${cleanNumber}`
    if (message) {
      const encodedMessage = encodeURIComponent(message)
      url += `?text=${encodedMessage}`
    }
    return url
  }

  const generatePinLink = (_pin: string, emojis: string[]): string => {
    const message = `${WHATSAPP_MESSAGE_PREFIX}${emojis.join('')}`
    return generateLink(message)
  }

  return {
    generateLink,
    generatePinLink
  }
}
