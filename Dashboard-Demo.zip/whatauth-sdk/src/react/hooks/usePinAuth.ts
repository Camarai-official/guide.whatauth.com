import { useState, useCallback, useEffect, useRef } from 'react'
import { 
  type PinAuthOptions, 
  type PinAuthState, 
  type PinGenerationResult, 
  type AuthResponse,
  WhatauthError, 
  DEFAULT_PIN_LENGTH, 
  DEFAULT_COUNTDOWN_SECONDS, 
  DEFAULT_MAX_REGENERATIONS,
  WHATSAPP_MESSAGE_PREFIX,
  WhatauthSocketClient,
  createAuthStorage,
  getUserFromToken,
  generateAuthLink
} from '../../core'

import { useCountdown } from './useCountdown'
import { useAutoRegeneration } from './useAutoRegeneration'
import { usePinGenerator } from './usePinGenerator'

// Development-only console
const devConsole = {
  log: process.env.NODE_ENV === 'development' ? console.log : () => {},
  warn: process.env.NODE_ENV === 'development' ? console.warn : () => {},
  error: process.env.NODE_ENV === 'development' ? console.error : () => {},
  info: process.env.NODE_ENV === 'development' ? console.info : () => {},
  debug: process.env.NODE_ENV === 'development' ? console.debug : () => {},
}

export function usePinAuth(options: PinAuthOptions): PinAuthState {
  const {
    apiUrl,
    whatsappNumber,
    pinLength = DEFAULT_PIN_LENGTH,
    expiresIn = DEFAULT_COUNTDOWN_SECONDS,
    maxAutoRegenerations = DEFAULT_MAX_REGENERATIONS,
    autoGenerate = false,
    messagePrefix = WHATSAPP_MESSAGE_PREFIX,
    onPinGenerated,
    onSuccess,
    onError,
    onExpire,
    onMaxRegenerationsReached
  } = options

  const [status, setStatus] = useState<PinAuthState['status']>('idle')
  const [user, setUser] = useState<PinAuthState['user']>(null)
  const [error, setError] = useState<PinAuthState['error']>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [whatsappLink, setWhatsappLink] = useState('')
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null)
  const [fullMessage, setFullMessage] = useState('')

  // Use refs for socket client and storage - NUNCA recrear
  const socketClientRef = useRef<WhatauthSocketClient | null>(null)
  const storageRef = useRef<ReturnType<typeof createAuthStorage> | null>(null)
  const onExpireRef = useRef<(() => void) | undefined>(undefined)
  const currentPinRef = useRef<string | null>(null)
  const isMountedRef = useRef(false)
  const callbacksRef = useRef({ onSuccess, onError, onExpire, onPinGenerated })

  // Actualizar callbacks sin causar re-render
  useEffect(() => {
    callbacksRef.current = { onSuccess, onError, onExpire, onPinGenerated }
  }, [onSuccess, onError, onExpire, onPinGenerated])

  const { 
    pin, 
    emojis, 
    emojiString, 
    regenerate: regeneratePin 
  } = usePinGenerator({ length: pinLength })

  const {
    timeLeft,
    formattedTime,
    isExpired,
    start: startCountdown,
    restart: restartCountdown,
    stop: stopCountdown
  } = useCountdown({
    seconds: expiresIn,
    autoStart: false,
    onExpire: useCallback(() => onExpireRef.current?.(), [])
  })

  const {
    count: regenerationCount,
    hasReachedMax: hasReachedMaxRegenerations,
    increment: incrementRegeneration,
    reset: resetRegenerations
  } = useAutoRegeneration({
    maxRegenerations: maxAutoRegenerations,
    onMaxReached: onMaxRegenerationsReached
  })

  // Initialize socket client y storage SOLO UNA VEZ
  useEffect(() => {
    if (isMountedRef.current) return
    isMountedRef.current = true

    // Crear storage
    storageRef.current = createAuthStorage()
    
    // Crear socket client
    socketClientRef.current = new WhatauthSocketClient({ apiUrl })
    
    // Set callbacks que usan refs para evitar recreaciones
    socketClientRef.current.setCallbacks({
      onSuccess: async (response: AuthResponse) => {
        if (response.verified && response.token) {
          stopCountdown()
          
          const userData = getUserFromToken(response.token)
          if (userData) {
            setUser(userData)
            setStatus('success')
            
            await storageRef.current?.save({
              token: response.token,
              refreshToken: response.refreshToken,
              user: userData
            })
            callbacksRef.current.onSuccess?.(userData)
          }
        }
      },
      onError: (err: Error) => {
        const error = err instanceof WhatauthError 
          ? err 
          : new WhatauthError(err.message, 'SOCKET_ERROR')
        setError(error)
        setStatus('error')
        callbacksRef.current.onError?.(error)
      },
      onExpired: () => {
        setStatus('expired')
        callbacksRef.current.onExpire?.()
      }
    })

    // Connect in background
    setIsConnecting(true)
    socketClientRef.current.connect()
      .then(() => {
      })
      .catch((err) => {
      })
      .finally(() => {
        setIsConnecting(false)
      })

    // Cleanup solo al desmontar completamente
    return () => {
      if (socketClientRef.current) {
        socketClientRef.current.disconnect()
        socketClientRef.current = null
      }
      isMountedRef.current = false
    }
  }, [apiUrl]) // Solo apiUrl como dependencia

  const generate = useCallback(async () => {
    if (!socketClientRef.current) {
      return
    }

    if (!whatsappNumber) {
      setError(new WhatauthError('whatsappNumber es requerido', 'CONFIG_ERROR'))
      setStatus('error')
      return
    }

    setIsLoading(true)
    setError(null)
    
    try {
      // Verificar conexión con timeout corto
      if (!socketClientRef.current.isConnected()) {
        try {
          await Promise.race([
            socketClientRef.current.connect(),
            new Promise((_, reject) => 
              setTimeout(() => reject(new Error('Connection timeout')), 3000)
            )
          ])
        } catch (connError) {
          // Intentar una vez más
          await socketClientRef.current.connect()
        }
      }

      const newResult = regeneratePin()
      const newPin = newResult.pin
      const newEmojiString = newResult.emojiString
      const previousPin = currentPinRef.current

      if (previousPin) {
        socketClientRef.current.cancelAuth(previousPin)
      }
      
      currentPinRef.current = newPin
      
      // Generar link de WhatsApp y QR solo si hay whatsappNumber
      if (whatsappNumber) {
        const authLink = generateAuthLink(whatsappNumber, newEmojiString, {
          prefix: messagePrefix,
          includeQR: true,
          qrSize: 300
        })
        
        setWhatsappLink(authLink.whatsappLink)
        setQrCodeUrl(authLink.qrCodeUrl)
        setFullMessage(authLink.fullMessage)
      }
      
      restartCountdown(expiresIn)
      resetRegenerations()
      
      await socketClientRef.current.registerPin(newPin, newEmojiString)
      
      setStatus('polling')
      callbacksRef.current.onPinGenerated?.(newPin, newResult.emojis)
      
      startCountdown()
    } catch (err) {
      const error = err instanceof WhatauthError 
        ? err 
        : new WhatauthError(
            err instanceof Error ? err.message : 'Failed to generate PIN', 
            'PIN_GENERATION_FAILED'
          )
      setError(error)
      setStatus('error')
      callbacksRef.current.onError?.(error)
    } finally {
      setIsLoading(false)
    }
  }, [regeneratePin, restartCountdown, startCountdown, expiresIn, resetRegenerations, whatsappNumber, messagePrefix])

  const regenerate = useCallback((): PinGenerationResult | null => {
    if (hasReachedMaxRegenerations || !socketClientRef.current) {
      return null
    }

    const success = incrementRegeneration()
    if (!success) return null

    const newResult = regeneratePin()
    const newPin = newResult.pin
    const newEmojiString = newResult.emojiString
    const previousPin = currentPinRef.current

    if (previousPin) {
      socketClientRef.current.cancelAuth(previousPin)
    }
    
    currentPinRef.current = newPin
    
    // Actualizar links solo si hay whatsappNumber
    if (whatsappNumber) {
      const authLink = generateAuthLink(whatsappNumber, newEmojiString, {
        prefix: messagePrefix,
        includeQR: true,
        qrSize: 300
      })
      
      setWhatsappLink(authLink.whatsappLink)
      setQrCodeUrl(authLink.qrCodeUrl)
      setFullMessage(authLink.fullMessage)
    }
    
    restartCountdown(expiresIn)
    
    socketClientRef.current
      .registerPin(newPin, newEmojiString)
      .catch(() => {})
    
    callbacksRef.current.onPinGenerated?.(newPin, newResult.emojis)
    
    startCountdown()
    
    return newResult
  }, [hasReachedMaxRegenerations, incrementRegeneration, regeneratePin, restartCountdown, startCountdown, expiresIn, whatsappNumber, messagePrefix])

  const handleExpire = useCallback(() => {
    if (!hasReachedMaxRegenerations) {
      const result = regenerate()
      if (!result) { 
        setStatus('expired')
        callbacksRef.current.onExpire?.()
      }
    } else {
      setStatus('expired')
      callbacksRef.current.onExpire?.()
    }
  }, [hasReachedMaxRegenerations, regenerate])

  useEffect(() => {
    onExpireRef.current = handleExpire
  }, [handleExpire])

  const cancel = useCallback(() => {
    if (currentPinRef.current && socketClientRef.current) {
      socketClientRef.current.cancelAuth(currentPinRef.current)
    }
    stopCountdown()
    setStatus('idle')
    setError(null)
    setWhatsappLink('')
    setQrCodeUrl(null)
    setFullMessage('')
    currentPinRef.current = null
  }, [stopCountdown])

  const reset = useCallback(() => {
    if (currentPinRef.current && socketClientRef.current) {
      socketClientRef.current.cancelAuth(currentPinRef.current)
    }
    stopCountdown()
    resetRegenerations()
    setStatus('idle')
    setUser(null)
    setError(null)
    setIsLoading(false)
    setWhatsappLink('')
    setQrCodeUrl(null)
    setFullMessage('')
    currentPinRef.current = null
  }, [stopCountdown, resetRegenerations])

  useEffect(() => {
    if (autoGenerate && !isConnecting && socketClientRef.current?.isConnected()) {
      generate()
    }
  }, [autoGenerate, isConnecting, generate])

  return {
    pin,
    emojis,
    emojiString,
    timeLeft,
    formattedTime,
    isExpired,
    regenerationCount,
    hasReachedMaxRegenerations,
    status,
    isLoading: isLoading || isConnecting,
    user,
    error,
    whatsappLink,
    qrCodeUrl,
    fullMessage,
    generate,
    cancel,
    reset
  }
}
