import { useState, useCallback } from 'react'
import type { 
  AutoRegenerationOptions, 
  AutoRegenerationState 
} from '../../core'
import { DEFAULT_MAX_REGENERATIONS } from '../../core'

export function useAutoRegeneration(
  options: AutoRegenerationOptions = {}
): AutoRegenerationState {
  const {
    maxRegenerations = DEFAULT_MAX_REGENERATIONS,
    onMaxReached,
    onRegenerate
  } = options

  const [count, setCount] = useState(0)

  const hasReachedMax = count >= maxRegenerations

  const increment = useCallback((): boolean => {
    if (hasReachedMax) {
      onMaxReached?.()
      return false
    }

    setCount(prev => {
      const newCount = prev + 1
      onRegenerate?.(newCount)
      return newCount
    })
    return true
  }, [hasReachedMax, onMaxReached, onRegenerate])

  const reset = useCallback(() => {
    setCount(0)
  }, [])

  return {
    count,
    hasReachedMax,
    increment,
    reset
  }
}
