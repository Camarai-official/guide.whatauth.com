import { useState, useEffect, useCallback, useRef } from 'react'
import type { CountdownOptions, CountdownState } from '../../core'
import { formatTime } from '../../core'

export function useCountdown(options: CountdownOptions): CountdownState {
  const { 
    seconds, 
    autoStart = true, 
    onExpire 
  } = options

  const [timeLeft, setTimeLeft] = useState(seconds)
  const [isRunning, setIsRunning] = useState(false)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const initialSecondsRef = useRef(seconds)

  useEffect(() => {
    initialSecondsRef.current = seconds
  }, [seconds])

  const start = useCallback(() => {
    if (intervalRef.current) return
    
    setIsRunning(true)
    intervalRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current)
            intervalRef.current = null
          }
          setIsRunning(false)
          onExpire?.()
          return 0
        }
        return prev - 1
      })
    }, 1000)
  }, [onExpire])

  const stop = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
    setIsRunning(false)
  }, [])

  const restart = useCallback((newSeconds?: number) => {
    stop()
    const duration = newSeconds ?? initialSecondsRef.current
    setTimeLeft(duration)
    
    if (autoStart) {
      setTimeout(() => {
        setIsRunning(true)
        intervalRef.current = setInterval(() => {
          setTimeLeft(prev => {
            if (prev <= 1) {
              if (intervalRef.current) {
                clearInterval(intervalRef.current)
                intervalRef.current = null
              }
              setIsRunning(false)
              onExpire?.()
              return 0
            }
            return prev - 1
          })
        }, 1000)
      }, 0)
    }
  }, [stop, autoStart, onExpire])

  useEffect(() => {
    if (autoStart) {
      start()
    }
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
        intervalRef.current = null
      }
    }
  }, [autoStart, start])

  const isExpired = timeLeft <= 0
  const formattedTime = formatTime(timeLeft)

  return {
    timeLeft,
    formattedTime,
    isExpired,
    isRunning,
    start,
    stop,
    restart
  }
}
