import { useState, useCallback } from 'react'
import type { PinGeneratorOptions, PinGenerationResult } from '../../core'
import { generatePinWithEmojis } from '../../core'

export function usePinGenerator(
  options: PinGeneratorOptions = {}
): PinGenerationResult & { regenerate: () => PinGenerationResult } {
  const [result, setResult] = useState<PinGenerationResult>(() => 
    generatePinWithEmojis(options)
  )

  const regenerate = useCallback((): PinGenerationResult => {
    const newResult = generatePinWithEmojis(options)
    setResult(newResult)
    return newResult
  }, [options])

  return {
    pin: result.pin,
    emojis: result.emojis,
    emojiString: result.emojiString,
    regenerate
  }
}
