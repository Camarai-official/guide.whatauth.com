// @vitest-environment jsdom

import { act, renderHook } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';

const registerPinMock = vi.fn();
const cancelAuthMock = vi.fn();
const connectMock = vi.fn();
const disconnectMock = vi.fn();

const pinSequence = [
  { pin: 'PIN001', emojis: ['A'], emojiString: 'EMOJI-1' },
  { pin: 'PIN002', emojis: ['B'], emojiString: 'EMOJI-2' },
  { pin: 'PIN003', emojis: ['C'], emojiString: 'EMOJI-3' }
];

let generationIndex = 0;
let countdownExpireHandler: (() => void) | undefined;

vi.mock('../../core', () => {
  class WhatauthError extends Error {
    code: string;

    constructor(message: string, code: string) {
      super(message);
      this.code = code;
    }
  }

  class WhatauthSocketClient {
    setCallbacks = vi.fn();

    connect() {
      connectMock();
      return Promise.resolve();
    }

    disconnect() {
      disconnectMock();
    }

    isConnected() {
      return true;
    }

    registerPin(pin: string, emojiString: string) {
      registerPinMock(pin, emojiString);
      return Promise.resolve({ success: true });
    }

    cancelAuth(pin: string) {
      cancelAuthMock(pin);
    }
  }

  return {
    WhatauthError,
    WhatauthSocketClient,
    DEFAULT_PIN_LENGTH: 6,
    DEFAULT_COUNTDOWN_SECONDS: 180,
    DEFAULT_MAX_REGENERATIONS: 3,
    WHATSAPP_MESSAGE_PREFIX: 'PIN',
    createAuthStorage: () => ({
      save: vi.fn().mockResolvedValue(undefined),
      load: vi.fn().mockResolvedValue(null),
      clear: vi.fn().mockResolvedValue(undefined),
      exists: vi.fn().mockResolvedValue(false),
      getKey: vi.fn().mockReturnValue('whatauth_token')
    }),
    getUserFromToken: () => ({ id: 'user-1', name: 'Test' }),
    generateAuthLink: () => ({
      whatsappLink: 'https://wa.me/123?text=PIN',
      qrCodeUrl: 'https://qr.local',
      fullMessage: 'PIN EMOJI'
    })
  };
});

vi.mock('./useCountdown', () => ({
  useCountdown: ({ onExpire }: { onExpire?: () => void }) => {
    countdownExpireHandler = onExpire;

    return {
      timeLeft: 180,
      formattedTime: '03:00',
      isExpired: false,
      start: vi.fn(),
      restart: vi.fn(),
      stop: vi.fn()
    };
  }
}));

vi.mock('./useAutoRegeneration', () => ({
  useAutoRegeneration: () => ({
    count: 0,
    hasReachedMax: false,
    increment: () => true,
    reset: vi.fn()
  })
}));

vi.mock('./usePinGenerator', () => ({
  usePinGenerator: () => ({
    pin: generationIndex > 0 ? pinSequence[generationIndex - 1].pin : null,
    emojis: generationIndex > 0 ? pinSequence[generationIndex - 1].emojis : [],
    emojiString: generationIndex > 0 ? pinSequence[generationIndex - 1].emojiString : '',
    regenerate: () => {
      const generated = pinSequence[generationIndex] ?? pinSequence[pinSequence.length - 1];
      generationIndex += 1;
      return generated;
    }
  })
}));

import { usePinAuth } from './usePinAuth';

describe('usePinAuth regeneration flow', () => {
  beforeEach(() => {
    generationIndex = 0;
    countdownExpireHandler = undefined;

    registerPinMock.mockReset();
    cancelAuthMock.mockReset();
    connectMock.mockReset();
    disconnectMock.mockReset();
  });

  it('cancels previous pin when auto-regeneration happens on expire', async () => {
    const { result } = renderHook(() =>
      usePinAuth({
        apiUrl: 'http://localhost:3001',
        whatsappNumber: '34600000000'
      })
    );

    await act(async () => {
      await result.current.generate();
    });

    expect(registerPinMock).toHaveBeenCalledWith('PIN001', 'EMOJI-1');

    act(() => {
      countdownExpireHandler?.();
    });

    await act(async () => {
      await Promise.resolve();
    });

    expect(cancelAuthMock).toHaveBeenCalledWith('PIN001');
    expect(registerPinMock).toHaveBeenCalledWith('PIN002', 'EMOJI-2');
  });

  it('cancels current pin when cancel is called', async () => {
    const { result } = renderHook(() =>
      usePinAuth({
        apiUrl: 'http://localhost:3001',
        whatsappNumber: '34600000000'
      })
    );

    await act(async () => {
      await result.current.generate();
    });

    act(() => {
      result.current.cancel();
    });

    expect(cancelAuthMock).toHaveBeenCalledWith('PIN001');
  });
});
