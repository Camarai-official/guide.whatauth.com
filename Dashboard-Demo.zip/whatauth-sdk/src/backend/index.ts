import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import { createHmac, randomBytes, timingSafeEqual } from 'crypto';
import { EventEmitter } from 'events';
import { AuthDomainService, DomainError } from './domain/auth-domain-service';
import type { SessionData } from './domain/auth-domain-service';
import type { PinRepository } from './repositories/pin-repository';
import { MemoryPinRepository } from './repositories/pin-repository';
import { TokenService } from './services/token-service';
import { WebhookService } from './services/webhook-service';
import { rateLimit, cleanupRateLimitStore } from './middleware/rate-limit';
import { StructuredLogger, createProductionLogger, createDevelopmentLogger, requestLogger } from './middleware/structured-logger';
import { TimeProvider, RealTimeProvider } from './time-provider';
import type {
  BackendErrorResponse,
  DatabaseAdapter,
  EvolutionMessage,
  EvolutionWebhookPayload,
  PinData,
} from './types';

interface RawBodyRequest extends express.Request {
  rawBody?: Buffer;
}

export interface BackendConfig {
  port?: number;
  host?: string; // '0.0.0.0' para escuchar en todas las interfaces
  jwtSecret?: string;
  webhookSecret?: string;
  webhookSignatureHeader?: string;
  pinRepository?: PinRepository;
  evolutionApiUrl: string;
  evolutionApiKey: string;
  evolutionInstanceName: string;
  pinExpirationMinutes?: number;
  corsOrigins?: string | string[];
  db?: DatabaseAdapter | null;
  /** Logger personalizado (default: auto-detecta prod/dev) */
  logger?: StructuredLogger;
  /** Configuración de rate limiting */
  rateLimit?: {
    /** Habilitar rate limiting (default: true) */
    enabled?: boolean;
    /** Ventana en ms (default: 60000) */
    windowMs?: number;
    /** Max requests por ventana (default: 100) */
    maxRequests?: number;
    /** Rate limit estricto para login (default: 5 requests por hora) */
    strictLogin?: boolean;
  };
  /** Proveedor de tiempo (default: RealTimeProvider) */
  timeProvider?: TimeProvider;
}

export interface SendMessageOptions {
  phoneNumber: string;
  message: string;
  instanceName?: string;
}

export class WhatauthBackend extends EventEmitter {
  private app: express.Application;
  private server: ReturnType<typeof createServer>;
  private io: Server;
  private sessions: Map<string, SessionData> = new Map();
  private domainService: AuthDomainService;
  private config: Required<BackendConfig>;
  private db: DatabaseAdapter | null;
  private host: string;
  private cleanupIntervalId: ReturnType<typeof setInterval> | null = null;
  private logger: StructuredLogger;

  constructor(config: BackendConfig) {
    super();
    
    if (!config.evolutionApiUrl || !config.evolutionApiKey || !config.evolutionInstanceName) {
      throw new Error(
        'WhatauthBackend requiere: evolutionApiUrl, evolutionApiKey y evolutionInstanceName\n' +
        'Ejemplo:\n' +
        'const backend = new WhatauthBackend({\n' +
        '  evolutionApiUrl: "https://tu-evolution-api.com",\n' +
        '  evolutionApiKey: "tu-api-key",\n' +
        '  evolutionInstanceName: "mi-instancia"\n' +
        '});'
      );
    }
    
    this.host = config.host || process.env.HOST || '0.0.0.0';
    const webhookSecret =
      config.webhookSecret ||
      process.env.EVOLUTION_WEBHOOK_SECRET ||
      process.env.WEBHOOK_SECRET ||
      '';
    
    // Configurar logger
    this.logger = config.logger || (
      process.env.NODE_ENV === 'production' 
        ? createProductionLogger() 
        : createDevelopmentLogger()
    );
    
    this.config = {
      port: config.port || parseInt(process.env.PORT || '3001'),
      host: this.host,
      jwtSecret: this.resolveJwtSecret(config.jwtSecret),
      webhookSecret,
      webhookSignatureHeader: (config.webhookSignatureHeader || 'x-hub-signature-256').toLowerCase(),
      pinRepository: config.pinRepository || new MemoryPinRepository(),
      evolutionApiUrl: config.evolutionApiUrl,
      evolutionApiKey: config.evolutionApiKey,
      evolutionInstanceName: config.evolutionInstanceName,
      pinExpirationMinutes: config.pinExpirationMinutes || 3,
      corsOrigins: config.corsOrigins || ['http://localhost:3000', 'http://localhost:5173'],
      db: config.db || null,
      logger: this.logger,
      rateLimit: config.rateLimit || { enabled: true },
      timeProvider: config.timeProvider || new RealTimeProvider()
    };

    this.db = this.config.db;
    const tokenService = new TokenService({ jwtSecret: this.config.jwtSecret });
    const webhookService = new WebhookService();

    this.domainService = new AuthDomainService({
      pinRepository: this.config.pinRepository,
      tokenService,
      webhookService,
      sessions: this.sessions,
      db: this.db,
      pinExpirationMinutes: this.config.pinExpirationMinutes,
      timeProvider: this.config.timeProvider
    });

    this.app = express();
    this.server = createServer(this.app);
    this.io = new Server(this.server, {
      cors: {
        origin: this.config.corsOrigins,
        methods: ['GET', 'POST'],
        credentials: true
      }
    });

    this.setupMiddleware();
    this.setupHttpRoutes();
    this.setupWebSocketHandlers();
    this.setupCleanupInterval();
  }

  private resolveJwtSecret(configSecret?: string): string {
    const envSecret = process.env.JWT_SECRET;
    const secret = configSecret || envSecret;

    if (secret) {
      return secret;
    }

    if (process.env.NODE_ENV === 'production') {
      throw new Error('JWT_SECRET es obligatorio en produccion');
    }

    const generatedSecret = randomBytes(32).toString('hex');
    console.warn('[Backend] JWT_SECRET no configurado. Se genera una clave temporal para desarrollo.');
    return generatedSecret;
  }

  private setupMiddleware(): void {
    // Request logging
    this.app.use(requestLogger(this.logger));

    this.app.use(cors({
      origin: this.config.corsOrigins,
      credentials: true
    }));
    this.app.use(express.json({
      verify: (req, _res, buffer) => {
        (req as RawBodyRequest).rawBody = Buffer.from(buffer);
      }
    }));

    // Rate limiting
    if (this.config.rateLimit?.enabled !== false) {
      // Rate limit general
      this.app.use(rateLimit({
        windowMs: this.config.rateLimit?.windowMs || 60000,
        maxRequests: this.config.rateLimit?.maxRequests || 100,
        standardHeaders: true,
        skip: (req) => req.path === '/health'
      }));

      // Rate limit estricto para endpoints de autenticación
      this.app.use('/check-login', rateLimit({
        windowMs: 60000,
        maxRequests: this.config.rateLimit?.strictLogin !== false ? 5 : 100,
        standardHeaders: true,
        message: 'Demasiados intentos de login. Intenta más tarde.'
      }));
    }
  }

  private setupHttpRoutes(): void {
    // Health check
    this.app.get('/health', async (_req, res) => {
      const activePins = await this.domainService.countPins();
      res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        activePins,
        instance: this.config.evolutionInstanceName
      });
    });

    // Helpers
    const getTokenFromHeaders = (req: express.Request): string | null => {
      const authHeader = req.headers.authorization;
      if (authHeader && authHeader.startsWith('Bearer ')) {
        return authHeader.substring(7);
      }
      return null;
    };

    const getRawBody = (req: express.Request): string => {
      const rawBody = (req as RawBodyRequest).rawBody;
      if (rawBody) {
        return rawBody.toString('utf8');
      }
      return JSON.stringify(req.body ?? {});
    };

    const isWebhookSignatureValid = (req: express.Request): boolean => {
      if (!this.config.webhookSecret) {
        return true;
      }

      const headerValue = req.headers[this.config.webhookSignatureHeader];
      const signature = Array.isArray(headerValue) ? headerValue[0] : headerValue;

      if (!signature) {
        return false;
      }

      const normalizedSignature = signature.startsWith('sha256=')
        ? signature.slice('sha256='.length)
        : signature;

      if (!/^[a-f0-9]+$/i.test(normalizedSignature)) {
        return false;
      }

      const expectedSignature = createHmac('sha256', this.config.webhookSecret)
        .update(getRawBody(req))
        .digest('hex');

      const expectedBuffer = Buffer.from(expectedSignature, 'hex');
      const providedBuffer = Buffer.from(normalizedSignature, 'hex');

      if (expectedBuffer.length !== providedBuffer.length) {
        return false;
      }

      return timingSafeEqual(expectedBuffer, providedBuffer);
    };

    const errorResponse = (
      status: number,
      code: string,
      error: string,
      details?: Record<string, unknown>
    ): BackendErrorResponse => ({
      success: false,
      error,
      code,
      status,
      ...(details ? { details } : {})
    });

    const sendError = (
      res: express.Response,
      status: number,
      code: string,
      error: string,
      details?: Record<string, unknown>
    ): void => {
      res.status(status).json(errorResponse(status, code, error, details));
    };

    const sendInternalError = (
      res: express.Response,
      context: string,
      rawError: unknown,
      errorMessage = 'Error interno'
    ): void => {
      console.error(`[Backend] ${context}:`, rawError);
      sendError(res, 500, 'INTERNAL_ERROR', errorMessage);
    };

    const respondDomainError = (res: express.Response, error: unknown): boolean => {
      if (error instanceof DomainError) {
        res.status(error.status).json(error.toResponseBody());
        return true;
      }

      return false;
    };

    // POST /register-pin - Registra un nuevo PIN (compatible con n8n)
    this.app.post('/register-pin', async (req, res) => {
      try {
        const { pinData, expiresIn } = await this.domainService.registerPin({
          pin: req.body?.pin,
          emojiString: req.body?.emojiString
        });
        
        
        res.json({ 
          success: true, 
          message: 'PIN registrado correctamente',
          pinId: pinData.id,
          expiresIn
        });

      } catch (error) {
        if (respondDomainError(res, error)) {
          return;
        }

        sendInternalError(res, 'Error registrando PIN', error, 'Error registrando PIN');
      }
    });

    // POST /check-login - Verifica si un PIN ha sido verificado (compatible con n8n)
    this.app.post('/check-login', async (req, res) => {
      try {
        const response = await this.domainService.checkLogin(req.body?.pin);
        res.json(response);

      } catch (error) {
        if (respondDomainError(res, error)) {
          return;
        }

        sendInternalError(res, 'Error en check-login', error);
      }
    });

    // POST /whatsapp-endpoint - Recibe mensajes de WhatsApp (compatible con n8n)
    this.app.post('/whatsapp-endpoint', async (req, res) => {
      try {
        if (!isWebhookSignatureValid(req)) {
          sendError(res, 401, 'WEBHOOK_SIGNATURE_INVALID', 'Firma webhook invalida');
          return;
        }

        
        // Evolution envía: { event, instance, data: {...} }
        // Necesitamos extraer data
        const payload = req.body as { data?: EvolutionMessage };
        if (payload.data) {
          await this.processIncomingMessage(payload.data);
        } else {
        }
        
        res.sendStatus(200);
      } catch (error) {
        sendInternalError(res, 'Error procesando mensaje WA', error, 'Error procesando mensaje WA');
      }
    });

    // POST /webhook/evolution - Alias para /whatsapp-endpoint
    this.app.post('/webhook/evolution', async (req, res) => {
      try {
        if (!isWebhookSignatureValid(req)) {
          sendError(res, 401, 'WEBHOOK_SIGNATURE_INVALID', 'Firma webhook invalida');
          return;
        }

        const payload = req.body as EvolutionWebhookPayload;
        
        if (!this.domainService.shouldProcessWebhookPayload(payload, this.config.evolutionInstanceName)) {
          if (payload.instance !== this.config.evolutionInstanceName) {
          }
          return res.sendStatus(200);
        }

        await this.processIncomingMessage(payload.data);
        
        res.sendStatus(200);
      } catch (error) {
        sendInternalError(res, 'Error procesando webhook', error, 'Error procesando webhook');
      }
    });

    // POST /refresh-token - Refresca el token de acceso (compatible con n8n)
    this.app.post('/refresh-token', async (req, res) => {
      try {
        const bodyRefreshToken =
          typeof req.body?.refreshToken === 'string' ? req.body.refreshToken : null;
        const legacyAccessToken = getTokenFromHeaders(req);
        const response = await this.domainService.refreshToken({
          refreshToken: bodyRefreshToken,
          legacyAccessToken
        });
        res.json(response);

      } catch (error) {
        if (respondDomainError(res, error)) {
          return;
        }

        sendInternalError(res, 'Error en refresh-token', error);
      }
    });

    // GET /profile - Obtiene el perfil del usuario
    this.app.get('/profile', (req, res) => {
      const token = getTokenFromHeaders(req);
      
      if (!token) {
        sendError(res, 401, 'TOKEN_NOT_PROVIDED', 'No token provided');
        return;
      }

      try {
        res.json(this.domainService.getProfile(token));
      } catch (error) {
        if (respondDomainError(res, error)) {
          return;
        }

        sendInternalError(res, 'Error en profile', error);
      }
    });

    // POST /logout - Cierra sesión
    this.app.post('/logout', async (req, res) => {
      try {
        const response = await this.domainService.logout({
          userId: req.body?.userId || req.body?.id,
          authToken: getTokenFromHeaders(req)
        });
        res.json(response);
      } catch (error) {
        sendInternalError(res, 'Error en logout', error);
      }
    });

    // Enviar mensaje de WhatsApp manualmente
    this.app.post('/send-message', async (req, res) => {
      try {
        const { phoneNumber, message } = req.body;
        
        if (!phoneNumber || !message) {
          sendError(
            res,
            400,
            'INVALID_REQUEST',
            'phoneNumber y message son requeridos',
            { required: ['phoneNumber', 'message'] }
          );
          return;
        }

        await this.sendWhatsAppMessage({ phoneNumber, message });
        res.json({ success: true, message: 'Mensaje enviado' });
      } catch (error) {
        sendInternalError(res, 'Error enviando mensaje', error, 'Error enviando mensaje');
      }
    });
  }

  private setupWebSocketHandlers(): void {
    this.io.on('connection', (socket) => {

      socket.on('register-pin', async (data: { pin: string; emojiString: string }) => {
        try {
          const { pinData, expiresIn } = await this.domainService.registerPin({
            pin: data?.pin,
            emojiString: data?.emojiString,
            socketId: socket.id
          });
          
          
          socket.emit('pin-registered', { 
            success: true, 
            pinId: pinData.id,
            expiresIn
          });

        } catch (error) {
          if (error instanceof DomainError) {
            socket.emit('pin-error', {
              error: error.message,
              code: error.code,
              status: error.status,
              ...(error.details ? { details: error.details } : {})
            });
            return;
          }

          socket.emit('pin-error', { error: 'Error registrando PIN' });
        }
      });

      socket.on('cancel-auth', async (data: { pin: string }) => {
        const cancelled = await this.domainService.cancelPin(data?.pin, socket.id);
        if (cancelled && data?.pin) {
        }

        socket.emit('auth-cancelled');
      });

      socket.on('disconnect', async () => {
  
        const cleanedPins = await this.domainService.cleanupPinsBySocket(socket.id);
        for (const pin of cleanedPins) {
        }
      });
    });
  }

  private async processIncomingMessage(message: EvolutionMessage): Promise<void> {
    const result = await this.domainService.processIncomingMessage(message);

    switch (result.kind) {
      case 'ignored': {
        if (result.rawText) {
        }
        return;
      }
      case 'unknown_pin': {
        return;
      }
      case 'already_processed': {
        return;
      }
      case 'expired': {
        if (result.socketId) {
          this.io.to(result.socketId).emit('pin-expired', { pin: result.pin });
        }
        return;
      }
      case 'verified': {

        if (result.socketId) {
          this.io.to(result.socketId).emit('auth-success', result.authResponse);
        }

        this.emit('auth:verified', {
          pin: result.pin,
          phoneNumber: result.phoneNumber,
          userId: result.userId,
          userData: result.userData
        });
        return;
      }
      default:
        return;
    }
  }

  public async sendWhatsAppMessage(options: SendMessageOptions): Promise<void> {
    const { phoneNumber, message, instanceName } = options;
    const instance = instanceName || this.config.evolutionInstanceName;
    
    try {
      const cleanPhone = phoneNumber.replace(/\D/g, '');
      
      const response = await fetch(`${this.config.evolutionApiUrl}/message/sendText/${instance}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': this.config.evolutionApiKey
        },
        body: JSON.stringify({
          number: cleanPhone,
          text: message
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Error ${response.status}: ${errorText}`);
      }

    } catch (error) {
      throw error;
    }
  }

  private setupCleanupInterval(): void {
    this.cleanupIntervalId = setInterval(() => {
      void this.domainService.cleanupExpiredPins()
        .then((cleanupResult) => {
          for (const expiredPin of cleanupResult.expiredPins) {
            if (expiredPin.socketId) {
              this.io.to(expiredPin.socketId).emit('pin-expired', { pin: expiredPin.pin });
            }
          }

          if (cleanupResult.cleaned > 0) {
          }
        })
        .catch((error) => {
        });
    }, 30000);
  }

  public start(): void {
    this.server.listen(this.config.port, this.host, () => {
      // Server started
    });
  }

  public stop(): Promise<void> {
    if (this.cleanupIntervalId) {
      clearInterval(this.cleanupIntervalId);
      this.cleanupIntervalId = null;
    }

    if (!this.server.listening) {
      return Promise.resolve();
    }

    return new Promise((resolve) => {
      this.server.close(() => {
          resolve();
      });
    });
  }

  public getPins(): Map<string, PinData> {
    return this.domainService.getDebugPinsMap();
  }

  public getApp(): express.Application {
    return this.app;
  }

  public getIO(): Server {
    return this.io;
  }
}

export function createWhatauthBackend(config: BackendConfig): WhatauthBackend {
  return new WhatauthBackend(config);
}

export * from './types';
export * from './domain/auth-domain-service';
export * from './repositories/pin-repository';
export * from './services/token-service';
export * from './services/webhook-service';
export * from './models/user';
export { MockDatabaseAdapter } from './adapters/mock-adapter';
export type { MockQueryCall } from './adapters/mock-adapter';
export { PostgreSQLAdapter, createPostgreSQLAdapter } from './adapters/postgresql-adapter';
export type { PGPoolLike, PostgreSQLAdapterConfig } from './adapters/postgresql-adapter';

// SDK-029: Middleware exports
export { rateLimit, cleanupRateLimitStore, resetRateLimitStore, getRateLimitStats } from './middleware/rate-limit';
export type { RateLimitConfig, RateLimitEntry } from './middleware/rate-limit';
export { StructuredLogger, logger, requestLogger, errorLogger, createProductionLogger, createDevelopmentLogger } from './middleware/structured-logger';
export type { LogLevel, LogContext, LogEntry, LoggerConfig } from './middleware/structured-logger';
export { RealTimeProvider, FakeTimeProvider } from './time-provider';
export type { TimeProvider, TimeProvider as TimeProviderInterface } from './time-provider';

// CLI
const isDirectExecution =
  typeof require !== 'undefined' &&
  typeof module !== 'undefined' &&
  require.main === module;

if (isDirectExecution) {
  const backend = new WhatauthBackend({
    port: parseInt(process.env.PORT || '3001'),
    jwtSecret: process.env.JWT_SECRET,
    webhookSecret: process.env.EVOLUTION_WEBHOOK_SECRET || process.env.WEBHOOK_SECRET,
    evolutionApiUrl: process.env.EVOLUTION_API_URL!,
    evolutionApiKey: process.env.EVOLUTION_API_KEY!,
    evolutionInstanceName: process.env.EVOLUTION_INSTANCE_NAME!,
    pinExpirationMinutes: parseInt(process.env.PIN_EXPIRATION_MINUTES || '3'),
    corsOrigins: process.env.CORS_ORIGINS?.split(',')
  });
  
  backend.start();
}
