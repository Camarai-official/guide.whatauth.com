import { createServer } from 'net';
import { afterEach, describe, expect, it } from 'vitest';
import { CamarauthBackend } from './index';

async function getFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') {
        server.close();
        reject(new Error('No se pudo obtener puerto libre'));
        return;
      }

      server.close(() => resolve(address.port));
    });
  });
}

async function waitForHealth(baseUrl: string): Promise<void> {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) {
        return;
      }
    } catch {
      // Retry until backend is up.
    }

    await new Promise(resolve => setTimeout(resolve, 50));
  }

  throw new Error('Backend no inicio a tiempo');
}

const startedBackends: CamarauthBackend[] = [];

async function startBackend(options: Partial<ConstructorParameters<typeof CamarauthBackend>[0]> = {}) {
  const port = await getFreePort();

  const backend = new CamarauthBackend({
    port,
    host: '127.0.0.1',
    jwtSecret: 'error-contract-secret',
    evolutionApiUrl: 'https://example.com',
    evolutionApiKey: 'test-api-key',
    evolutionInstanceName: 'test-instance',
    ...options
  });

  backend.start();
  startedBackends.push(backend);

  const baseUrl = `http://127.0.0.1:${port}`;
  await waitForHealth(baseUrl);

  return { baseUrl };
}

afterEach(async () => {
  while (startedBackends.length > 0) {
    const backend = startedBackends.pop();
    if (backend) {
      await backend.stop();
    }
  }
});

function expectStandardErrorBody(
  body: Record<string, unknown>,
  expected: { status: number; code: string; error: string }
): void {
  expect(body.success).toBe(false);
  expect(body.status).toBe(expected.status);
  expect(body.code).toBe(expected.code);
  expect(body.error).toBe(expected.error);
}

describe('Backend error contract', () => {
  it('returns standardized error for register-pin missing pin', async () => {
    const { baseUrl } = await startBackend();

    const response = await fetch(`${baseUrl}/register-pin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const body = await response.json();

    expect(response.status).toBe(400);
    expectStandardErrorBody(body, {
      status: 400,
      code: 'PIN_REQUIRED',
      error: 'PIN es requerido'
    });
    expect(body.details).toEqual({ field: 'pin' });
  });

  it('returns standardized error for refresh-token invalid request', async () => {
    const { baseUrl } = await startBackend();

    const response = await fetch(`${baseUrl}/refresh-token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const body = await response.json();

    expect(response.status).toBe(400);
    expectStandardErrorBody(body, {
      status: 400,
      code: 'INVALID_REQUEST',
      error: 'Peticion invalida'
    });
  });

  it('returns standardized error for missing profile token', async () => {
    const { baseUrl } = await startBackend();

    const response = await fetch(`${baseUrl}/profile`);
    const body = await response.json();

    expect(response.status).toBe(401);
    expectStandardErrorBody(body, {
      status: 401,
      code: 'TOKEN_NOT_PROVIDED',
      error: 'No token provided'
    });
  });

  it('returns standardized webhook signature error when secret is enabled', async () => {
    const { baseUrl } = await startBackend({ webhookSecret: 'error-contract-webhook-secret' });

    const response = await fetch(`${baseUrl}/webhook/evolution`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event: 'messages.upsert', instance: 'test-instance' })
    });
    const body = await response.json();

    expect(response.status).toBe(401);
    expectStandardErrorBody(body, {
      status: 401,
      code: 'WEBHOOK_SIGNATURE_INVALID',
      error: 'Firma webhook invalida'
    });
  });

  it('returns standardized validation error for send-message payload', async () => {
    const { baseUrl } = await startBackend();

    const response = await fetch(`${baseUrl}/send-message`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneNumber: '3000000000' })
    });
    const body = await response.json();

    expect(response.status).toBe(400);
    expectStandardErrorBody(body, {
      status: 400,
      code: 'INVALID_REQUEST',
      error: 'phoneNumber y message son requeridos'
    });
    expect(body.details).toEqual({ required: ['phoneNumber', 'message'] });
  });
});
