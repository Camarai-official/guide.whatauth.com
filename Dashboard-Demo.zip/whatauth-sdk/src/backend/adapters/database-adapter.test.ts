import { describe, it, expect, beforeEach } from 'vitest';
import { MockDatabaseAdapter } from './mock-adapter';
import type { DatabaseAdapter, DatabaseQueryResult } from '../types';

describe('DatabaseAdapter Contract', () => {
  let adapter: MockDatabaseAdapter;

  beforeEach(() => {
    adapter = new MockDatabaseAdapter();
  });

  describe('interface compliance', () => {
    it('should implement DatabaseAdapter interface', () => {
      expect(adapter).toBeDefined();
      expect(typeof adapter.query).toBe('function');
    });

    it('should return Promise<DatabaseQueryResult> from query', async () => {
      const result = await adapter.query('SELECT 1');
      
      expect(result).toHaveProperty('rows');
      expect(result).toHaveProperty('rowCount');
      expect(Array.isArray(result.rows)).toBe(true);
      expect(typeof result.rowCount).toBe('number');
    });
  });

  describe('query behavior', () => {
    it('should handle SELECT queries', async () => {
      adapter.mockQueryResponse(/SELECT/i, [
        { id: 1, nombre: 'Test User' }
      ]);

      const result = await adapter.query('SELECT * FROM usuarios WHERE id = $1', [1]);
      
      expect(result.rows).toHaveLength(1);
      expect(result.rows[0]).toMatchObject({ id: 1, nombre: 'Test User' });
      expect(result.rowCount).toBe(1);
    });

    it('should handle INSERT queries', async () => {
      adapter.mockQueryResponse(/INSERT/i, [
        { id: 42, nombre: 'New User', telefono: '+1234567890' }
      ]);

      const result = await adapter.query(
        'INSERT INTO usuarios (nombre, telefono) VALUES ($1, $2) RETURNING *',
        ['New User', '+1234567890']
      );
      
      expect(result.rows[0]).toMatchObject({
        id: 42,
        nombre: 'New User',
        telefono: '+1234567890'
      });
    });

    it('should handle UPDATE queries', async () => {
      adapter.mockQueryResponse(/UPDATE/i, [
        { id: 1, nombre: 'Updated Name' }
      ]);

      const result = await adapter.query(
        'UPDATE usuarios SET nombre = $1 WHERE id = $2 RETURNING *',
        ['Updated Name', 1]
      );
      
      expect(result.rows[0].nombre).toBe('Updated Name');
    });

    it('should handle empty results', async () => {
      const result = await adapter.query('SELECT * FROM usuarios WHERE id = $1', [999]);
      
      expect(result.rows).toEqual([]);
      expect(result.rowCount).toBe(0);
    });

    it('should track query calls for verification', async () => {
      await adapter.query('SELECT * FROM test', [1, 2, 3]);
      
      expect(adapter.wasCalledWith('SELECT')).toBe(true);
      expect(adapter.wasCalledWith(/FROM test/i)).toBe(true);
      
      const calls = adapter.getCalls();
      expect(calls).toHaveLength(1);
      expect(calls[0].text).toBe('SELECT * FROM test');
      expect(calls[0].values).toEqual([1, 2, 3]);
    });
  });

  describe('type safety', () => {
    it('should preserve row types in results', async () => {
      type UserRow = {
        id: number;
        nombre: string;
        email: string;
      };

      adapter.mockQueryResponse<UserRow>(/SELECT/i, [
        { id: 1, nombre: 'John', email: 'john@example.com' }
      ]);

      const result = await adapter.query<UserRow>('SELECT * FROM usuarios');
      const user = result.rows[0];
      
      expect(user.id).toBe(1);
      expect(user.nombre).toBe('John');
      expect(user.email).toBe('john@example.com');
    });
  });

  describe('real-world patterns', () => {
    it('should support user lookup by phone', async () => {
      adapter.mockQueryResponse(/SELECT.*telefono/i, [
        { id: 1, nombre: 'Maria', telefono: '+34600123456', estado: 'activo' }
      ]);

      const result = await adapter.query(
        'SELECT * FROM usuarios WHERE telefono = $1',
        ['+34600123456']
      );
      
      expect(result.rows[0]).toMatchObject({
        nombre: 'Maria',
        telefono: '+34600123456'
      });
    });

    it('should support session upsert', async () => {
      adapter.mockQueryResponse(/INSERT.*user_session/i, []);

      await adapter.query(
        `INSERT INTO user_session (user_id, refresh_token, isactive) 
         VALUES ($1, $2, true)
         ON CONFLICT (user_id) DO UPDATE 
         SET refresh_token = $2, isactive = true`,
        ['user_123', 'refresh_token_xyz']
      );
      
      expect(adapter.wasCalledWith(/user_session/i)).toBe(true);
    });

    it('should support role lookup', async () => {
      adapter.mockQueryResponse(/JOIN roles/i, [
        { nombre: 'admin' },
        { nombre: 'user' }
      ]);

      const result = await adapter.query(
        `SELECT r.nombre FROM roles_usuarios ru 
         JOIN roles r ON ru.rol_id = r.id 
         WHERE ru.usuario_id = $1`,
        ['1']
      );
      
      expect(result.rows).toHaveLength(2);
      expect(result.rows.map(r => r.nombre)).toContain('admin');
    });
  });

  describe('error handling', () => {
    it('should handle null adapter gracefully', async () => {
      const nullAdapter = null as unknown as DatabaseAdapter | null;
      
      if (nullAdapter) {
        await (nullAdapter as DatabaseAdapter).query('SELECT 1');
      }
      
      expect(nullAdapter).toBeNull();
    });

    it('should return consistent empty result for unknown queries', async () => {
      const result1 = await adapter.query('UNKNOWN QUERY');
      const result2 = await adapter.query('ANOTHER UNKNOWN');
      
      expect(result1.rows).toEqual([]);
      expect(result2.rows).toEqual([]);
      expect(result1.rowCount).toBe(0);
      expect(result2.rowCount).toBe(0);
    });
  });
});
