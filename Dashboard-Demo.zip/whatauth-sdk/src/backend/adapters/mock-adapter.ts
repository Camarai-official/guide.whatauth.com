import type { DatabaseAdapter, DatabaseQueryResult } from '../types';

export interface MockQueryCall {
  text: string;
  values: unknown[];
}

export class MockDatabaseAdapter implements DatabaseAdapter {
  private responses: Map<string, unknown[]> = new Map();
  private calls: MockQueryCall[] = [];

  mockQueryResponse<Row extends Record<string, unknown>>(
    pattern: string | RegExp,
    rows: Row[]
  ): this {
    const key = pattern instanceof RegExp ? pattern.source : pattern;
    this.responses.set(key, rows);
    return this;
  }

  getCalls(): MockQueryCall[] {
    return [...this.calls];
  }

  wasCalledWith(pattern: string | RegExp): boolean {
    const key = pattern instanceof RegExp ? pattern.source : pattern;
    return this.calls.some(call => {
      if (pattern instanceof RegExp) {
        return pattern.test(call.text);
      }
      return call.text.includes(key);
    });
  }

  clear(): void {
    this.responses.clear();
    this.calls = [];
  }

  async query<Row extends Record<string, unknown>>(
    text: string,
    values?: unknown[]
  ): Promise<DatabaseQueryResult<Row>> {
    this.calls.push({ text, values: values || [] });

    for (const [pattern, rows] of this.responses) {
      const regex = new RegExp(pattern, 'i');
      if (regex.test(text)) {
        return {
          rows: rows as Row[],
          rowCount: rows.length
        };
      }
    }

    // Comportamiento por defecto mejorado para INSERTs (mocking la creación del usuario)
    if (text.trim().toUpperCase().startsWith('INSERT')) {
       return {
          rows: [{
            id: 'mock_user_' + Date.now(),
            name: values?.[0] || 'Mock User',
            phone: values?.[1] || '000',
            estado: 'activo'
          }] as unknown as Row[],
          rowCount: 1
       };
    }

    return {
      rows: [],
      rowCount: 0
    };
  }
}
