/**
 * SDK-018: PostgreSQL Database Adapter
 * 
 * Implementación de DatabaseAdapter para PostgreSQL.
 * 
 * Uso:
 * ```typescript
 * import { Pool } from 'pg';
 * import { PostgreSQLAdapter } from 'whatauth-sdk/backend';
 * 
 * const pool = new Pool({ connectionString: process.env.DATABASE_URL });
 * const adapter = new PostgreSQLAdapter(pool);
 * 
 * const backend = new WhatauthBackend({
 *   // ... otras opciones
 *   db: adapter
 * });
 * ```
 */

import type { DatabaseAdapter, DatabaseQueryResult } from '../types';

/**
 * Interface mínima compatible con pg.Pool
 * Esto permite usar cualquier implementación compatible con pg
 * sin tener que depender directamente del paquete 'pg'
 */
export interface PGPoolLike {
  query: <Row extends Record<string, unknown>>(
    text: string,
    values?: unknown[]
  ) => Promise<{ rows: Row[]; rowCount?: number }>;
  end?: () => Promise<void>;
}

/**
 * Configuración del adaptador PostgreSQL
 */
export interface PostgreSQLAdapterConfig {
  /** Prefijo para tablas (default: '') */
  tablePrefix?: string;
  
  /** Nombre de la tabla de usuarios (default: 'usuarios') */
  userTable?: string;
  
  /** Nombre de la tabla de sesiones (default: 'user_session') */
  sessionTable?: string;
  
  /** Nombre de la tabla de códigos de verificación (default: 'verification_codes') */
  verificationTable?: string;
}

/**
 * Adaptador PostgreSQL para Camarauth
 * 
 * Implementa DatabaseAdapter usando cualquier pool compatible con pg
 */
export class PostgreSQLAdapter implements DatabaseAdapter {
  private readonly pool: PGPoolLike;
  private readonly config: Required<PostgreSQLAdapterConfig>;

  constructor(pool: PGPoolLike, config: PostgreSQLAdapterConfig = {}) {
    this.pool = pool;
    this.config = {
      tablePrefix: config.tablePrefix || '',
      userTable: config.userTable || 'usuarios',
      sessionTable: config.sessionTable || 'user_session',
      verificationTable: config.verificationTable || 'verification_codes'
    };
  }

  /**
   * Ejecuta una query SQL
   * 
   * @param text - Query SQL con parámetros $1, $2, etc.
   * @param values - Valores para los parámetros
   * @returns Resultado de la query
   */
  async query<Row extends Record<string, unknown>>(
    text: string,
    values?: unknown[]
  ): Promise<DatabaseQueryResult<Row>> {
    const result = await this.pool.query<Row>(text, values);
    
    return {
      rows: result.rows,
      rowCount: result.rowCount ?? result.rows.length
    };
  }

  /**
   * Obtiene el nombre completo de una tabla (con prefijo)
   */
  getTableName(baseName: string): string {
    return `${this.config.tablePrefix}${baseName}`;
  }

  /**
   * Obtiene el nombre de la tabla de usuarios
   */
  get userTable(): string {
    return this.getTableName(this.config.userTable);
  }

  /**
   * Obtiene el nombre de la tabla de sesiones
   */
  get sessionTable(): string {
    return this.getTableName(this.config.sessionTable);
  }

  /**
   * Obtiene el nombre de la tabla de verificación
   */
  get verificationTable(): string {
    return this.getTableName(this.config.verificationTable);
  }

  /**
   * Cierra la conexión con la base de datos
   */
  async end(): Promise<void> {
    if (this.pool.end) {
      await this.pool.end();
    }
  }
}

/**
 * Crea un PostgreSQLAdapter desde una URL de conexión
 * 
 * @param connectionString - URL de conexión PostgreSQL
 * @param PoolConstructor - Constructor de pg.Pool (debe ser pasado para evitar dependencia directa)
 * @param config - Configuración opcional del adapter
 * @returns PostgreSQLAdapter configurado
 * 
 * @example
 * ```typescript
 * import { Pool } from 'pg';
 * import { createPostgreSQLAdapter } from 'whatauth-sdk/backend';
 * 
 * const adapter = createPostgreSQLAdapter(
 *   process.env.DATABASE_URL!,
 *   Pool,
 *   { tablePrefix: 'auth_' }
 * );
 * ```
 */
export function createPostgreSQLAdapter(
  connectionString: string,
  PoolConstructor: new (config: { connectionString: string }) => PGPoolLike,
  config?: PostgreSQLAdapterConfig
): PostgreSQLAdapter {
  const pool = new PoolConstructor({ connectionString });
  return new PostgreSQLAdapter(pool, config);
}
