/**
 * SDK-018: PostgreSQL Adapter Tests
 * 
 * Tests unitarios y de integración para PostgreSQLAdapter.
 * 
 * Nota: Los tests de integración requieren una base de datos PostgreSQL
 * disponible. Si no hay DB, estos tests se saltan automáticamente.
 */

import { describe, it, expect, beforeEach, beforeAll } from 'vitest';
import { PostgreSQLAdapter, createPostgreSQLAdapter, type PGPoolLike } from './postgresql-adapter';
import type { DatabaseQueryResult } from '../types';

describe('SDK-018: PostgreSQLAdapter', () => {
  describe('Unit tests', () => {
    // Mock de pool para tests unitarios
    function createMockPool(): PGPoolLike {
      return {
        query: async <Row extends Record<string, unknown>>(
          text: string,
          values?: unknown[]
        ): Promise<{ rows: Row[]; rowCount?: number }> => {
          return {
            rows: [{ query: text, params: values } as unknown as Row],
            rowCount: 1
          };
        }
      };
    }

    it('should implement DatabaseAdapter interface', () => {
      const pool = createMockPool();
      const adapter = new PostgreSQLAdapter(pool);

      expect(adapter).toBeDefined();
      expect(typeof adapter.query).toBe('function');
    });

    it('should execute queries and return formatted result', async () => {
      const pool = createMockPool();
      const adapter = new PostgreSQLAdapter(pool);

      const result = await adapter.query('SELECT * FROM users WHERE id = $1', [1]);

      expect(result).toHaveProperty('rows');
      expect(result).toHaveProperty('rowCount');
      expect(Array.isArray(result.rows)).toBe(true);
    });

    it('should use default table names', () => {
      const pool = createMockPool();
      const adapter = new PostgreSQLAdapter(pool);

      expect(adapter.userTable).toBe('usuarios');
      expect(adapter.sessionTable).toBe('user_session');
      expect(adapter.verificationTable).toBe('verification_codes');
    });

    it('should use custom table names with prefix', () => {
      const pool = createMockPool();
      const adapter = new PostgreSQLAdapter(pool, {
        tablePrefix: 'camarauth_',
        userTable: 'users',
        sessionTable: 'sessions'
      });

      expect(adapter.userTable).toBe('camarauth_users');
      expect(adapter.sessionTable).toBe('camarauth_sessions');
      expect(adapter.verificationTable).toBe('camarauth_verification_codes');
    });

    it('should get prefixed table names', () => {
      const pool = createMockPool();
      const adapter = new PostgreSQLAdapter(pool, { tablePrefix: 'test_' });

      expect(adapter.getTableName('custom_table')).toBe('test_custom_table');
    });

    it('should handle query with empty values', async () => {
      const pool = createMockPool();
      const adapter = new PostgreSQLAdapter(pool);

      const result = await adapter.query('SELECT 1');

      expect(result.rows).toHaveLength(1);
      expect(result.rowCount).toBe(1);
    });

    it('should call pool.end when available', async () => {
      let endCalled = false;
      const pool: PGPoolLike = {
        ...createMockPool(),
        end: async () => {
          endCalled = true;
        }
      };

      const adapter = new PostgreSQLAdapter(pool);
      await adapter.end();

      expect(endCalled).toBe(true);
    });

    it('should not fail if pool.end is not available', async () => {
      const pool = createMockPool();
      const adapter = new PostgreSQLAdapter(pool);

      // No debería lanzar error
      await expect(adapter.end()).resolves.not.toThrow();
    });
  });

  describe('Factory function', () => {
    it('should create adapter with connection string', () => {
      class MockPool implements PGPoolLike {
        constructor(public config: { connectionString: string }) {}
        async query<Row>(): Promise<{ rows: Row[] }> {
          return { rows: [] };
        }
      }

      const adapter = createPostgreSQLAdapter(
        'postgres://user:pass@localhost/db',
        MockPool,
        { tablePrefix: 'auth_' }
      );

      expect(adapter).toBeInstanceOf(PostgreSQLAdapter);
      expect(adapter.userTable).toBe('auth_usuarios');
    });
  });

  describe('Integration tests', () => {
    // Verificar si hay DB disponible
    const hasTestDatabase = !!process.env.TEST_DATABASE_URL;

    // Pool real para tests de integración (si está disponible)
    let realPool: PGPoolLike | null = null;
    let realAdapter: PostgreSQLAdapter | null = null;

    beforeAll(async () => {
      if (!hasTestDatabase) {
        console.log('[SDK-018] Skipping integration tests - TEST_DATABASE_URL not set');
        return;
      }

      try {
        // Intentar importar pg dinámicamente
        // @ts-ignore - pg es dependencia opcional para pruebas
        const { Pool } = await import('pg');
        realPool = new Pool({
          connectionString: process.env.TEST_DATABASE_URL
        });
        realAdapter = new PostgreSQLAdapter(realPool as PGPoolLike, {
          tablePrefix: 'test_sdk018_'
        });

        // Crear tabla de prueba
        await realAdapter.query(`
          CREATE TABLE IF NOT EXISTS ${realAdapter.userTable} (
            id SERIAL PRIMARY KEY,
            nombre VARCHAR(255),
            telefono VARCHAR(20) UNIQUE,
            email VARCHAR(255),
            estado VARCHAR(20) DEFAULT 'activo'
          )
        `);
      } catch (error) {
        console.error('[SDK-018] Failed to setup test database:', error);
      }
    });

    beforeEach(async () => {
      if (!realAdapter) return;
      
      // Limpiar datos de prueba
      await realAdapter.query(`DELETE FROM ${realAdapter.userTable}`);
    });

    it.skipIf(!hasTestDatabase)('should connect to real PostgreSQL database', async () => {
      if (!realAdapter) return;

      const result = await realAdapter.query('SELECT NOW() as now');
      
      expect(result.rows).toHaveLength(1);
      expect(result.rows[0]).toHaveProperty('now');
    });

    it.skipIf(!hasTestDatabase)('should insert and retrieve user data', async () => {
      if (!realAdapter) return;

      // Insertar usuario
      const insertResult = await realAdapter.query(
        `INSERT INTO ${realAdapter.userTable} (nombre, telefono, email) 
         VALUES ($1, $2, $3) RETURNING *`,
        ['Test User', '+34600123456', 'test@example.com']
      );

      expect(insertResult.rows).toHaveLength(1);
      expect(insertResult.rows[0].nombre).toBe('Test User');

      // Recuperar usuario
      const selectResult = await realAdapter.query(
        `SELECT * FROM ${realAdapter.userTable} WHERE telefono = $1`,
        ['+34600123456']
      );

      expect(selectResult.rows).toHaveLength(1);
      expect(selectResult.rows[0].telefono).toBe('+34600123456');
    });

    it.skipIf(!hasTestDatabase)('should handle parameterized queries', async () => {
      if (!realAdapter) return;

      // Insertar múltiples usuarios
      for (let i = 1; i <= 3; i++) {
        await realAdapter.query(
          `INSERT INTO ${realAdapter.userTable} (nombre, telefono) 
           VALUES ($1, $2)`,
          [`User ${i}`, `+3460000000${i}`]
        );
      }

      // Contar usuarios
      const countResult = await realAdapter.query(
        `SELECT COUNT(*) as count FROM ${realAdapter.userTable}`
      );

      expect(parseInt(countResult.rows[0].count as string)).toBe(3);
    });

    it.skipIf(!hasTestDatabase)('should return correct rowCount', async () => {
      if (!realAdapter) return;

      const result = await realAdapter.query(
        `INSERT INTO ${realAdapter.userTable} (nombre, telefono) 
         VALUES ($1, $2) RETURNING *`,
        ['Count Test', '+34999111111']
      );

      expect(result.rowCount).toBe(1);
    });
  });
});
