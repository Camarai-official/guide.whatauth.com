import { createHmac } from 'crypto';
import { createServer } from 'net';
import jwt from 'jsonwebtoken';
import { afterEach, describe, expect, it } from 'vitest';
import { WhatauthBackend } from './index';

async function getFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') {
        server.close();
        reject(new Error('No se pudo resolver puerto libre'));
        return;
      }

      const { port } = address;
      server.close(() => resolve(port));
    });
  });
}

async function waitForHealth(baseUrl: string): Promise<void> {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) {
        return;
      }
    } catch {
      // Retry until backend is up.
    }

    await new Promise(resolve => setTimeout(resolve, 50));
  }

  throw new Error('Backend no inicio a tiempo');
}

const startedBackends: WhatauthBackend[] = [];

async function startBackend(options: Partial<ConstructorParameters<typeof WhatauthBackend>[0]> = {}) {
  const port = await getFreePort();

  const backend = new WhatauthBackend({
    port,
    host: '127.0.0.1',
    jwtSecret: 'test-jwt-secret',
    evolutionApiUrl: 'https://example.com',
    evolutionApiKey: 'test-api-key',
    evolutionInstanceName: 'test-instance',
    ...options
  });

  backend.start();
  startedBackends.push(backend);

  const baseUrl = `http://127.0.0.1:${port}`;
  await waitForHealth(baseUrl);

  return { backend, baseUrl };
}

afterEach(async () => {
  while (startedBackends.length > 0) {
    const backend = startedBackends.pop();
    if (backend) {
      await backend.stop();
    }
  }
});

describe('CamarauthBackend sprint 1 contracts', () => {
  it('registers pin even when emojiString is omitted', async () => {
    const { backend, baseUrl } = await startBackend();

    const response = await fetch(`${baseUrl}/register-pin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: 'ABC123' })
    });

    const body = await response.json();
    const storedPin = backend.getPins().get('ABC123');

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(storedPin?.emojiString).toBeTruthy();
  });

  it('refreshes token using refreshToken payload', async () => {
    const jwtSecret = 'refresh-secret';
    const { backend, baseUrl } = await startBackend({ jwtSecret });

    const refreshToken = jwt.sign({ sub: 'user-1' }, jwtSecret, { expiresIn: '1h' });
    (backend as any).sessions.set('user-1', {
      userData: {
        nombre: 'Test',
        apellidos: 'User',
        telefono: '3000000000',
        roles: ['user']
      },
      refreshToken,
      createdAt: Date.now()
    });

    const response = await fetch(`${baseUrl}/refresh-token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken })
    });

    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(typeof body.token).toBe('string');
    expect(body.refreshToken).toBe(refreshToken);
  });

  it('cleans active session on logout with userId payload', async () => {
    const { backend, baseUrl } = await startBackend();

    (backend as any).sessions.set('user-logout', {
      userData: { nombre: 'Logout User', roles: ['user'] },
      refreshToken: 'refresh-logout',
      createdAt: Date.now()
    });

    const response = await fetch(`${baseUrl}/logout`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: 'user-logout' })
    });

    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect((backend as any).sessions.has('user-logout')).toBe(false);
  });

  it('validates webhook signature when webhook secret is configured', async () => {
    const webhookSecret = 'webhook-secret';
    const { baseUrl } = await startBackend({ webhookSecret });

    const payload = {
      event: 'messages.upsert',
      instance: 'test-instance',
      data: {
        key: {
          remoteJid: '123456789@s.whatsapp.net',
          fromMe: false,
          id: 'msg-1'
        },
        pushName: 'Tester',
        message: {
          conversation: 'Hola mundo'
        }
      }
    };

    const rawPayload = JSON.stringify(payload);
    const signature = createHmac('sha256', webhookSecret)
      .update(rawPayload)
      .digest('hex');

    const validResponse = await fetch(`${baseUrl}/webhook/evolution`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-hub-signature-256': `sha256=${signature}`
      },
      body: rawPayload
    });

    expect(validResponse.status).toBe(200);

    const invalidResponse = await fetch(`${baseUrl}/webhook/evolution`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-hub-signature-256': 'sha256=deadbeef'
      },
      body: rawPayload
    });

    expect(invalidResponse.status).toBe(401);
  });

  it('fails fast in production when JWT_SECRET is missing', () => {
    const previousNodeEnv = process.env.NODE_ENV;
    const previousJwtSecret = process.env.JWT_SECRET;

    try {
      process.env.NODE_ENV = 'production';
      delete process.env.JWT_SECRET;

      expect(() => {
        const backend = new WhatauthBackend({
          evolutionApiUrl: 'https://example.com',
          evolutionApiKey: 'test-api-key',
          evolutionInstanceName: 'test-instance'
        });

        backend.stop();
      }).toThrow('JWT_SECRET es obligatorio en produccion');
    } finally {
      process.env.NODE_ENV = previousNodeEnv;
      if (previousJwtSecret !== undefined) {
        process.env.JWT_SECRET = previousJwtSecret;
      } else {
        delete process.env.JWT_SECRET;
      }
    }
  });

  it('generates temporary JWT secret in development when missing', async () => {
    const previousNodeEnv = process.env.NODE_ENV;
    const previousJwtSecret = process.env.JWT_SECRET;

    try {
      process.env.NODE_ENV = 'development';
      delete process.env.JWT_SECRET;

      const backend = new WhatauthBackend({
        evolutionApiUrl: 'https://example.com',
        evolutionApiKey: 'test-api-key',
        evolutionInstanceName: 'test-instance'
      });

      const generatedSecret = (backend as any).config.jwtSecret;
      expect(generatedSecret).toMatch(/^[a-f0-9]{64}$/i);

      await backend.stop();
    } finally {
      process.env.NODE_ENV = previousNodeEnv;
      if (previousJwtSecret !== undefined) {
        process.env.JWT_SECRET = previousJwtSecret;
      } else {
        delete process.env.JWT_SECRET;
      }
    }
  });
});
