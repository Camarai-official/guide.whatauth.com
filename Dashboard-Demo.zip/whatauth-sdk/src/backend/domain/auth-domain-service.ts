import { encodePinToEmojis } from '../../core/pin-generator';
import type { PinRepository } from '../repositories/pin-repository';
import { TokenService } from '../services/token-service';
import type { TokenUserData } from '../services/token-service';
import { WebhookService } from '../services/webhook-service';
import type {
  BackendErrorResponse,
  DatabaseAdapter,
  EvolutionMessage,
  EvolutionWebhookPayload,
  PinData,
} from '../types';
import { type User, mapDatabaseRowToUser } from '../models/user';
import type { TimeProvider } from '../time-provider';

// @deprecated Use User from '../models/user' instead
export type BackendUserData = User;

export interface SessionData {
  userData: User;
  refreshToken: string;
  createdAt: number;
}

export class DomainError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: Record<string, unknown>;
  readonly extraFields: Record<string, unknown>;

  constructor(config: {
    status: number;
    code: string;
    error: string;
    details?: Record<string, unknown>;
    extraFields?: Record<string, unknown>;
  }) {
    super(config.error);
    this.name = 'DomainError';
    this.status = config.status;
    this.code = config.code;
    this.details = config.details;
    this.extraFields = config.extraFields || {};
  }

  toResponseBody(): BackendErrorResponse & Record<string, unknown> {
    return {
      success: false,
      error: this.message,
      code: this.code,
      status: this.status,
      ...(this.details ? { details: this.details } : {}),
      ...this.extraFields
    };
  }
}

function domainError(config: {
  status: number;
  code: string;
  error: string;
  details?: Record<string, unknown>;
  extraFields?: Record<string, unknown>;
}): DomainError {
  return new DomainError(config);
}

export interface AuthDomainServiceConfig {
  pinRepository: PinRepository;
  tokenService: TokenService;
  webhookService: WebhookService;
  sessions: Map<string, SessionData>;
  db: DatabaseAdapter | null;
  pinExpirationMinutes: number;
  timeProvider?: TimeProvider;
}

export interface RegisterPinInput {
  pin?: string;
  emojiString?: string;
  socketId?: string;
}

export interface RegisterPinResult {
  pinData: PinData;
  expiresIn: number;
}

export interface RefreshTokenInput {
  refreshToken?: string | null;
  legacyAccessToken?: string | null;
}

export interface LogoutInput {
  userId?: string | null;
  authToken?: string | null;
}

export interface CleanupExpiredPinsResult {
  cleaned: number;
  expiredPins: Array<{ pin: string; socketId?: string }>;
}

export interface VerifiedMessageResult {
  kind: 'verified';
  pin: string;
  phoneNumber: string;
  userId: string;
  userData: User;
  socketId?: string;
  authResponse: {
    success: true;
    verified: true;
    token: string;
    refreshToken: string;
    user: User;
  };
}

export type ProcessIncomingMessageResult =
  | { kind: 'ignored'; rawText?: string }
  | { kind: 'unknown_pin'; pin: string; phoneNumber: string }
  | { kind: 'already_processed'; pin: string }
  | { kind: 'expired'; pin: string; socketId?: string }
  | VerifiedMessageResult;

interface SessionRefreshRow extends Record<string, unknown> {
  refresh_token?: string;
}

interface RoleNameRow extends Record<string, unknown> {
  nombre: string;
}

export class AuthDomainService {
  private readonly pinRepository: PinRepository;
  private readonly tokenService: TokenService;
  private readonly webhookService: WebhookService;
  private readonly sessions: Map<string, SessionData>;
  private readonly db: DatabaseAdapter | null;
  private readonly pinExpirationMinutes: number;
  private readonly timeProvider: TimeProvider;

  constructor(config: AuthDomainServiceConfig) {
    this.pinRepository = config.pinRepository;
    this.tokenService = config.tokenService;
    this.webhookService = config.webhookService;
    this.sessions = config.sessions;
    this.db = config.db;
    this.pinExpirationMinutes = config.pinExpirationMinutes;
    this.timeProvider = config.timeProvider || { now: () => Date.now() };
  }

  async countPins(): Promise<number> {
    return this.pinRepository.count();
  }

  getDebugPinsMap(): Map<string, PinData> {
    if (this.pinRepository.toDebugMap) {
      return this.pinRepository.toDebugMap();
    }

    return new Map<string, PinData>();
  }

  shouldProcessWebhookPayload(payload: EvolutionWebhookPayload, expectedInstance: string): boolean {
    return this.webhookService.shouldProcessPayload(payload, expectedInstance);
  }

  async registerPin(input: RegisterPinInput): Promise<RegisterPinResult> {
    const pin = typeof input.pin === 'string' ? input.pin.trim() : '';
    if (!pin) {
      throw domainError({
        status: 400,
        code: 'PIN_REQUIRED',
        error: 'PIN es requerido',
        details: { field: 'pin' }
      });
    }

    const resolvedEmojiString =
      typeof input.emojiString === 'string' && input.emojiString.trim().length > 0
        ? input.emojiString
        : encodePinToEmojis(pin).join('');

    const now = this.timeProvider.now();
    const pinData: PinData = {
      id: Math.random().toString(36).substring(2, 15),
      pin,
      emojiString: resolvedEmojiString,
      status: 'pending',
      socketId: input.socketId,
      expiresAt: now + this.pinExpirationMinutes * 60 * 1000,
      createdAt: now
    };

    await this.pinRepository.save(pinData);

    return {
      pinData,
      expiresIn: this.pinExpirationMinutes * 60
    };
  }

  async checkLogin(pinInput?: string): Promise<Record<string, unknown>> {
    const pin = typeof pinInput === 'string' ? pinInput.trim() : '';
    if (!pin) {
      throw domainError({
        status: 400,
        code: 'PIN_REQUIRED',
        error: 'PIN es requerido',
        details: { field: 'pin' }
      });
    }

    const pinData = await this.pinRepository.findByPin(pin);
    if (!pinData) {
      throw domainError({
        status: 404,
        code: 'PIN_NOT_FOUND',
        error: 'PIN no encontrado',
        details: { pin },
        extraFields: { verified: false }
      });
    }

    if (this.timeProvider.now() > pinData.expiresAt) {
      await this.pinRepository.removeByPin(pin);
      throw domainError({
        status: 410,
        code: 'PIN_EXPIRED',
        error: 'PIN expirado',
        details: { pin },
        extraFields: { verified: false }
      });
    }

    if (pinData.status !== 'verified') {
      return {
        success: true,
        verified: false,
        message: 'Login pendiente'
      };
    }

    return {
      success: true,
      verified: true,
      token: pinData.accessToken,
      refreshToken: pinData.refreshToken,
      user: pinData.userData
    };
  }

  async refreshToken(input: RefreshTokenInput): Promise<Record<string, unknown>> {
    const bodyRefreshToken = input.refreshToken || null;
    const legacyAccessToken = input.legacyAccessToken || null;

    if (!bodyRefreshToken && !legacyAccessToken) {
      throw domainError({
        status: 400,
        code: 'INVALID_REQUEST',
        error: 'Peticion invalida',
        details: { required: ['refreshToken or bearer token'] }
      });
    }

    let userId: string | null = null;
    let session: { userData: User; refreshToken: string } | null = null;

    if (bodyRefreshToken) {
      try {
        const decodedRefreshToken = this.tokenService.verifyRefreshToken(bodyRefreshToken);
        userId = typeof decodedRefreshToken.sub === 'string' ? decodedRefreshToken.sub : null;
      } catch {
        throw domainError({
          status: 401,
          code: 'SESSION_EXPIRED',
          error: 'Refresh token invalido o expirado'
        });
      }

      if (!userId) {
        throw domainError({
          status: 401,
          code: 'UNAUTHORIZED',
          error: 'Refresh token invalido'
        });
      }

      session = await this.findSessionByUserId(userId);
      if (!session || session.refreshToken !== bodyRefreshToken) {
        throw domainError({
          status: 401,
          code: 'REFRESH_TOKEN_MISMATCH',
          error: 'Refresh token no coincide con la sesion activa',
          details: { userId }
        });
      }
    } else {
      userId = this.tokenService.resolveSubjectFromAccessToken(legacyAccessToken!);

      if (!userId) {
        throw domainError({
          status: 401,
          code: 'UNAUTHORIZED',
          error: 'No se pudo decodificar el token legado'
        });
      }

      session = await this.findSessionByUserId(userId);
      if (!session) {
        throw domainError({
          status: 401,
          code: 'SESSION_NOT_FOUND',
          error: 'Usuario no encontrado o sin sesion activa',
          details: { userId }
        });
      }

      try {
        this.tokenService.verifyRefreshToken(session.refreshToken);
      } catch {
        throw domainError({
          status: 401,
          code: 'SESSION_EXPIRED',
          error: 'El refresh token es invalido o ha expirado'
        });
      }
    }

    if (!userId || !session) {
      throw domainError({
        status: 401,
        code: 'SESSION_NOT_FOUND',
        error: 'Sesion no encontrada'
      });
    }

    const newToken = this.tokenService.issueAccessToken(userId, session.userData);
    return {
      success: true,
      token: newToken,
      refreshToken: session.refreshToken
    };
  }

  getProfile(token: string | null): Record<string, unknown> {
    if (!token) {
      throw domainError({
        status: 401,
        code: 'TOKEN_NOT_PROVIDED',
        error: 'No token provided'
      });
    }

    try {
      const decoded = this.tokenService.verifyAccessToken(token);
      return {
        success: true,
        user: {
          id: decoded.sub,
          ...decoded.user
        }
      };
    } catch {
      throw domainError({
        status: 401,
        code: 'INVALID_TOKEN',
        error: 'Invalid token'
      });
    }
  }

  async logout(input: LogoutInput): Promise<Record<string, unknown>> {
    let userId = typeof input.userId === 'string' && input.userId.length > 0 ? input.userId : null;

    if (!userId && input.authToken) {
      userId = this.tokenService.resolveSubjectFromAccessToken(input.authToken);
    }

    if (userId) {
      this.sessions.delete(userId);
    }

    if (this.db && userId) {
      await this.db.query(
        `UPDATE user_session SET refresh_token = null, isactive = false 
         WHERE user_id = $1 AND isactive = true`,
        [userId]
      );
    }

    return { success: true, message: 'Logout exitoso' };
  }

  async cancelPin(pinInput?: string, socketId?: string): Promise<boolean> {
    const pin = typeof pinInput === 'string' ? pinInput.trim() : '';
    if (!pin) {
      return false;
    }

    const pinData = await this.pinRepository.findByPin(pin);
    if (!pinData) {
      return false;
    }

    if (socketId && pinData.socketId !== socketId) {
      return false;
    }

    return this.pinRepository.removeByPin(pin);
  }

  async cleanupPinsBySocket(socketId: string): Promise<string[]> {
    const pinEntries = await this.pinRepository.listEntries();
    const removedPins: string[] = [];

    for (const [pin, pinData] of pinEntries) {
      if (pinData.socketId === socketId && pinData.status === 'pending') {
        await this.pinRepository.removeByPin(pin);
        removedPins.push(pin);
      }
    }

    return removedPins;
  }

  async cleanupExpiredPins(now = Date.now()): Promise<CleanupExpiredPinsResult> {
    const pinEntries = await this.pinRepository.listEntries();
    const expiredPins: Array<{ pin: string; socketId?: string }> = [];

    for (const [pin, pinData] of pinEntries) {
      if (now > pinData.expiresAt && pinData.status === 'pending') {
        await this.pinRepository.removeByPin(pin);
        expiredPins.push({ pin, socketId: pinData.socketId });
      }
    }

    return {
      cleaned: expiredPins.length,
      expiredPins
    };
  }

  async processIncomingMessage(message: EvolutionMessage): Promise<ProcessIncomingMessageResult> {
    const parsedWebhookPin = this.webhookService.decodePinFromMessage(message);
    if (!parsedWebhookPin) {
      const rawText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
      return {
        kind: 'ignored',
        rawText: rawText || undefined
      };
    }

    const { phoneNumber, pin, pushName } = parsedWebhookPin;
    const pinData = await this.pinRepository.findByPin(pin);

    if (!pinData) {
      return {
        kind: 'unknown_pin',
        pin,
        phoneNumber
      };
    }

    if (pinData.status !== 'pending') {
      return {
        kind: 'already_processed',
        pin
      };
    }

    if (Date.now() > pinData.expiresAt) {
      await this.pinRepository.removeByPin(pin);
      return {
        kind: 'expired',
        pin,
        socketId: pinData.socketId
      };
    }

    return this.verifyPin(pinData, phoneNumber, pushName);
  }

  private async verifyPin(
    pinData: PinData,
    phoneNumber: string,
    pushName: string
  ): Promise<VerifiedMessageResult> {
    pinData.status = 'verified';
    pinData.phoneNumber = phoneNumber;
    pinData.userId = `user_${phoneNumber}`;

    let userData: User = {
      id: pinData.userId,
      nombre: pushName,
      apellidos: '',
      telefono: phoneNumber,
      email: '',
      foto: null,
      roles: ['user']
    };

    if (this.db) {
      try {
        const result = await this.db.query<Record<string, unknown>>(
          'SELECT * FROM usuarios WHERE telefono = $1',
          [phoneNumber]
        );

        if (result.rows.length > 0) {
          userData = mapDatabaseRowToUser(result.rows[0] as Record<string, unknown>);
        } else {
          const insertResult = await this.db.query<Record<string, unknown>>(
            `INSERT INTO usuarios (nombre, telefono, estado) 
             VALUES ($1, $2, 'activo') RETURNING *`,
            [pushName, phoneNumber]
          );
          userData = mapDatabaseRowToUser(insertResult.rows[0] as Record<string, unknown>);
        }

        const rolesResult = await this.db.query<RoleNameRow>(
          `SELECT r.nombre FROM roles_usuarios ru 
           JOIN roles r ON ru.rol_id = r.id 
           WHERE ru.usuario_id = $1 AND ru.status = 'activo'`,
          [String(userData.id)]
        );

        if (rolesResult.rows.length > 0) {
          userData.roles = rolesResult.rows.map((row: { nombre: string }) => row.nombre);
        }

        pinData.userId = String(userData.id);
      } catch (dbError) {
        console.error('[Backend] Error DB:', dbError);
      }
    }

    const userId = String(pinData.userId);
    const { token, refreshToken } = this.tokenService.issueTokens(userId, userData);

    pinData.accessToken = token;
    pinData.refreshToken = refreshToken;
    pinData.userData = userData;
    await this.pinRepository.save(pinData);

    this.sessions.set(userId, {
      userData,
      refreshToken,
      createdAt: Date.now()
    });

    if (this.db) {
      try {
        await this.db.query(
          `UPDATE verification_codes 
           SET status = 'verificado', phone_number = $1 
           WHERE code = $2`,
          [phoneNumber, pinData.pin]
        );

        await this.db.query(
          `INSERT INTO user_session (user_id, refresh_token, isactive) 
           VALUES ($1, $2, true)
           ON CONFLICT (user_id) DO UPDATE 
           SET refresh_token = $2, isactive = true`,
          [userId, refreshToken]
        );
      } catch (dbError) {
        console.error('[Backend] Error guardando en DB:', dbError);
      }
    }

    setTimeout(() => {
      void this.pinRepository.removeByPin(pinData.pin);
    }, 5000);

    return {
      kind: 'verified',
      pin: pinData.pin,
      phoneNumber,
      userId,
      userData,
      socketId: pinData.socketId,
      authResponse: {
        success: true,
        verified: true,
        token,
        refreshToken,
        user: userData
      }
    };
  }

  private async findSessionByUserId(
    userId: string
  ): Promise<{ userData: User; refreshToken: string } | null> {
    if (this.db) {
      try {
        const result = await this.db.query<SessionRefreshRow>(
          `SELECT u.*, us.refresh_token
           FROM usuarios u
           LEFT JOIN user_session us ON us.user_id = u.id
           WHERE u.id = $1 AND us.refresh_token IS NOT NULL`,
          [userId]
        );

        if (result.rows.length > 0 && result.rows[0].refresh_token) {
          return {
            userData: mapDatabaseRowToUser(result.rows[0] as Record<string, unknown>),
            refreshToken: String(result.rows[0].refresh_token)
          };
        }
      } catch (dbError) {
        console.error('[Backend] Error DB:', dbError);
        return null;
      }
    }

    const session = this.sessions.get(userId);
    if (session) {
      return {
        userData: session.userData,
        refreshToken: session.refreshToken
      };
    }

    const pinData = await this.pinRepository.findByUserId(userId);
    if (pinData?.refreshToken && pinData.userData) {
      return {
        userData: mapDatabaseRowToUser(pinData.userData as Record<string, unknown>),
        refreshToken: pinData.refreshToken
      };
    }

    return null;
  }
}
