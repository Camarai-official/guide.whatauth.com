import { createServer } from 'net';
import { afterEach, describe, expect, it } from 'vitest';
import { encodePinToEmojis } from '../core/pin-generator';
import { CamarauthSocketClient } from '../core/socket-client';
import { CamarauthBackend } from './index';

async function getFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') {
        server.close();
        reject(new Error('No se pudo obtener puerto libre'));
        return;
      }

      server.close(() => resolve(address.port));
    });
  });
}

async function waitForHealth(baseUrl: string): Promise<void> {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) {
        return;
      }
    } catch {
      // Retry until backend is up.
    }

    await new Promise(resolve => setTimeout(resolve, 50));
  }

  throw new Error('Backend no inicio a tiempo');
}

const startedBackends: CamarauthBackend[] = [];

async function startBackend() {
  const port = await getFreePort();
  const backend = new CamarauthBackend({
    port,
    host: '127.0.0.1',
    jwtSecret: 'transport-integration-secret',
    evolutionApiUrl: 'https://example.com',
    evolutionApiKey: 'test-api-key',
    evolutionInstanceName: 'test-instance',
    rateLimit: { enabled: false }
  });

  backend.start();
  startedBackends.push(backend);

  const baseUrl = `http://127.0.0.1:${port}`;
  await waitForHealth(baseUrl);

  return { backend, baseUrl };
}

afterEach(async () => {
  while (startedBackends.length > 0) {
    const backend = startedBackends.pop();
    if (backend) {
      await backend.stop();
    }
  }
});

describe('Backend transport integration', () => {
  it('keeps websocket and http views in sync for pin lifecycle', async () => {
    const { baseUrl } = await startBackend();
    const socketClient = new CamarauthSocketClient({ apiUrl: baseUrl });
    const pin = 'WS9900';

    await socketClient.connect();
    await socketClient.registerPin(pin, encodePinToEmojis(pin).join(''));

    const pendingResponse = await fetch(`${baseUrl}/check-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin })
    });
    const pendingBody = await pendingResponse.json();

    expect(pendingResponse.status).toBe(200);
    expect(pendingBody.verified).toBe(false);

    socketClient.cancelAuth(pin);
    await new Promise(resolve => setTimeout(resolve, 25));

    const cancelledResponse = await fetch(`${baseUrl}/check-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin })
    });

    expect(cancelledResponse.status).toBe(404);
    socketClient.disconnect();
  });

  it('processes webhook route and exposes verified login via http', async () => {
    const { baseUrl } = await startBackend();
    const pin = 'HTTP11';
    const emojiString = encodePinToEmojis(pin).join('');

    const registerResponse = await fetch(`${baseUrl}/register-pin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin })
    });

    expect(registerResponse.status).toBe(200);

    const webhookResponse = await fetch(`${baseUrl}/webhook/evolution`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: 'messages.upsert',
        instance: 'test-instance',
        data: {
          key: {
            remoteJid: '34600000000@s.whatsapp.net',
            fromMe: false,
            id: 'transport-msg-1'
          },
          pushName: 'Transport User',
          message: {
            conversation: `PIN: ${emojiString}`
          }
        }
      })
    });

    expect(webhookResponse.status).toBe(200);

    const checkResponse = await fetch(`${baseUrl}/check-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin })
    });
    const checkBody = await checkResponse.json();

    expect(checkResponse.status).toBe(200);
    expect(checkBody.verified).toBe(true);
    expect(typeof checkBody.token).toBe('string');
    expect(typeof checkBody.refreshToken).toBe('string');
  });
});
