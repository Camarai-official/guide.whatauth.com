import jwt from 'jsonwebtoken';
import { describe, expect, it } from 'vitest';
import { TokenService } from './token-service';

describe('TokenService', () => {
  const tokenService = new TokenService({
    jwtSecret: 'token-service-secret',
    accessTokenExpiresIn: '15m',
    refreshTokenExpiresIn: '7d'
  });

  it('issues access and refresh tokens with aligned claims', () => {
    const { token, refreshToken } = tokenService.issueTokens('user-1', {
      nombre: 'Ada',
      apellidos: 'Lovelace',
      telefono: '3000000000',
      roles: ['admin']
    });

    const decodedAccessToken = tokenService.verifyAccessToken(token);
    const decodedRefreshToken = tokenService.verifyRefreshToken(refreshToken);

    expect(decodedAccessToken.sub).toBe('user-1');
    expect((decodedAccessToken.user as { nombre: string }).nombre).toBe('Ada');
    expect((decodedAccessToken.user as { roles: string[] }).roles).toEqual(['admin']);
    expect(decodedRefreshToken.sub).toBe('user-1');
  });

  it('resolves subject from expired access token using decode fallback', async () => {
    const shortLivedTokenService = new TokenService({
      jwtSecret: 'short-lived-secret',
      accessTokenExpiresIn: '1ms'
    });

    const token = shortLivedTokenService.issueAccessToken('user-expired', { nombre: 'Expired' });
    await new Promise(resolve => setTimeout(resolve, 10));

    const resolvedSubject = shortLivedTokenService.resolveSubjectFromAccessToken(token);
    expect(resolvedSubject).toBe('user-expired');
  });

  it('refreshes access token from a valid refresh token', () => {
    const refreshToken = jwt.sign({ sub: 'user-99' }, 'token-service-secret', { expiresIn: '7d' });

    const refreshed = tokenService.refreshAccessToken(refreshToken, {
      nombre: 'Refresh User',
      roles: ['user']
    });

    const decoded = tokenService.verifyAccessToken(refreshed.token);

    expect(refreshed.userId).toBe('user-99');
    expect(refreshed.refreshToken).toBe(refreshToken);
    expect(decoded.sub).toBe('user-99');
    expect((decoded.user as { nombre: string }).nombre).toBe('Refresh User');
  });
});
