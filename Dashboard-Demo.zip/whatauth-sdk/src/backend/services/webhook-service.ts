import { decodeEmojiChunk, decodeEmojisFull } from '../../core/emoji-encoder';
import type { EvolutionMessage, EvolutionWebhookPayload } from '../types';

export interface ParsedWebhookPin {
  phoneNumber: string;
  pushName: string;
  pin: string;
  rawText: string;
}

export class WebhookService {
  shouldProcessPayload(payload: EvolutionWebhookPayload, expectedInstance: string): boolean {
    if (payload.instance !== expectedInstance) {
      return false;
    }

    if (payload.event !== 'messages.upsert') {
      return false;
    }

    return this.getMessageText(payload.data).length > 0;
  }

  decodePinFromPayload(payload: EvolutionWebhookPayload, expectedInstance: string): ParsedWebhookPin | null {
    if (!this.shouldProcessPayload(payload, expectedInstance)) {
      return null;
    }

    return this.decodePinFromMessage(payload.data);
  }

  decodePinFromMessage(message: EvolutionMessage): ParsedWebhookPin | null {
    const phoneNumber = this.getPhoneNumber(message);
    const rawText = this.getMessageText(message);

    if (!phoneNumber || !rawText) {
      return null;
    }

    const pin = this.decodePinFromText(rawText);
    if (!pin) {
      return null;
    }

    return {
      phoneNumber,
      pushName: message.pushName || 'Usuario',
      pin,
      rawText
    };
  }

  decodePinFromText(text: string): string | null {
    const pinMatch = text.match(/PIN[:\s]*(.+)/i);
    if (!pinMatch) {
      return null;
    }

    const encodedPin = pinMatch[1].trim();
    if (!encodedPin) {
      return null;
    }

    const decodedFullPin = decodeEmojisFull(encodedPin).trim();
    if (decodedFullPin) {
      return decodedFullPin;
    }

    const decodedChunkPin = decodeEmojiChunk(encodedPin)?.trim();
    return decodedChunkPin || null;
  }

  private getPhoneNumber(message: EvolutionMessage): string | null {
    return message.key?.remoteJid?.split('@')[0] || null;
  }

  private getMessageText(message: EvolutionMessage): string {
    return message.message?.conversation || message.message?.extendedTextMessage?.text || '';
  }
}
