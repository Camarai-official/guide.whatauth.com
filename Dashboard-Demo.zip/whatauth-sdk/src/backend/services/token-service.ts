import jwt from 'jsonwebtoken';

export interface TokenServiceConfig {
  jwtSecret: string;
  accessTokenExpiresIn?: jwt.SignOptions['expiresIn'];
  refreshTokenExpiresIn?: jwt.SignOptions['expiresIn'];
}

export interface TokenUserData {
  nombre?: string;
  apellidos?: string;
  telefono?: string;
  roles?: string[];
  [key: string]: unknown;
}

export interface TokenPair {
  token: string;
  refreshToken: string;
}

export class TokenService {
  private readonly jwtSecret: string;
  private readonly accessTokenExpiresIn: jwt.SignOptions['expiresIn'];
  private readonly refreshTokenExpiresIn: jwt.SignOptions['expiresIn'];

  constructor(config: TokenServiceConfig) {
    this.jwtSecret = config.jwtSecret;
    this.accessTokenExpiresIn = config.accessTokenExpiresIn ?? '15m';
    this.refreshTokenExpiresIn = config.refreshTokenExpiresIn ?? '7d';
  }

  issueAccessToken(userId: string, userData: TokenUserData): string {
    return jwt.sign(
      {
        sub: userId,
        user: this.buildUserClaims(userData)
      },
      this.jwtSecret,
      { expiresIn: this.accessTokenExpiresIn }
    );
  }

  issueRefreshToken(userId: string): string {
    return jwt.sign(
      { sub: userId },
      this.jwtSecret,
      { expiresIn: this.refreshTokenExpiresIn }
    );
  }

  issueTokens(userId: string, userData: TokenUserData): TokenPair {
    return {
      token: this.issueAccessToken(userId, userData),
      refreshToken: this.issueRefreshToken(userId)
    };
  }

  verifyAccessToken(token: string): jwt.JwtPayload {
    return this.verifyToken(token);
  }

  verifyRefreshToken(refreshToken: string): jwt.JwtPayload {
    return this.verifyToken(refreshToken);
  }

  decodeToken(token: string): jwt.JwtPayload | null {
    const decoded = jwt.decode(token);
    if (!decoded || typeof decoded === 'string') {
      return null;
    }

    return decoded;
  }

  resolveSubjectFromAccessToken(accessToken: string): string | null {
    try {
      const verified = this.verifyAccessToken(accessToken);
      return typeof verified.sub === 'string' ? verified.sub : null;
    } catch {
      const decoded = this.decodeToken(accessToken);
      return decoded && typeof decoded.sub === 'string' ? decoded.sub : null;
    }
  }

  refreshAccessToken(refreshToken: string, userData: TokenUserData): TokenPair & { userId: string } {
    const verifiedRefreshToken = this.verifyRefreshToken(refreshToken);
    const userId = typeof verifiedRefreshToken.sub === 'string' ? verifiedRefreshToken.sub : null;

    if (!userId) {
      throw new Error('Refresh token invalido');
    }

    return {
      userId,
      token: this.issueAccessToken(userId, userData),
      refreshToken
    };
  }

  private verifyToken(token: string): jwt.JwtPayload {
    const verified = jwt.verify(token, this.jwtSecret);
    if (typeof verified === 'string') {
      throw new Error('Token invalido');
    }

    return verified;
  }

  private buildUserClaims(userData: TokenUserData) {
    return {
      nombre: userData.nombre,
      apellidos: userData.apellidos,
      telefono: userData.telefono,
      roles: userData.roles || ['user']
    };
  }
}
