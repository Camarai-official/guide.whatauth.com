import { describe, expect, it } from 'vitest';
import { encodePinToEmojis } from '../../core/pin-generator';
import type { EvolutionWebhookPayload } from '../types';
import { WebhookService } from './webhook-service';

describe('WebhookService', () => {
  const webhookService = new WebhookService();

  it('decodes pin from provider payload and extracts phone/user', () => {
    const pin = 'ABC123';
    const emojiString = encodePinToEmojis(pin).join('');

    const payload: EvolutionWebhookPayload = {
      event: 'messages.upsert',
      instance: 'test-instance',
      data: {
        key: {
          remoteJid: '34600000000@s.whatsapp.net',
          fromMe: false,
          id: 'msg-1'
        },
        pushName: 'Webhook User',
        message: {
          conversation: `PIN: ${emojiString}`
        }
      }
    };

    const parsed = webhookService.decodePinFromPayload(payload, 'test-instance');

    expect(parsed).not.toBeNull();
    expect(parsed?.pin).toBe(pin);
    expect(parsed?.phoneNumber).toBe('34600000000');
    expect(parsed?.pushName).toBe('Webhook User');
  });

  it('ignores payloads from other instances or unsupported events', () => {
    const payload: EvolutionWebhookPayload = {
      event: 'messages.update',
      instance: 'other-instance',
      data: {
        key: {
          remoteJid: '34600000000@s.whatsapp.net',
          fromMe: false,
          id: 'msg-2'
        },
        pushName: 'Ignored User',
        message: {
          conversation: 'PIN: cualquiera'
        }
      }
    };

    const parsed = webhookService.decodePinFromPayload(payload, 'test-instance');
    expect(parsed).toBeNull();
  });

  it('returns null when text has no PIN format', () => {
    const decoded = webhookService.decodePinFromText('Hola, esto no es un pin');
    expect(decoded).toBeNull();
  });
});
