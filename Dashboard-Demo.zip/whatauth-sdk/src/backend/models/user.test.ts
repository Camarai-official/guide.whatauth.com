import { describe, it, expect } from 'vitest';
import {
  mapDatabaseRowToUser,
  userToTokenClaims,
  tokenClaimsToUser,
  normalizeCreateUserData,
  isValidUser,
  type User,
  type DatabaseUserRow
} from './user';

describe('SDK-019: Unified User Model', () => {
  describe('mapDatabaseRowToUser', () => {
    it('should map a complete PostgreSQL row to User', () => {
      const row: DatabaseUserRow = {
        id: 123,
        nombre: 'Juan',
        apellidos: 'Pérez',
        telefono: '+34600123456',
        email: 'juan@example.com',
        foto: 'https://example.com/avatar.jpg',
        estado: 'activo',
        roles: ['user', 'admin']
      };

      const user = mapDatabaseRowToUser(row);

      expect(user).toMatchObject({
        id: '123',
        nombre: 'Juan',
        apellidos: 'Pérez',
        telefono: '+34600123456',
        email: 'juan@example.com',
        foto: 'https://example.com/avatar.jpg',
        estado: 'activo',
        roles: ['user', 'admin']
      });

      // Verificar aliases en inglés
      expect(user.name).toBe('Juan');
      expect(user.firstName).toBe('Juan');
      expect(user.lastName).toBe('Pérez');
      expect(user.phone).toBe('+34600123456');
      expect(user.avatar).toBe('https://example.com/avatar.jpg');
    });

    it('should handle snake_case column names', () => {
      const row: DatabaseUserRow = {
        id: 456,
        first_name: 'María',
        last_name: 'García',
        phone_number: '+34600987654',
        email: 'maria@example.com',
        status: 'active'
      };

      const user = mapDatabaseRowToUser(row);

      expect(user.nombre).toBe('María');
      expect(user.apellidos).toBe('García');
      expect(user.telefono).toBe('+34600987654');
    });

    it('should provide default values for missing fields', () => {
      const row: DatabaseUserRow = {
        id: 789,
        nombre: 'Test'
      };

      const user = mapDatabaseRowToUser(row);

      expect(user.id).toBe('789');
      expect(user.nombre).toBe('Test');
      expect(user.apellidos).toBe('');
      expect(user.telefono).toBe('');
      expect(user.email).toBe('');
      expect(user.foto).toBeNull();
      expect(user.roles).toEqual(['user']);
    });

    it('should handle string id', () => {
      const row: DatabaseUserRow = {
        id: 'user-abc-123',
        nombre: 'Pedro',
        telefono: '+34123456789'
      };

      const user = mapDatabaseRowToUser(row);

      expect(user.id).toBe('user-abc-123');
    });

    it('should extract single role from role field', () => {
      const row: DatabaseUserRow = {
        id: 1,
        nombre: 'Admin',
        role: 'admin'
      };

      const user = mapDatabaseRowToUser(row);

      expect(user.roles).toEqual(['admin']);
    });

    it('should throw for null/undefined row', () => {
      expect(() => mapDatabaseRowToUser(null as unknown as DatabaseUserRow)).toThrow();
      expect(() => mapDatabaseRowToUser(undefined as unknown as DatabaseUserRow)).toThrow();
    });
  });

  describe('userToTokenClaims', () => {
    it('should convert User to token claims', () => {
      const user: User = {
        id: '123',
        nombre: 'Juan',
        apellidos: 'Pérez',
        telefono: '+34600123456',
        email: 'juan@example.com',
        foto: null,
        roles: ['user', 'admin']
      };

      const claims = userToTokenClaims(user);

      expect(claims).toEqual({
        nombre: 'Juan',
        apellidos: 'Pérez',
        telefono: '+34600123456',
        roles: ['user', 'admin']
      });
    });

    it('should handle missing optional fields', () => {
      const user: User = {
        id: '456',
        nombre: 'María',
        telefono: '+34600987654',
        roles: ['user']
      };

      const claims = userToTokenClaims(user);

      expect(claims.nombre).toBe('María');
      expect(claims.apellidos).toBeUndefined();
      expect(claims.telefono).toBe('+34600987654');
    });
  });

  describe('tokenClaimsToUser', () => {
    it('should reconstruct User from valid JWT payload', () => {
      const payload = {
        sub: 'user-123',
        user: {
          nombre: 'Juan',
          apellidos: 'Pérez',
          telefono: '+34600123456',
          roles: ['user']
        }
      };

      const user = tokenClaimsToUser(payload);

      expect(user).not.toBeNull();
      expect(user?.id).toBe('user-123');
      expect(user?.nombre).toBe('Juan');
      expect(user?.roles).toEqual(['user']);
    });

    it('should return null for invalid payload', () => {
      expect(tokenClaimsToUser({})).toBeNull();
      expect(tokenClaimsToUser({ sub: '123' })).toBeNull();
      expect(tokenClaimsToUser({ user: {} })).toBeNull();
    });
  });

  describe('normalizeCreateUserData', () => {
    it('should return complete CreateUserData with defaults', () => {
      const data = { nombre: 'Test' };
      
      const result = normalizeCreateUserData(data);

      expect(result).toEqual({
        nombre: 'Test',
        telefono: '',
        apellidos: undefined,
        email: undefined,
        foto: null,
        roles: ['user']
      });
    });

    it('should preserve provided values with defaults', () => {
      const data = {
        nombre: 'Juan',
        telefono: '+34600123456',
        apellidos: 'Pérez',
        email: 'juan@example.com',
        roles: ['admin']
      };

      const result = normalizeCreateUserData(data);

      expect(result).toEqual({
        ...data,
        foto: null // Valor por defecto
      });
    });
  });

  describe('isValidUser', () => {
    it('should return true for valid User', () => {
      const user: User = {
        id: '123',
        nombre: 'Juan',
        telefono: '+34600123456',
        roles: ['user']
      };

      expect(isValidUser(user)).toBe(true);
    });

    it('should return true with name/phone aliases', () => {
      const user = {
        id: '123',
        name: 'Juan',
        phone: '+34600123456',
        roles: ['user']
      };

      expect(isValidUser(user)).toBe(true);
    });

    it('should return false for invalid objects', () => {
      expect(isValidUser(null)).toBe(false);
      expect(isValidUser(undefined)).toBe(false);
      expect(isValidUser('string')).toBe(false);
      expect(isValidUser(123)).toBe(false);
      expect(isValidUser({})).toBe(false);
      expect(isValidUser({ id: '123' })).toBe(false);
      expect(isValidUser({ nombre: 'Juan' })).toBe(false);
    });
  });

  describe('backend->frontend serialization', () => {
    it('should serialize User for frontend correctly', () => {
      const backendUser: User = {
        id: '42',
        nombre: 'Carlos',
        apellidos: 'López',
        telefono: '+34611222333',
        email: 'carlos@example.com',
        foto: 'https://example.com/photo.jpg',
        estado: 'activo',
        roles: ['user', 'manager']
      };

      // Simular serialización JSON (como en una respuesta HTTP)
      const serialized = JSON.stringify(backendUser);
      const frontendUser = JSON.parse(serialized) as User;

      // Verificar que todos los campos principales se preservan
      expect(frontendUser.id).toBe('42');
      expect(frontendUser.nombre).toBe('Carlos');
      expect(frontendUser.apellidos).toBe('López');
      expect(frontendUser.telefono).toBe('+34611222333');
      expect(frontendUser.email).toBe('carlos@example.com');
      expect(frontendUser.foto).toBe('https://example.com/photo.jpg');
      expect(frontendUser.estado).toBe('activo');
      expect(frontendUser.roles).toEqual(['user', 'manager']);
      
      // Nota: Los alias (name, phone, avatar) no se serializan porque
      // son duplicados de los campos principales. Están disponibles
      // en tiempo de desarrollo via TypeScript type checking.
    });
  });
});
