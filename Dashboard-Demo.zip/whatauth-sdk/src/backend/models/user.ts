/**
 * Unified User Model - SDK-019
 * 
 * Este archivo define el modelo de usuario unificado para todo el SDK.
 * Campos principales en español (para compatibilidad con DB existente)
 * con aliases en inglés para conveniencia.
 */

export interface User {
  /** ID único del usuario */
  id: string;
  
  /** Nombre del usuario (campo principal en español) */
  nombre: string;
  
  /** Alias en inglés para 'nombre' */
  name?: string;
  
  /** Apellidos del usuario */
  apellidos?: string;
  
  /** Alias en inglés para 'apellidos' */
  lastName?: string;
  firstName?: string; // Compatibilidad con campo 'nombre'
  
  /** Número de teléfono (formato internacional) */
  telefono: string;
  
  /** Alias en inglés para 'telefono' */
  phone?: string;
  
  /** Email del usuario (opcional) */
  email?: string;
  
  /** Foto/avatar del usuario (URL o null) */
  foto?: string | null;
  
  /** Alias en inglés para 'foto' */
  avatar?: string | null;
  
  /** Roles del usuario (por defecto ['user']) */
  roles: string[];
  
  /** Estado del usuario en la base de datos (activo/inactivo) */
  estado?: string;
  
  /** Campo libre para datos adicionales */
  [key: string]: unknown;
}

/**
 * Datos necesarios para crear un nuevo usuario
 */
export interface CreateUserData {
  nombre: string;
  telefono: string;
  apellidos?: string;
  email?: string;
  foto?: string | null;
  roles?: string[];
}

/**
 * Row de base de datos típico (campos en snake_case o camelCase)
 */
export interface DatabaseUserRow {
  id?: number | string;
  nombre?: string;
  first_name?: string;
  apellidos?: string;
  last_name?: string;
  telefono?: string;
  phone?: string;
  phone_number?: string;
  email?: string;
  foto?: string | null;
  avatar?: string | null;
  estado?: string;
  status?: string;
  roles?: string[];
  role?: string;
  created_at?: Date | string;
  updated_at?: Date | string;
  [key: string]: unknown;
}

/**
 * Mapea una fila de base de datos a un objeto User unificado
 * 
 * @param row - Fila de base de datos (puede venir de PostgreSQL, MySQL, MongoDB, etc.)
 * @returns User con campos normalizados
 */
export function mapDatabaseRowToUser(row: DatabaseUserRow): User {
  if (!row) {
    throw new Error('Cannot map null/undefined database row to User');
  }

  const id = String(row.id ?? '');
  const nombre = row.nombre || row.first_name || '';
  const apellidos = row.apellidos || row.last_name || '';
  const telefono = row.telefono || row.phone || row.phone_number || '';
  const email = row.email || '';
  const foto = row.foto ?? row.avatar ?? null;
  const estado = row.estado || row.status || 'activo';
  
  // Extraer roles: puede ser un array o un string único
  let roles: string[] = ['user'];
  if (Array.isArray(row.roles)) {
    roles = row.roles;
  } else if (row.roles) {
    roles = [String(row.roles)];
  } else if (row.role) {
    roles = [String(row.role)];
  }

  return {
    id,
    nombre,
    apellidos,
    telefono,
    email,
    foto,
    estado,
    roles,
    // Alias en inglés para conveniencia
    name: nombre,
    firstName: nombre,
    lastName: apellidos,
    phone: telefono,
    avatar: foto
  };
}

/**
 * Convierte un User a los claims que se guardan en el JWT
 * 
 * @param user - Objeto User
 * @returns Claims del usuario para el token
 */
export function userToTokenClaims(user: User): {
  nombre: string;
  apellidos?: string;
  telefono: string;
  roles: string[];
} {
  return {
    nombre: user.nombre,
    apellidos: user.apellidos,
    telefono: user.telefono,
    roles: user.roles
  };
}

/**
 * Extrae los datos de usuario desde un JWT decodificado
 * 
 * @param payload - Payload del JWT decodificado
 * @returns User reconstruido o null si no hay datos
 */
export function tokenClaimsToUser(
  payload: { sub?: string; user?: Record<string, unknown> }
): User | null {
  if (!payload.sub || !payload.user) {
    return null;
  }

  const userData = payload.user;
  
  return {
    id: payload.sub,
    nombre: String(userData.nombre || ''),
    apellidos: String(userData.apellidos || ''),
    telefono: String(userData.telefono || ''),
    email: userData.email ? String(userData.email) : undefined,
    foto: userData.foto ? String(userData.foto) : null,
    roles: Array.isArray(userData.roles) 
      ? userData.roles.map(String) 
      : ['user'],
    // Alias
    name: String(userData.nombre || ''),
    firstName: String(userData.nombre || ''),
    lastName: String(userData.apellidos || ''),
    phone: String(userData.telefono || ''),
    avatar: userData.foto ? String(userData.foto) : null
  };
}

/**
 * Normaliza un objeto parcial a CreateUserData válido
 * 
 * @param data - Datos parciales del usuario
 * @returns CreateUserData con valores por defecto
 */
export function normalizeCreateUserData(data: Partial<CreateUserData>): CreateUserData {
  return {
    nombre: data.nombre || '',
    telefono: data.telefono || '',
    apellidos: data.apellidos,
    email: data.email,
    foto: data.foto ?? null,
    roles: data.roles || ['user']
  };
}

/**
 * Valida si un objeto tiene los campos mínimos requeridos para ser un User
 * 
 * @param obj - Objeto a validar
 * @returns true si es un User válido
 */
export function isValidUser(obj: unknown): obj is User {
  if (!obj || typeof obj !== 'object') {
    return false;
  }
  
  const user = obj as Record<string, unknown>;
  
  return (
    typeof user.id === 'string' &&
    user.id.length > 0 &&
    (typeof user.nombre === 'string' || typeof user.name === 'string') &&
    (typeof user.telefono === 'string' || typeof user.phone === 'string') &&
    Array.isArray(user.roles)
  );
}


