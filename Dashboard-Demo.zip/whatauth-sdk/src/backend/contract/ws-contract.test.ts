/**
 * SDK-025: WebSocket Contract Tests
 * 
 * Verifica que los eventos WebSocket cumplen con el contrato definido.
 */

import { describe, it, expect, afterAll } from 'vitest';
import { createServer } from 'net';
import { CamarauthBackend } from '../index';
import { CamarauthSocketClient } from '../../core/socket-client';
import { encodePinToEmojis } from '../../core/pin-generator';
import type { AuthResponse } from '../../core/types';

async function getFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') {
        server.close();
        reject(new Error('No se pudo obtener puerto libre'));
        return;
      }
      server.close(() => resolve(address.port));
    });
  });
}

async function waitForHealth(baseUrl: string): Promise<void> {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) return;
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('Backend no inicio a tiempo');
}

const startedBackends: CamarauthBackend[] = [];

async function startBackend() {
  const port = await getFreePort();
  const backend = new CamarauthBackend({
    port,
    host: '127.0.0.1',
    jwtSecret: 'ws-contract-secret',
    evolutionApiUrl: 'https://example.com',
    evolutionApiKey: 'test-api-key',
    evolutionInstanceName: 'test-instance',
    rateLimit: { enabled: false }
  });

  backend.start();
  startedBackends.push(backend);
  const baseUrl = `http://127.0.0.1:${port}`;
  const wsUrl = `ws://127.0.0.1:${port}`;
  await waitForHealth(baseUrl);
  return { backend, baseUrl, wsUrl };
}

describe('SDK-025: WebSocket Contract Tests', () => {
  afterAll(async () => {
    while (startedBackends.length > 0) {
      const backend = startedBackends.pop();
      if (backend) await backend.stop();
    }
  });

  describe('Event: pin-registered', () => {
    it('should emit valid pin-registered contract', async () => {
      const { wsUrl } = await startBackend();
      const client = new CamarauthSocketClient({ apiUrl: wsUrl.replace('ws:', 'http:') });

      await client.connect();
      const pin = 'WSTEST01';
      
      // registerPin devuelve la respuesta directamente
      const response = await client.registerPin(pin, encodePinToEmojis(pin).join(''));

      // Verificar contrato del evento
      expect(response).toMatchObject({
        success: true,
        message: expect.any(String)
      });

      client.disconnect();
    });
  });

  describe('Event: auth-success', () => {
    it('should emit valid auth-success contract', async () => {
      const { baseUrl, wsUrl } = await startBackend();
      const client = new CamarauthSocketClient({ apiUrl: wsUrl.replace('ws:', 'http:') });
      const pin = 'WSTEST02';
      const emojiString = encodePinToEmojis(pin).join('');

      const authSuccessPromise = new Promise<AuthResponse>((resolve) => {
        client.setCallbacks({ onSuccess: resolve });
      });

      await client.connect();
      await client.registerPin(pin, emojiString);

      // Simular webhook
      await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'test-instance',
          data: {
            key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-ws-1' },
            pushName: 'WS Test User',
            message: { conversation: `PIN: ${emojiString}` }
          }
        })
      });

      const event = await authSuccessPromise;

      // Verificar contrato completo de auth-success
      expect(event).toMatchObject({
        success: true,
        verified: true,
        token: expect.any(String),
        refreshToken: expect.any(String),
        user: expect.any(Object)
      });

      // Verificar estructura del usuario
      expect(event.user).toMatchObject({
        id: expect.any(String),
        nombre: expect.any(String),
        telefono: expect.any(String),
        roles: expect.arrayContaining([expect.any(String)])
      });

      client.disconnect();
    });
  });

  describe('Event: pin-error', () => {
    it('should emit valid pin-error contract', async () => {
      const { wsUrl } = await startBackend();
      const client = new CamarauthSocketClient({ apiUrl: wsUrl.replace('ws:', 'http:') });

      await client.connect();
      
      // Intentar registrar PIN vacío (debería fallar)
      try {
        await client.registerPin('', '');
        // Si no lanza error, el test falla
        expect(false).toBe(true);
      } catch (error: any) {
        // Verificar que se lanzó un error
        expect(error).toBeDefined();
        expect(error.message).toBeTruthy();
      }

      client.disconnect();
    });
  });

  describe('Event: auth-cancelled', () => {
    it('should emit auth-cancelled event', async () => {
      const { wsUrl } = await startBackend();
      const client = new CamarauthSocketClient({ apiUrl: wsUrl.replace('ws:', 'http:') });
      const pin = 'WSTEST03';

      await client.connect();
      await client.registerPin(pin, encodePinToEmojis(pin).join(''));
      
      // cancelAuth no devuelve nada, solo emite el evento
      client.cancelAuth(pin);

      // Esperar un poco para que el evento se procese
      await new Promise(resolve => setTimeout(resolve, 100));

      // Verificar que el cliente sigue conectado después de cancelar
      expect(client.isConnected()).toBe(true);

      client.disconnect();
    });
  });

  describe('Connection Contract', () => {
    it('should establish connection with valid handshake', async () => {
      const { wsUrl } = await startBackend();
      const client = new CamarauthSocketClient({ apiUrl: wsUrl.replace('ws:', 'http:') });

      await client.connect();
      
      // Verificar conexión exitosa
      expect(client.isConnected()).toBe(true);

      client.disconnect();
    });

    it('should handle disconnection gracefully', async () => {
      const { wsUrl } = await startBackend();
      const client = new CamarauthSocketClient({ apiUrl: wsUrl.replace('ws:', 'http:') });

      await client.connect();
      client.disconnect();

      // Verificar desconexión
      expect(client.isConnected()).toBe(false);
    });
  });
});
