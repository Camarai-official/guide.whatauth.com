/**
 * SDK-025: Contract Tests HTTP/WS + OpenAPI
 * 
 * Tests de contrato para verificar que las respuestas HTTP y eventos WS
 * cumplen con el schema definido.
 */

import { describe, it, expect, beforeEach, beforeAll, afterAll } from 'vitest';
import { createServer } from 'net';
import { CamarauthBackend } from '../index';
import { encodePinToEmojis } from '../../core/pin-generator';

async function getFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address === 'string') {
        server.close();
        reject(new Error('No se pudo obtener puerto libre'));
        return;
      }
      server.close(() => resolve(address.port));
    });
  });
}

async function waitForHealth(baseUrl: string): Promise<void> {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/health`);
      if (response.ok) return;
    } catch {
      // Retry
    }
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('Backend no inicio a tiempo');
}

const startedBackends: CamarauthBackend[] = [];

async function startBackend() {
  const port = await getFreePort();
  const backend = new CamarauthBackend({
    port,
    host: '127.0.0.1',
    jwtSecret: 'contract-test-secret',
    evolutionApiUrl: 'https://example.com',
    evolutionApiKey: 'test-api-key',
    evolutionInstanceName: 'test-instance',
    rateLimit: { enabled: false }
  });

  backend.start();
  startedBackends.push(backend);
  const baseUrl = `http://127.0.0.1:${port}`;
  await waitForHealth(baseUrl);
  return { backend, baseUrl };
}

describe('SDK-025: Contract Tests', () => {
  afterAll(async () => {
    while (startedBackends.length > 0) {
      const backend = startedBackends.pop();
      if (backend) await backend.stop();
    }
  });

  describe('HTTP Endpoints Contract', () => {
    describe('POST /register-pin', () => {
      it('should return valid contract for successful registration', async () => {
        const { baseUrl } = await startBackend();
        
        const response = await fetch(`${baseUrl}/register-pin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: 'TEST12' })
        });

        const body = await response.json();

        // Verificar estructura de respuesta exitosa
        expect(response.status).toBe(200);
        expect(body).toMatchObject({
          success: true,
          message: expect.any(String),
          pinId: expect.any(String),
          expiresIn: expect.any(Number)
        });
        expect(typeof body.pinId).toBe('string');
        expect(body.pinId.length).toBeGreaterThan(0);
        expect(typeof body.expiresIn).toBe('number');
        expect(body.expiresIn).toBeGreaterThan(0);
      });

      it('should return valid error contract for invalid request', async () => {
        const { baseUrl } = await startBackend();
        
        const response = await fetch(`${baseUrl}/register-pin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({}) // Sin PIN
        });

        const body = await response.json();

        // Verificar estructura de error estándar
        expect(response.status).toBe(400);
        expect(body).toMatchObject({
          success: false,
          error: expect.any(String),
          code: expect.any(String),
          status: 400
        });
      });
    });

    describe('POST /check-login', () => {
      it('should return valid pending contract', async () => {
        const { baseUrl } = await startBackend();
        
        // Registrar PIN primero
        await fetch(`${baseUrl}/register-pin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: 'PEND01' })
        });

        const response = await fetch(`${baseUrl}/check-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: 'PEND01' })
        });

        const body = await response.json();

        expect(response.status).toBe(200);
        expect(body).toMatchObject({
          success: true,
          verified: false,
          message: expect.any(String)
        });
        expect(body.verified).toBe(false);
        expect(body.token).toBeUndefined();
      });

      it('should return valid verified contract', async () => {
        const { baseUrl } = await startBackend();
        const pin = 'VERF01';
        const emojiString = encodePinToEmojis(pin).join('');

        // Registrar PIN
        await fetch(`${baseUrl}/register-pin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin })
        });

        // Simular webhook de verificación
        await fetch(`${baseUrl}/webhook/evolution`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'messages.upsert',
            instance: 'test-instance',
            data: {
              key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-1' },
              pushName: 'Test User',
              message: { conversation: `PIN: ${emojiString}` }
            }
          })
        });

        const response = await fetch(`${baseUrl}/check-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin })
        });

        const body = await response.json();

        expect(response.status).toBe(200);
        expect(body).toMatchObject({
          success: true,
          verified: true,
          token: expect.any(String),
          refreshToken: expect.any(String),
          user: expect.any(Object)
        });

        // Verificar estructura de user
        expect(body.user).toMatchObject({
          id: expect.any(String),
          nombre: expect.any(String),
          telefono: expect.any(String),
          roles: expect.any(Array)
        });
      });

      it('should return valid not-found contract', async () => {
        const { baseUrl } = await startBackend();
        
        const response = await fetch(`${baseUrl}/check-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin: 'NONEXISTENT' })
        });

        const body = await response.json();

        expect(response.status).toBe(404);
        expect(body).toMatchObject({
          success: false,
          error: expect.any(String),
          code: expect.any(String),
          status: 404,
          verified: false
        });
      });
    });

    describe('POST /refresh-token', () => {
      it('should return valid token refresh contract', async () => {
        const { baseUrl } = await startBackend();
        const pin = 'REFR01';
        const emojiString = encodePinToEmojis(pin).join('');

        // Registrar y verificar PIN
        await fetch(`${baseUrl}/register-pin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin })
        });

        await fetch(`${baseUrl}/webhook/evolution`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'messages.upsert',
            instance: 'test-instance',
            data: {
              key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-1' },
              pushName: 'Test User',
              message: { conversation: `PIN: ${emojiString}` }
            }
          })
        });

        const loginResponse = await fetch(`${baseUrl}/check-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin })
        });
        const loginBody = await loginResponse.json();

        const response = await fetch(`${baseUrl}/refresh-token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refreshToken: loginBody.refreshToken })
        });

        const body = await response.json();

        expect(response.status).toBe(200);
        expect(body).toMatchObject({
          success: true,
          token: expect.any(String),
          refreshToken: expect.any(String)
        });
      });

      it('should return valid error contract for invalid refresh token', async () => {
        const { baseUrl } = await startBackend();
        
        const response = await fetch(`${baseUrl}/refresh-token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refreshToken: 'invalid-token' })
        });

        const body = await response.json();

        expect(response.status).toBe(401);
        expect(body).toMatchObject({
          success: false,
          error: expect.any(String),
          code: expect.any(String),
          status: 401
        });
      });
    });

    describe('POST /logout', () => {
      it('should return valid logout contract', async () => {
        const { baseUrl } = await startBackend();
        
        const response = await fetch(`${baseUrl}/logout`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: '123' })
        });

        const body = await response.json();

        expect(response.status).toBe(200);
        expect(body).toMatchObject({
          success: true,
          message: expect.any(String)
        });
      });
    });

    describe('GET /profile', () => {
      it('should return valid profile contract', async () => {
        const { baseUrl } = await startBackend();
        const pin = 'PROF01';
        const emojiString = encodePinToEmojis(pin).join('');

        // Registrar y verificar PIN
        await fetch(`${baseUrl}/register-pin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin })
        });

        await fetch(`${baseUrl}/webhook/evolution`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'messages.upsert',
            instance: 'test-instance',
            data: {
              key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-1' },
              pushName: 'Test User',
              message: { conversation: `PIN: ${emojiString}` }
            }
          })
        });

        const loginResponse = await fetch(`${baseUrl}/check-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin })
        });
        const loginBody = await loginResponse.json();

        const response = await fetch(`${baseUrl}/profile`, {
          headers: { Authorization: `Bearer ${loginBody.token}` }
        });

        const body = await response.json();

        expect(response.status).toBe(200);
        expect(body).toMatchObject({
          success: true,
          user: expect.any(Object)
        });

        // Verificar estructura completa del usuario
        expect(body.user).toMatchObject({
          id: expect.any(String),
          nombre: expect.any(String),
          telefono: expect.any(String),
          roles: expect.arrayContaining([expect.any(String)])
        });
      });

      it('should return valid error contract for missing token', async () => {
        const { baseUrl } = await startBackend();
        
        const response = await fetch(`${baseUrl}/profile`);
        const body = await response.json();

        expect(response.status).toBe(401);
        expect(body).toMatchObject({
          success: false,
          error: expect.any(String),
          code: expect.any(String),
          status: 401
        });
      });
    });

    describe('GET /health', () => {
      it('should return valid health contract', async () => {
        const { baseUrl } = await startBackend();
        
        const response = await fetch(`${baseUrl}/health`);
        const body = await response.json();

        expect(response.status).toBe(200);
        expect(body).toMatchObject({
          status: 'ok',
          timestamp: expect.any(String),
          activePins: expect.any(Number),
          instance: expect.any(String)
        });

        // Verificar que timestamp es ISO 8601 válido
        expect(new Date(body.timestamp).toISOString()).toBe(body.timestamp);
      });
    });
  });

  describe('Webhook Contract', () => {
    it('should return 200 for valid webhook payload', async () => {
      const { baseUrl } = await startBackend();
      
      const response = await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'test-instance',
          data: {
            key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-1' },
            pushName: 'Test User',
            message: { conversation: 'Hello' }
          }
        })
      });

      expect(response.status).toBe(200);
    });

    it('should return 200 for messages without PIN format', async () => {
      const { baseUrl } = await startBackend();
      
      const response = await fetch(`${baseUrl}/webhook/evolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'messages.upsert',
          instance: 'test-instance',
          data: {
            key: { remoteJid: '34600000000@s.whatsapp.net', fromMe: false, id: 'msg-1' },
            pushName: 'Test User',
            message: { conversation: 'Just a normal message' }
          }
        })
      });

      expect(response.status).toBe(200);
    });
  });
});
