export interface EvolutionMessage {
  key?: {
    remoteJid: string;
    fromMe: boolean;
    id: string;
  };
  pushName?: string;
  message?: {
    conversation?: string;
    extendedTextMessage?: {
      text: string;
    };
  };
  messageTimestamp?: number;
}

export interface EvolutionWebhookPayload {
  event: string;
  instance: string;
  data: EvolutionMessage;
}

export interface PinData {
  id: string;
  pin: string;
  emojiString: string;
  status: 'pending' | 'verified';
  userId?: string;
  phoneNumber?: string;
  socketId?: string;
  expiresAt: number;
  createdAt: number;
  userData?: unknown;
  accessToken?: string;
  refreshToken?: string;
}

export interface DatabaseQueryResult<Row extends Record<string, unknown> = Record<string, unknown>> {
  rows: Row[];
  rowCount?: number;
}

export interface DatabaseAdapter {
  query<Row extends Record<string, unknown> = Record<string, unknown>>(
    text: string,
    values?: unknown[]
  ): Promise<DatabaseQueryResult<Row>>;
}

export interface BackendErrorResponse {
  success: false;
  error: string;
  code: string;
  status: number;
  details?: Record<string, unknown>;
}
