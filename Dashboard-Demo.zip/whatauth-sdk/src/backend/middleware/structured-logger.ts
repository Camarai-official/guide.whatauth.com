/**
 * SDK-029: Structured Logging
 * 
 * Sistema de logs estructurados en formato JSON para producción.
 * 
 * Características:
 * - Niveles de log: debug, info, warn, error
 * - Formato JSON estructurado
 * - Contexto configurable
 * - Timestamps ISO 8601
 * - Soporte para correlation IDs
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogContext {
  /** ID de correlación para tracing */
  correlationId?: string;
  /** ID del request */
  requestId?: string;
  /** ID del usuario */
  userId?: string;
  /** Endpoint o ruta */
  path?: string;
  /** Método HTTP */
  method?: string;
  /** IP del cliente */
  ip?: string;
  /** Campos adicionales */
  [key: string]: unknown;
}

export interface LogEntry {
  /** Timestamp ISO 8601 */
  timestamp: string;
  /** Nivel de log */
  level: LogLevel;
  /** Mensaje */
  message: string;
  /** Contexto */
  context?: LogContext;
  /** Datos adicionales */
  data?: Record<string, unknown>;
  /** Error si aplica */
  error?: {
    message: string;
    stack?: string;
    code?: string;
  };
}

export interface LoggerConfig {
  /** Nivel mínimo de log (default: 'info' en prod, 'debug' en dev) */
  minLevel: LogLevel;
  /** 
   * Función de salida (default: console.log/console.error)
   * En producción, esto podría ser un stream a un servicio de logs
   */
  output: (entry: LogEntry) => void;
  /** 
   * Contexto global que se incluye en todos los logs
   */
  globalContext?: LogContext;
  /** 
   * Incluir stack traces en errores (default: true en dev, false en prod)
   */
  includeStackTrace: boolean;
}

const LOG_LEVELS: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3
};

/**
 * Formatea una entrada de log a JSON
 */
function formatLogEntry(entry: LogEntry): string {
  return JSON.stringify(entry);
}

/**
 * Logger estructurado
 */
export class StructuredLogger {
  private config: LoggerConfig;
  
  constructor(config: Partial<LoggerConfig> = {}) {
    const isProd = process.env.NODE_ENV === 'production';
    
    this.config = {
      minLevel: config.minLevel ?? (isProd ? 'info' : 'debug'),
      output: config.output ?? ((entry: LogEntry) => {
        const formatted = formatLogEntry(entry);
        if (entry.level === 'error') {
          console.error(formatted);
        } else if (entry.level === 'warn') {
          console.warn(formatted);
        } else {
          console.log(formatted);
        }
      }),
      globalContext: config.globalContext ?? {},
      includeStackTrace: config.includeStackTrace ?? !isProd
    };
  }
  
  /**
   * Crea un child logger con contexto adicional
   */
  child(context: LogContext): StructuredLogger {
    return new StructuredLogger({
      ...this.config,
      globalContext: {
        ...this.config.globalContext,
        ...context
      }
    });
  }
  
  /**
   * Log de nivel debug
   */
  debug(message: string, data?: Record<string, unknown>): void {
    this.log('debug', message, data);
  }
  
  /**
   * Log de nivel info
   */
  info(message: string, data?: Record<string, unknown>): void {
    this.log('info', message, data);
  }
  
  /**
   * Log de nivel warn
   */
  warn(message: string, data?: Record<string, unknown>): void {
    this.log('warn', message, data);
  }
  
  /**
   * Log de nivel error
   */
  error(message: string, error?: Error, data?: Record<string, unknown>): void {
    const errorData = error ? {
      message: error.message,
      ...(this.config.includeStackTrace && error.stack ? { stack: error.stack } : {}),
      ...(error.name !== 'Error' ? { code: error.name } : {})
    } : undefined;
    
    this.log('error', message, data, errorData);
  }
  
  private log(
    level: LogLevel, 
    message: string, 
    data?: Record<string, unknown>,
    error?: LogEntry['error']
  ): void {
    // Verificar nivel mínimo
    if (LOG_LEVELS[level] < LOG_LEVELS[this.config.minLevel]) {
      return;
    }
    
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      ...(Object.keys(this.config.globalContext || {}).length > 0 
        ? { context: this.config.globalContext } 
        : {}),
      ...(data && Object.keys(data).length > 0 ? { data } : {}),
      ...(error ? { error } : {})
    };
    
    this.config.output(entry);
  }
}

/**
 * Logger global por defecto
 */
export const logger = new StructuredLogger();

/**
 * Express middleware para logging de requests
 */
export function requestLogger(loggerInstance: StructuredLogger = logger) {
  return (req: any, res: any, next: any): void => {
    const start = Date.now();
    const requestId = Math.random().toString(36).substring(2, 15);
    
    // Crear logger con contexto del request
    const requestLogger = loggerInstance.child({
      requestId,
      method: req.method,
      path: req.path,
      ip: req.ip
    });
    
    // Log de inicio
    requestLogger.info('Request started', {
      query: req.query,
      userAgent: req.get('user-agent')
    });
    
    // Capturar fin del request
    res.on('finish', () => {
      const duration = Date.now() - start;
      const level = res.statusCode >= 400 ? 'warn' : 'info';
      
      requestLogger[level](
        'Request completed',
        {
          statusCode: res.statusCode,
          duration: `${duration}ms`
        }
      );
    });
    
    // Adjuntar logger al request para uso en controllers
    req.logger = requestLogger;
    
    next();
  };
}

/**
 * Middleware de error que loguea antes de responder
 */
export function errorLogger(loggerInstance: StructuredLogger = logger) {
  return (err: Error, req: any, res: any, next: any): void => {
    const requestLogger = req.logger || loggerInstance;
    
    requestLogger.error(
      'Request error',
      err,
      {
        path: req.path,
        method: req.method
      }
    );
    
    next(err);
  };
}

/**
 * Crea un logger para usar en producción (formato JSON puro)
 */
export function createProductionLogger(): StructuredLogger {
  return new StructuredLogger({
    minLevel: 'info',
    includeStackTrace: false
  });
}

/**
 * Crea un logger para desarrollo (formato legible)
 */
export function createDevelopmentLogger(): StructuredLogger {
  return new StructuredLogger({
    minLevel: 'debug',
    includeStackTrace: true,
    output: (entry: LogEntry) => {
      const { timestamp, level, message, context, data, error } = entry;
      const parts = [
        `[${timestamp}]`,
        `[${level.toUpperCase()}]`,
        message
      ];
      
      if (context && Object.keys(context).length > 0) {
        parts.push(JSON.stringify(context));
      }
      
      if (data && Object.keys(data).length > 0) {
        parts.push(JSON.stringify(data));
      }
      
      if (error) {
        parts.push(`Error: ${error.message}`);
        if (error.stack) {
          parts.push(error.stack);
        }
      }
      
      const output = parts.join(' ');
      
      if (level === 'error') {
        console.error(output);
      } else if (level === 'warn') {
        console.warn(output);
      } else {
        console.log(output);
      }
    }
  });
}
