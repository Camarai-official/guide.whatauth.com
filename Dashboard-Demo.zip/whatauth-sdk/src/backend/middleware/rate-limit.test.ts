/**
 * SDK-029: Rate Limiting Tests
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  rateLimit,
  cleanupRateLimitStore,
  resetRateLimitStore,
  getRateLimitStats,
  type RateLimitConfig
} from './rate-limit';
import type { Request, Response, NextFunction } from 'express';

// Mock de Request, Response, NextFunction
function createMockReq(overrides: Partial<Request> = {}): Partial<Request> {
  return {
    ip: '127.0.0.1',
    path: '/test',
    method: 'GET',
    ...overrides
  };
}

function createMockRes(): Partial<Response> {
  const headers: Record<string, string | number> = {};
  return {
    status: vi.fn().mockReturnThis(),
    json: vi.fn().mockReturnThis(),
    setHeader: vi.fn((key: string, value: string | number) => {
      headers[key] = value;
      return {} as Response;
    }),
    getHeaders: () => headers
  };
}

function createMockNext(): NextFunction {
  return vi.fn() as unknown as NextFunction;
}

describe('SDK-029: Rate Limiting', () => {
  beforeEach(() => {
    resetRateLimitStore();
    vi.useFakeTimers();
  });

  describe('Basic functionality', () => {
    it('should allow requests under the limit', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 5,
        standardHeaders: false
      });

      const req = createMockReq();
      const res = createMockRes();
      const next = createMockNext();

      // 5 requests deben pasar
      for (let i = 0; i < 5; i++) {
        middleware(req as Request, res as Response, next);
      }

      expect(next).toHaveBeenCalledTimes(5);
      expect(res.status).not.toHaveBeenCalled();
    });

    it('should block requests over the limit', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 2,
        standardHeaders: false
      });

      const req = createMockReq();
      const res = createMockRes();
      const next = createMockNext();

      // 2 requests pasan
      middleware(req as Request, res as Response, next);
      middleware(req as Request, res as Response, next);

      // La tercera debe ser bloqueada
      middleware(req as Request, res as Response, next);

      expect(next).toHaveBeenCalledTimes(2);
      expect(res.status).toHaveBeenCalledWith(429);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: false,
          code: 'RATE_LIMIT_EXCEEDED',
          status: 429
        })
      );
    });

    it('should reset limit after window expires', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 2,
        standardHeaders: false
      });

      const req = createMockReq();
      const res = createMockRes();
      const next = createMockNext();

      // 2 requests pasan
      middleware(req as Request, res as Response, next);
      middleware(req as Request, res as Response, next);

      // Bloqueado
      middleware(req as Request, res as Response, next);
      expect(next).toHaveBeenCalledTimes(2);

      // Avanzar tiempo para resetear ventana
      vi.advanceTimersByTime(61000);

      // Nueva request debe pasar
      middleware(req as Request, res as Response, next);
      expect(next).toHaveBeenCalledTimes(3);
    });
  });

  describe('Headers', () => {
    it('should set standard headers', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 10,
        standardHeaders: true
      });

      const req = createMockReq();
      const res = createMockRes();
      const next = createMockNext();

      middleware(req as Request, res as Response, next);

      expect(res.setHeader).toHaveBeenCalledWith('X-RateLimit-Limit', 10);
      expect(res.setHeader).toHaveBeenCalledWith('X-RateLimit-Remaining', 9);
      expect(res.setHeader).toHaveBeenCalledWith(
        'X-RateLimit-Reset',
        expect.any(String)
      );
    });

    it('should set legacy headers when enabled', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 10,
        standardHeaders: false,
        legacyHeaders: true
      });

      const req = createMockReq();
      const res = createMockRes();
      const next = createMockNext();

      middleware(req as Request, res as Response, next);

      expect(res.setHeader).toHaveBeenCalledWith('X-Rate-Limit-Limit', 10);
      expect(res.setHeader).toHaveBeenCalledWith('X-Rate-Limit-Remaining', 9);
      expect(res.setHeader).toHaveBeenCalledWith(
        'X-Rate-Limit-Reset',
        expect.any(Number)
      );
    });
  });

  describe('Custom configuration', () => {
    it('should use custom key generator', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 1,
        keyGenerator: (req) => req.headers['x-api-key'] as string || 'default',
        standardHeaders: false
      });

      // Request con API key 1
      const req1 = createMockReq({ headers: { 'x-api-key': 'key1' } });
      const res1 = createMockRes();
      const next1 = createMockNext();
      middleware(req1 as Request, res1 as Response, next1);
      expect(next1).toHaveBeenCalledTimes(1);

      // Segunda request con misma API key debe ser bloqueada
      middleware(req1 as Request, res1 as Response, next1);
      expect(next1).toHaveBeenCalledTimes(1);

      // Request con API key diferente debe pasar
      const req2 = createMockReq({ headers: { 'x-api-key': 'key2' } });
      const res2 = createMockRes();
      const next2 = createMockNext();
      middleware(req2 as Request, res2 as Response, next2);
      expect(next2).toHaveBeenCalledTimes(1);
    });

    it('should skip rate limiting when skip function returns true', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 1,
        skip: (req) => req.path === '/health',
        standardHeaders: false
      });

      const req = createMockReq({ path: '/health' });
      const res = createMockRes();
      const next = createMockNext();

      // Múltiples requests a /health deben pasar
      for (let i = 0; i < 10; i++) {
        middleware(req as Request, res as Response, next);
      }

      expect(next).toHaveBeenCalledTimes(10);
    });

    it('should use custom error message', () => {
      const customMessage = 'Custom rate limit message';
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 1,
        message: customMessage,
        standardHeaders: false
      });

      const req = createMockReq();
      const res = createMockRes();
      const next = createMockNext();

      middleware(req as Request, res as Response, next);
      middleware(req as Request, res as Response, next);

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          error: customMessage
        })
      );
    });
  });

  describe('Rate limit response details', () => {
    it('should include retry-after in error response', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 1,
        standardHeaders: false
      });

      const req = createMockReq();
      const res = createMockRes();
      const next = createMockNext();

      middleware(req as Request, res as Response, next);
      middleware(req as Request, res as Response, next);

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          details: expect.objectContaining({
            retryAfter: expect.any(Number)
          })
        })
      );
    });
  });

  describe('Store management', () => {
    it('should report correct stats', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 10,
        standardHeaders: false
      });

      // Generar algunas entradas
      for (let i = 0; i < 3; i++) {
        const req = createMockReq({ ip: `192.168.1.${i}` });
        const res = createMockRes();
        const next = createMockNext();
        middleware(req as Request, res as Response, next);
      }

      const stats = getRateLimitStats();
      expect(stats.totalEntries).toBe(3);
    });

    it('should cleanup expired entries', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 10,
        standardHeaders: false
      });

      const req = createMockReq();
      const res = createMockRes();
      const next = createMockNext();

      middleware(req as Request, res as Response, next);

      expect(getRateLimitStats().totalEntries).toBe(1);

      // Avanzar tiempo para expirar
      vi.advanceTimersByTime(61000);

      cleanupRateLimitStore();

      expect(getRateLimitStats().totalEntries).toBe(0);
    });

    it('should reset all entries', () => {
      const middleware = rateLimit({
        windowMs: 60000,
        maxRequests: 10,
        standardHeaders: false
      });

      for (let i = 0; i < 3; i++) {
        const req = createMockReq({ ip: `192.168.1.${i}` });
        const res = createMockRes();
        const next = createMockNext();
        middleware(req as Request, res as Response, next);
      }

      expect(getRateLimitStats().totalEntries).toBe(3);

      resetRateLimitStore();

      expect(getRateLimitStats().totalEntries).toBe(0);
    });
  });
});
