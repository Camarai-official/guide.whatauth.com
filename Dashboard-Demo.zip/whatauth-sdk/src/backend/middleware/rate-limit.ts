/**
 * SDK-029: Rate Limiting Middleware
 * 
 * Implementación de rate limiting para proteger endpoints del backend.
 * 
 * Características:
 * - Límite por IP
 * - Límite por endpoint
 * - Headers de rate limit (X-RateLimit-*)
 * - Configuración personalizable
 */

import type { Request, Response, NextFunction } from 'express';

export interface RateLimitConfig {
  /** Ventana de tiempo en milisegundos (default: 60000 = 1 minuto) */
  windowMs: number;
  
  /** Máximo de requests por ventana (default: 100) */
  maxRequests: number;
  
  /** Mensaje de error cuando se excede el límite */
  message?: string;
  
  /** Headers de rate limit en respuesta (default: true) */
  standardHeaders: boolean;
  
  /** Headers legacy en respuesta (default: false) */
  legacyHeaders: boolean;
  
  /** 
   * Función para obtener el identificador del cliente
   * Por defecto usa req.ip
   */
  keyGenerator?: (req: Request) => string;
  
  /**
   * Función para determinar si saltar el rate limiting
   * Útil para whitelist de IPs
   */
  skip?: (req: Request) => boolean;
}

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

/**
 * Almacenamiento en memoria para rate limiting
 * En producción, considerar usar Redis
 */
class RateLimitStore {
  private store: Map<string, RateLimitEntry> = new Map();
  
  /**
   * Incrementa el contador para una key
   */
  increment(key: string, windowMs: number): { count: number; resetTime: number } {
    const now = Date.now();
    const existing = this.store.get(key);
    
    if (!existing || now > existing.resetTime) {
      // Nueva ventana o ventana expirada
      const entry: RateLimitEntry = {
        count: 1,
        resetTime: now + windowMs
      };
      this.store.set(key, entry);
      return { count: 1, resetTime: entry.resetTime };
    }
    
    // Incrementar contador existente
    existing.count++;
    return { count: existing.count, resetTime: existing.resetTime };
  }
  
  /**
   * Obtiene el estado actual sin incrementar
   */
  get(key: string): RateLimitEntry | undefined {
    const entry = this.store.get(key);
    if (entry && Date.now() > entry.resetTime) {
      this.store.delete(key);
      return undefined;
    }
    return entry;
  }
  
  /**
   * Limpia entradas expiradas
   */
  cleanup(): void {
    const now = Date.now();
    for (const [key, entry] of this.store.entries()) {
      if (now > entry.resetTime) {
        this.store.delete(key);
      }
    }
  }
  
  /**
   * Limpia todas las entradas
   */
  reset(): void {
    this.store.clear();
  }
}

// Store singleton
const store = new RateLimitStore();

/**
 * Middleware de rate limiting
 * 
 * @example
 * ```typescript
 * // Configuración por defecto: 100 requests por minuto
 * app.use(rateLimit());
 * 
 * // Configuración personalizada
 * app.use('/api/', rateLimit({
 *   windowMs: 15 * 60 * 1000, // 15 minutos
 *   maxRequests: 100
 * }));
 * 
 * // Rate limit estricto para login
 * app.post('/login', rateLimit({
 *   windowMs: 60 * 60 * 1000, // 1 hora
 *   maxRequests: 5,
 *   message: 'Demasiados intentos de login. Intenta más tarde.'
 * }));
 * ```
 */
export function rateLimit(config: Partial<RateLimitConfig> = {}) {
  const options: RateLimitConfig = {
    windowMs: 60 * 1000, // 1 minuto
    maxRequests: 100,
    message: 'Demasiadas peticiones. Intenta más tarde.',
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req: Request) => req.ip || 'unknown',
    skip: () => false,
    ...config
  };
  
  return (req: Request, res: Response, next: NextFunction): void => {
    // Saltar si la función skip lo indica
    if (options.skip && options.skip(req)) {
      return next();
    }
    
    const key = options.keyGenerator!(req);
    const { count, resetTime } = store.increment(key, options.windowMs);
    
    // Headers estándar (IETF draft)
    if (options.standardHeaders) {
      res.setHeader('X-RateLimit-Limit', options.maxRequests);
      res.setHeader('X-RateLimit-Remaining', Math.max(0, options.maxRequests - count));
      res.setHeader('X-RateLimit-Reset', new Date(resetTime).toISOString());
    }
    
    // Headers legacy
    if (options.legacyHeaders) {
      res.setHeader('X-Rate-Limit-Limit', options.maxRequests);
      res.setHeader('X-Rate-Limit-Remaining', Math.max(0, options.maxRequests - count));
      res.setHeader('X-Rate-Limit-Reset', Math.ceil(resetTime / 1000));
    }
    
    // Verificar límite
    if (count > options.maxRequests) {
      res.status(429).json({
        success: false,
        error: options.message,
        code: 'RATE_LIMIT_EXCEEDED',
        status: 429,
        details: {
          limit: options.maxRequests,
          windowMs: options.windowMs,
          retryAfter: Math.ceil((resetTime - Date.now()) / 1000)
        }
      });
      return;
    }
    
    next();
  };
}

/**
 * Limpia entradas expiradas del store
 * Útil para llamar periódicamente
 */
export function cleanupRateLimitStore(): void {
  store.cleanup();
}

/**
 * Resetea completamente el store
 * Útil para tests
 */
export function resetRateLimitStore(): void {
  store.reset();
}

/**
 * Obtiene estadísticas del rate limiter
 */
export function getRateLimitStats(): {
  totalEntries: number;
} {
  return {
    totalEntries: store['store'].size
  };
}

// Exportar tipos
export type { RateLimitEntry };
export { RateLimitStore };
