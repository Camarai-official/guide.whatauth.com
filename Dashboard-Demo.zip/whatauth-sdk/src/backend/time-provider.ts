/**
 * SDK-031: Time Provider
 * 
 * Abstracción para proveer tiempo, permite inyección de tiempo falso para tests.
 */

export interface TimeProvider {
  now(): number;
}

export class RealTimeProvider implements TimeProvider {
  now(): number {
    return Date.now();
  }
}

export class FakeTimeProvider implements TimeProvider {
  private currentTime: number;

  constructor(initialTime: number = Date.now()) {
    this.currentTime = initialTime;
  }

  now(): number {
    return this.currentTime;
  }

  advance(ms: number): void {
    this.currentTime += ms;
  }

  setTime(timestamp: number): void {
    this.currentTime = timestamp;
  }
}
