import type { PinData } from '../types';

export interface PinRepository {
  save(pinData: PinData): Promise<void>;
  findByPin(pin: string): Promise<PinData | null>;
  removeByPin(pin: string): Promise<boolean>;
  hasPin(pin: string): Promise<boolean>;
  findByUserId(userId: string): Promise<PinData | null>;
  listEntries(): Promise<Array<[string, PinData]>>;
  count(): Promise<number>;
  toDebugMap?(): Map<string, PinData>;
}

export class MemoryPinRepository implements PinRepository {
  private readonly pins = new Map<string, PinData>();

  async save(pinData: PinData): Promise<void> {
    this.pins.set(pinData.pin, pinData);
  }

  async findByPin(pin: string): Promise<PinData | null> {
    return this.pins.get(pin) ?? null;
  }

  async removeByPin(pin: string): Promise<boolean> {
    return this.pins.delete(pin);
  }

  async hasPin(pin: string): Promise<boolean> {
    return this.pins.has(pin);
  }

  async findByUserId(userId: string): Promise<PinData | null> {
    for (const pinData of this.pins.values()) {
      if (pinData.userId === userId) {
        return pinData;
      }
    }

    return null;
  }

  async listEntries(): Promise<Array<[string, PinData]>> {
    return Array.from(this.pins.entries());
  }

  async count(): Promise<number> {
    return this.pins.size;
  }

  toDebugMap(): Map<string, PinData> {
    return new Map(this.pins);
  }
}
