import { describe, expect, it } from 'vitest';
import { MemoryPinRepository } from './pin-repository';
import type { PinData } from '../types';

function createPinData(pin: string, overrides: Partial<PinData> = {}): PinData {
  return {
    id: `id-${pin}`,
    pin,
    emojiString: `emoji-${pin}`,
    status: 'pending',
    expiresAt: Date.now() + 10000,
    createdAt: Date.now(),
    ...overrides
  };
}

describe('MemoryPinRepository', () => {
  it('stores and reads pin data by pin', async () => {
    const repository = new MemoryPinRepository();
    const pinData = createPinData('ABC123');

    await repository.save(pinData);

    const stored = await repository.findByPin('ABC123');
    expect(stored).toEqual(pinData);
  });

  it('finds pin by user id for refresh/session flows', async () => {
    const repository = new MemoryPinRepository();
    const pinData = createPinData('DEF456', { userId: 'user-42', refreshToken: 'refresh-42' });

    await repository.save(pinData);

    const found = await repository.findByUserId('user-42');
    expect(found?.pin).toBe('DEF456');
  });

  it('lists entries and removes pins', async () => {
    const repository = new MemoryPinRepository();

    await repository.save(createPinData('PIN001'));
    await repository.save(createPinData('PIN002'));

    expect(await repository.count()).toBe(2);
    expect(await repository.hasPin('PIN001')).toBe(true);

    const removed = await repository.removeByPin('PIN001');
    expect(removed).toBe(true);
    expect(await repository.hasPin('PIN001')).toBe(false);

    const entries = await repository.listEntries();
    expect(entries).toHaveLength(1);
    expect(entries[0][0]).toBe('PIN002');
  });
});
