import type { StorageAdapter } from '../types'

export function createLocalStorageAdapter(): StorageAdapter {
  return {
    getItem: (key: string) => localStorage.getItem(key),
    setItem: (key: string, value: string) => localStorage.setItem(key, value),
    removeItem: (key: string) => localStorage.removeItem(key)
  }
}

export function createSessionStorageAdapter(): StorageAdapter {
  return {
    getItem: (key: string) => sessionStorage.getItem(key),
    setItem: (key: string, value: string) => sessionStorage.setItem(key, value),
    removeItem: (key: string) => sessionStorage.removeItem(key)
  }
}

export function createMemoryStorage(): StorageAdapter {
  const store = new Map<string, string>()
  return {
    getItem: (key: string) => store.get(key) || null,
    setItem: (key: string, value: string) => { store.set(key, value) },
    removeItem: (key: string) => { store.delete(key) }
  }
}
