import type { 
  StorageAdapter, 
  AuthStorageOptions, 
  AuthStorageData 
} from '../types'
import { DEFAULT_STORAGE_KEY } from '../constants'
import { ValidationError } from '../types'
import { createLocalStorageAdapter, createSessionStorageAdapter, createMemoryStorage } from './adapters'
export { createLocalStorageAdapter, createSessionStorageAdapter, createMemoryStorage } from './adapters'

const defaultSerialize = (data: AuthStorageData): string => 
  JSON.stringify(data)

const defaultDeserialize = (raw: string): AuthStorageData => {
  try {
    return JSON.parse(raw) as AuthStorageData
  } catch {
    throw new ValidationError('Failed to deserialize auth data')
  }
}

function isStorageAvailable(type: 'localStorage' | 'sessionStorage'): boolean {
  try {
    if (typeof window === 'undefined') return false
    const storage = window[type]
    const testKey = '__camarauth_storage_test__'
    storage.setItem(testKey, 'test')
    storage.removeItem(testKey)
    return true
  } catch {
    return false
  }
}

function detectBestStorage(): StorageAdapter {
  if (typeof window === 'undefined') {
    return createMemoryStorage()
  }
  if (isStorageAvailable('localStorage')) {
    return createLocalStorageAdapter()
  }
  if (isStorageAvailable('sessionStorage')) {
    return createSessionStorageAdapter()
  }
  return createMemoryStorage()
}

export type AuthStorage = ReturnType<typeof createAuthStorage>

export function createAuthStorage(options: AuthStorageOptions = {}) {
  const {
    key = DEFAULT_STORAGE_KEY,
    storage: storageAdapter,
    serialize = defaultSerialize,
    deserialize = defaultDeserialize
  } = options

  const storage = storageAdapter ?? detectBestStorage()

  async function save(data: AuthStorageData): Promise<void> {
    const serialized = serialize(data)
    await storage.setItem(key, serialized)
  }

  async function load(): Promise<AuthStorageData | null> {
    try {
      const raw = await storage.getItem(key)
      if (!raw) return null
      return deserialize(raw)
    } catch {
      try { await storage.removeItem(key) } catch {}
      return null
    }
  }

  async function clear(): Promise<void> {
    await storage.removeItem(key)
  }

  async function exists(): Promise<boolean> {
    const data = await load()
    return data !== null
  }

  function getKey(): string {
    return key
  }

  return {
    save,
    load,
    clear,
    exists,
    getKey,
    storage
  }
}
