import { HttpClient, FetchHttpClient } from './http-client';
import { AuthResponse, LogoutResponse, RegisterPinResponse, User } from './types';
import { encodePinToEmojis } from './pin-generator';

export class CamarauthClient {
  private httpClient: HttpClient;

  constructor(config: { apiUrl: string; httpClient?: HttpClient }) {
    this.httpClient = config.httpClient || new FetchHttpClient(config.apiUrl);
  }

  async registerPin(pin: string, emojiString?: string, finalizado = false): Promise<RegisterPinResponse> {
    const resolvedEmojiString = emojiString ?? encodePinToEmojis(pin).join('');
    return this.httpClient.post<RegisterPinResponse>('/register-pin', {
      pin,
      emojiString: resolvedEmojiString,
      finalizado,
    });
  }

  async checkLogin(pin: string): Promise<AuthResponse> {
    return this.httpClient.post<AuthResponse>('/check-login', { pin });
  }

  async refreshToken(refreshToken: string): Promise<{ token: string; refreshToken: string }> {
     return this.httpClient.post<{ token: string; refreshToken: string }>('/refresh-token', { refreshToken });
  }
  
  async getProfile(accessToken: string): Promise<User> {
      return this.httpClient.get<User>('/profile', { token: accessToken });
  }

  async logout(accessToken: string, userId: string): Promise<LogoutResponse> {
       return this.httpClient.post<LogoutResponse>(
            '/logout', 
            { userId }, 
            { token: accessToken }
        );
  }
}
