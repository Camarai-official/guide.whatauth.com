import type { Socket } from 'socket.io-client'
import { io } from 'socket.io-client'
import type { 
  AuthResponse, 
  LogoutResponse,
  RegisterPinResponse, 
  User,
  WhatauthConfig 
} from './types'
import { HttpClient, FetchHttpClient } from './http-client'

// Development-only console
const devConsole = {
  log: process.env.NODE_ENV === 'development' ? console.log : () => {},
  warn: process.env.NODE_ENV === 'development' ? console.warn : () => {},
  error: process.env.NODE_ENV === 'development' ? console.error : () => {},
  info: process.env.NODE_ENV === 'development' ? console.info : () => {},
  debug: process.env.NODE_ENV === 'development' ? console.debug : () => {},
}

export interface WebSocketAuthCallbacks {
  onSuccess?: (response: AuthResponse) => void
  onError?: (error: Error) => void
  onExpired?: () => void
}

export class WhatauthSocketClient {
  private socket: Socket | null = null
  private httpClient: HttpClient
  private apiUrl: string
  private callbacks: WebSocketAuthCallbacks = {}
  private connectionPromise: Promise<void> | null = null

  constructor(config: WhatauthConfig) {
    this.apiUrl = config.apiUrl
    this.httpClient = new FetchHttpClient(config.apiUrl)
  }

  connect(): Promise<void> {
    // Si ya hay una conexión en progreso, retornar esa misma promesa
    if (this.connectionPromise) {
      return this.connectionPromise
    }

    // Si ya está conectado, retornar promesa resuelta inmediatamente
    if (this.socket?.connected) {
      return Promise.resolve()
    }

    this.connectionPromise = new Promise((resolve, reject) => {
      this.socket = io(this.apiUrl, {
        transports: ['websocket'],
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000
      })

      const connectionTimeout = setTimeout(() => {
        reject(new Error('Connection timeout'))
        this.connectionPromise = null
      }, 10000)

      this.socket.on('connect', () => {
        clearTimeout(connectionTimeout)
        resolve()
      })

      this.socket.on('connect_error', (error) => {
        clearTimeout(connectionTimeout)
        this.callbacks.onError?.(error)
        this.connectionPromise = null
        reject(error)
      })

      this.socket.on('disconnect', () => {
        this.connectionPromise = null
      })

      // Listen for authentication events
      this.socket.on('pin-registered', (data) => {
      })

      this.socket.on('auth-success', (response: AuthResponse) => {
        this.callbacks.onSuccess?.(response)
      })

      this.socket.on('pin-expired', () => {
        this.callbacks.onExpired?.()
      })

      this.socket.on('pin-error', (data: { error: string }) => {
        this.callbacks.onError?.(new Error(data.error))
      })
    })

    return this.connectionPromise
  }

  disconnect(): void {
    this.socket?.disconnect()
    this.socket = null
    this.connectionPromise = null
  }

  async registerPin(pin: string, emojiString: string): Promise<RegisterPinResponse> {
    // Asegurar que estamos conectados antes de registrar
    if (!this.socket?.connected) {
      await this.connect()
    }

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Registration timeout'))
      }, 10000)

      this.socket!.once('pin-registered', (data: RegisterPinResponse & { expiresIn: number }) => {
        clearTimeout(timeout)
        resolve({
          success: true,
          message: `PIN registered successfully. Expires in ${data.expiresIn} seconds`
        })
      })

      this.socket!.once('pin-error', (data: { error: string }) => {
        clearTimeout(timeout)
        reject(new Error(data.error))
      })

      this.socket!.emit('register-pin', { pin, emojiString })
    })
  }

  cancelAuth(pin: string): void {
    if (this.socket?.connected) {
      this.socket.emit('cancel-auth', { pin })
    }
  }

  setCallbacks(callbacks: WebSocketAuthCallbacks): void {
    this.callbacks = { ...this.callbacks, ...callbacks }
  }

  isConnected(): boolean {
    return this.socket?.connected || false
  }

  // HTTP fallback methods for non-realtime operations
  async refreshToken(refreshToken: string): Promise<{ token: string; refreshToken: string }> {
    return this.httpClient.post<{ token: string; refreshToken: string }>('/refresh-token', { refreshToken })
  }

  async getProfile(accessToken: string): Promise<User> {
    return this.httpClient.get<User>('/profile', { token: accessToken })
  }

  async logout(accessToken: string, userId: string): Promise<LogoutResponse> {
    return this.httpClient.post<LogoutResponse>('/logout', { userId }, { token: accessToken })
  }
}
