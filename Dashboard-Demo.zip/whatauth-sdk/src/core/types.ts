/**
 * Core TypeScript types and interfaces for whatauth-sdk
 */

// ============================================================================
// User and Authentication Types
// ============================================================================

export interface User {
  id: string
  email?: string
  name?: string
  firstName?: string
  lastName?: string
  phone?: string
  avatar?: string
  [key: string]: unknown
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: WhatauthError | null
}

export interface AuthContextValue extends AuthState {
  login: (user: User) => void
  logout: () => Promise<void>
  setLoading: (loading: boolean) => void
  setError: (error: WhatauthError | null) => void
}

export interface AuthResponse {
  success: boolean;
  verified: boolean;
  token?: string;
  refreshToken?: string;
  user?: User;
  error?: string;
}

export interface RegisterPinResponse {
  success: boolean;
  message?: string;
  pinId?: string;
  expiresIn?: number;
  error?: string;
}

export interface WhatauthConfig {
  apiUrl: string;
  whatsappNumber?: string;
}

// ============================================================================
// PIN and Emoji Types
// ============================================================================

export interface PinGeneratorOptions {
  length?: number
  characters?: string
}

export interface PinGenerationResult {
  pin: string
  emojis: string[]
  emojiString: string
}

export interface EmojiEncoderOptions {
  emojis?: string[]
}

// ============================================================================
// Countdown and Timer Types
// ============================================================================

export interface CountdownOptions {
  seconds: number
  autoStart?: boolean
  onExpire?: () => void
}

export interface CountdownState {
  timeLeft: number
  formattedTime: string
  isExpired: boolean
  isRunning: boolean
  start: () => void
  stop: () => void
  restart: (seconds?: number) => void
}

// ============================================================================
// Auto-Regeneration Types
// ============================================================================

export interface AutoRegenerationOptions {
  maxRegenerations?: number
  onMaxReached?: () => void
  onRegenerate?: (count: number) => void
}

export interface AutoRegenerationState {
  count: number
  hasReachedMax: boolean
  increment: () => boolean
  reset: () => void
}

// ============================================================================
// Auth Status and Polling Types
// ============================================================================

export interface AuthStatusOptions {
  pin: string | null
  apiUrl: string
  interval?: number
  maxAttempts?: number
  enabled?: boolean
  onSuccess?: (user: User) => void
  onError?: (error: WhatauthError) => void
}

export type AuthStatus = 'idle' | 'polling' | 'success' | 'error' | 'expired'

export interface AuthStatusState {
  status: AuthStatus
  isPolling: boolean
  user: User | null
  error: WhatauthError | null
  attempts: number
  start: () => void
  stop: () => void
}

export interface CheckLoginResponse {
  success: boolean
  verified: boolean
  token?: string;
  refreshToken?: string;
  user?: User;
}

export interface LogoutResponse {
  success: boolean
  message?: string
}

// ============================================================================
// PIN Auth Orchestrator Types
// ============================================================================

export interface PinAuthOptions {
  apiUrl: string
  whatsappNumber: string
  pinLength?: number
  expiresIn?: number
  maxAutoRegenerations?: number
  pollingInterval?: number
  autoGenerate?: boolean
  messagePrefix?: string
  onPinGenerated?: (pin: string, emojis: string[]) => void
  onSuccess?: (user: User) => void
  onError?: (error: WhatauthError) => void
  onExpire?: () => void
  onMaxRegenerationsReached?: () => void
}

export interface PinAuthState {
  pin: string | null
  emojis: string[]
  emojiString: string
  timeLeft: number
  formattedTime: string
  isExpired: boolean
  regenerationCount: number
  hasReachedMaxRegenerations: boolean
  status: AuthStatus
  isLoading: boolean
  user: User | null
  error: WhatauthError | null
  whatsappLink: string
  qrCodeUrl: string | null
  fullMessage: string
  generate: () => void
  cancel: () => void
  reset: () => void
}

// ============================================================================
// Storage Types
// ============================================================================

export interface StorageAdapter {
  getItem: (key: string) => string | null | Promise<string | null>
  setItem: (key: string, value: string) => void | Promise<void>
  removeItem: (key: string) => void | Promise<void>
}

export interface AuthStorageOptions {
  key?: string
  storage?: StorageAdapter
  serialize?: (data: AuthStorageData) => string
  deserialize?: (raw: string) => AuthStorageData
}

export interface AuthStorageData {
  token: string
  refreshToken?: string
  user: User
  expiresAt?: number
}

// ============================================================================
// API Types
// ============================================================================

export interface ApiClientConfig {
  baseUrl: string
  timeout?: number
  onRequest?: (config: RequestInit) => RequestInit | Promise<RequestInit>
  onResponse?: (response: Response) => Response | Promise<Response>
  onError?: (error: WhatauthError) => void | Promise<void>
}

export interface ApiEndpoints {
  registerPin: string
  checkLogin: string
  refreshToken: string
  getUser: string
  logout: string
}

// ============================================================================
// Error Types
// ============================================================================

export class WhatauthError extends Error {
  public code: string
  public statusCode?: number

  constructor(
    message: string,
    code: string,
    statusCode?: number
  ) {
    super(message)
    this.name = 'WhatauthError'
    this.code = code
    this.statusCode = statusCode
    Object.setPrototypeOf(this, WhatauthError.prototype)
  }
}

export class PinExpiredError extends WhatauthError {
  constructor(message = 'PIN has expired') {
    super(message, 'PIN_EXPIRED', 410)
    this.name = 'PinExpiredError'
  }
}

export class RefreshTokenExpiredError extends WhatauthError {
  constructor(message = 'Refresh token has expired') {
    super(message, 'REFRESH_TOKEN_EXPIRED', 401)
    this.name = 'RefreshTokenExpiredError'
  }
}

export class AuthenticationError extends WhatauthError {
  constructor(message = 'Authentication failed') {
    super(message, 'AUTHENTICATION_FAILED', 401)
    this.name = 'AuthenticationError'
  }
}

export class NetworkError extends WhatauthError {
  constructor(message = 'Network error') {
    super(message, 'NETWORK_ERROR')
    this.name = 'NetworkError'
  }
}

export class ValidationError extends WhatauthError {
  constructor(message = 'Validation error') {
    super(message, 'VALIDATION_ERROR', 400)
    this.name = 'ValidationError'
  }
}

// ============================================================================
// WhatsApp Types
// ============================================================================

export interface WhatsAppLinkOptions {
  phoneNumber: string
  message?: string
  prefix?: string
}

// ============================================================================
// Provider Types -> Moved to React package
// ============================================================================

export type ErrorCode = 
  | 'PIN_EXPIRED'
  | 'REFRESH_TOKEN_EXPIRED'
  | 'AUTHENTICATION_FAILED'
  | 'NETWORK_ERROR'
  | 'VALIDATION_ERROR'
