import {
  VARIATION_SELECTOR_16_START,
  VARIATION_SELECTOR_16_END,
  VARIATION_SELECTOR_256_START,
  VARIATION_SELECTOR_256_END
} from './constants'

export function byteToVariationSelector(byte: number): string {
  if (byte < 0 || byte > 255) {
    throw new Error('Byte value must be between 0 and 255')
  }
  
  let codePoint: number
  if (byte < 16) {
    codePoint = VARIATION_SELECTOR_16_START + byte
  } else {
    codePoint = VARIATION_SELECTOR_256_START + (byte - 16)
  }
  
  return String.fromCodePoint(codePoint)
}

export function variationSelectorToByte(char: string): number | null {
  if (char.length === 0) return null
  
  const codePoint = char.codePointAt(0)
  if (codePoint === undefined) return null
  
  if (codePoint >= VARIATION_SELECTOR_16_START && 
      codePoint <= VARIATION_SELECTOR_16_END) {
    return codePoint - VARIATION_SELECTOR_16_START
  }
  
  if (codePoint >= VARIATION_SELECTOR_256_START && 
      codePoint <= VARIATION_SELECTOR_256_END) {
    return 16 + (codePoint - VARIATION_SELECTOR_256_START)
  }
  
  return null
}

export function isVariationSelector(char: string): boolean {
  return variationSelectorToByte(char) !== null
}

export function encodeTextToEmojis(baseEmoji: string, text: string): string {
  if (!baseEmoji || typeof baseEmoji !== 'string') {
    throw new Error('Base emoji is required')
  }
  
  if (!text || typeof text !== 'string') {
    return baseEmoji
  }
  
  const encoder = new TextEncoder()
  const bytes = encoder.encode(text)
  
  const variationSelectors = Array.from(bytes)
    .map(byte => byteToVariationSelector(byte))
    .join('')
  
  return baseEmoji + variationSelectors
}

export function extractVariationSelectors(text: string): string[] {
  if (!text) return []
  const selectors: string[] = []
  for (const char of text) {
    if (isVariationSelector(char)) selectors.push(char)
  }
  return selectors
}

export function decodeEmojisToText(emojiString: string): string | null {
  if (!emojiString || typeof emojiString !== 'string') {
    return null
  }

  try {
    // Extraer los variation selectors (ignorar el emoji base al inicio)
    const bytes: number[] = []
    let foundFirstSelector = false
    
    for (const char of emojiString) {
      const byte = variationSelectorToByte(char)
      if (byte !== null) {
        foundFirstSelector = true
        bytes.push(byte)
      } else if (foundFirstSelector) {
        // Si ya encontramos selectors y ahora hay algo que no es selector, paramos
        break
      }
    }

    if (bytes.length === 0) {
      return null
    }

    // Convertir bytes a string UTF-8
    const decoder = new TextDecoder()
    const uint8Array = new Uint8Array(bytes)
    return decoder.decode(uint8Array)
  } catch (error) {
    console.error('Error decoding emojis:', error)
    return null
  }
}

export function decodeEmojiChunk(chunk: string): string | null {
  // Decodifica un chunk que empieza con emoji base + variation selectors
  const bytes: number[] = []
  let foundSelector = false
  
  for (const char of chunk) {
    const byte = variationSelectorToByte(char)
    if (byte !== null) {
      foundSelector = true
      bytes.push(byte)
    } else if (!foundSelector) {
      // Ignorar el emoji base inicial
      continue
    } else {
      // Después de los selectors, paramos
      break
    }
  }

  if (bytes.length === 0) return null

  try {
    const decoder = new TextDecoder()
    return decoder.decode(new Uint8Array(bytes))
  } catch {
    return null
  }
}

// Funciones adicionales compatibles con n8n

export function splitByBaseEmoji(text: string): string[] {
  // Divide el string en chunks separados por emoji base
  const chunks: string[] = []
  let currentChunk = ""
  const chars = Array.from(text)
  
  for (const char of chars) {
    const codePoint = char.codePointAt(0)
    if (codePoint === undefined) continue
    
    const byte = variationSelectorToByte(char)
    if (byte === null) {
      // Es un emoji base (o carácter normal)
      if (currentChunk.length > 0) {
        chunks.push(currentChunk)
      }
      currentChunk = char
    } else {
      // Es un variation selector, añadir al chunk actual
      if (currentChunk.length > 0) {
        currentChunk += char
      }
    }
  }
  
  if (currentChunk.length > 0) {
    chunks.push(currentChunk)
  }
  
  return chunks
}

export function decodeEmojisFull(emojiString: string): string {
  // Decodifica un string completo de emojis (como en n8n)
  // Divide por emojis base y decodifica cada uno
  const chunks = splitByBaseEmoji(emojiString)
  const decodedChars: string[] = []
  
  for (const chunk of chunks) {
    const decoded = decodeEmojiChunk(chunk)
    if (decoded && decoded.length > 0) {
      decodedChars.push(decoded)
    }
  }
  
  return decodedChars.join('')
}
