import { jwtDecode } from 'jwt-decode'
import type { User } from './types'
import { ERROR_MESSAGES } from './constants'

export interface JWTPayload {
  sub?: string
  phone?: string
  exp?: number
  iat?: number
  [key: string]: unknown
}

export interface DecodedToken {
  payload: JWTPayload
  isExpired: boolean
  expiresAt: Date | null
}

export function decodeToken(token: string): JWTPayload {
  if (!token || typeof token !== 'string') {
    throw new Error(ERROR_MESSAGES.INVALID_TOKEN)
  }

  try {
    return jwtDecode<JWTPayload>(token)
  } catch (error) {
    throw new Error(ERROR_MESSAGES.INVALID_TOKEN)
  }
}

export function decodeTokenFull(token: string): DecodedToken {
  const payload = decodeToken(token)

  const exp = payload.exp
  const expiresAt = exp ? new Date(exp * 1000) : null
  const isExpired = exp ? Date.now() >= exp * 1000 : false

  return {
    payload,
    isExpired,
    expiresAt
  }
}

export function extractUserFromPayload(payload: JWTPayload): User {
  const nestedUser = (payload.user as Record<string, unknown>) || {}
  const { nombre, apellidos, telefono, ...restNested } = nestedUser
  const { user: _omitUser, ...restPayload } = payload
  
  return {
    ...restPayload,
    ...restNested,
    id: payload.sub || '',
    email: (payload.email as string) || (nestedUser.email as string) || '',
    name: (payload.name as string) || (nestedUser.name as string) || (nombre as string) || '',
    surname: (payload.lastName as string) || (nestedUser.lastName as string) || (nestedUser.surname as string) || (apellidos as string) || '',
    firstName: (payload.firstName as string) || (nestedUser.firstName as string),
    lastName: (payload.lastName as string) || (nestedUser.lastName as string) || (apellidos as string),
    phone: (payload.phone as string) || (nestedUser.phone as string) || (telefono as string),
    avatar: (payload.avatar as string) || (nestedUser.avatar as string),
  }
}

export function isTokenExpired(token: string): boolean {
  try {
    const { isExpired } = decodeTokenFull(token)
    return isExpired
  } catch {
    return true
  }
}

export function getUserFromToken(token: string): User | null {
  try {
    const payload = decodeToken(token)
    return extractUserFromPayload(payload)
  } catch {
    return null
  }
}
