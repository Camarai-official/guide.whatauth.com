export const DEFAULT_PIN_LENGTH = 6
export const DEFAULT_PIN_CHARACTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
export const DEFAULT_COUNTDOWN_SECONDS = 180
export const DEFAULT_POLLING_INTERVAL = 15000
export const DEFAULT_API_TIMEOUT = 7000
export const DEFAULT_MAX_REGENERATIONS = 3

export const DEFAULT_EMOJIS = [
  '😀', '😂', '🥰', '😎', '🤔', '👍',
  '🎉', '🔥', '⚡', '🎯', '🚀', '💡',
  '⭐', '🌟', '💎', '🎨', '🎭', '🎪',
  '🌈', '🌺', '🌻', '🌹', '🌷', '🌼',
  '🍀', '🍎', '🍊', '🍋', '🍌', '🍉',
  '🍇', '🍓', '🫐', '🍈', '🍒', '🍑'
]

export const VARIATION_SELECTOR_16_START = 0xFE00
export const VARIATION_SELECTOR_16_END = 0xFE0F
export const VARIATION_SELECTOR_256_START = 0xE0100
export const VARIATION_SELECTOR_256_END = 0xE01EF

export const DEFAULT_STORAGE_KEY = 'camarauth_token'

export const WHATSAPP_BASE_URL = 'https://wa.me'
export const WHATSAPP_MESSAGE_PREFIX = 'PIN'

export const ERROR_MESSAGES = {
  PIN_EXPIRED: 'PIN has expired. Please generate a new one.',
  REFRESH_TOKEN_EXPIRED: 'Session expired. Please log in again.',
  AUTHENTICATION_FAILED: 'Authentication failed. Please try again.',
  NETWORK_ERROR: 'Network error. Please check your connection.',
  VALIDATION_ERROR: 'Invalid input. Please check your data.',
  MAX_REGENERATIONS_REACHED: 'Maximum regenerations reached. Please wait.',
  STORAGE_NOT_AVAILABLE: 'Storage is not available in this environment.',
  INVALID_TOKEN: 'Invalid or malformed token.',
  UNKNOWN_ERROR: 'An unknown error occurred.'
} as const
