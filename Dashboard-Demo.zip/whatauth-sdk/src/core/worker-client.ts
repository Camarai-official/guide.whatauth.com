/**
 * Whatauth Worker client (WebSocket + PKCE + session handshake)
 * Compatible with the Cloudflare Workers backend
 */

import type { AuthResponse, RegisterPinResponse, User, WhatauthError } from './types';
import { AuthenticationError, NetworkError } from './types';

// Development-only console
const devConsole = {
  log: process.env.NODE_ENV === 'development' ? console.log : () => {},
  warn: process.env.NODE_ENV === 'development' ? console.warn : () => {},
  error: process.env.NODE_ENV === 'development' ? console.error : () => {},
  info: process.env.NODE_ENV === 'development' ? console.info : () => {},
  debug: process.env.NODE_ENV === 'development' ? console.debug : () => {},
}

export interface WhatauthWorkerConfig {
  apiUrl: string;
  clientId: string;
  tenantSlug: string;
}

export interface WhatauthWorkerCallbacks {
  onSuccess?: (response: AuthResponse) => void;
  onError?: (error: WhatauthError) => void;
  onExpired?: () => void;
  onPinRegistered?: (loginCode: string, expiresIn: number) => void;
  onAuthCodeIssued?: (authCode: string, expiresIn: number) => void;
}

/**
 * Simple PKCE implementation
 */
function generateCodeVerifier(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return btoa(String.fromCharCode(...array))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

async function sha256Base64Url(input: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const digest = await crypto.subtle.digest('SHA-256', data);
  const base64 = btoa(String.fromCharCode(...new Uint8Array(digest)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
  return base64;
}

export class WhatauthWorkerClient {
  private config: WhatauthWorkerConfig;
  private callbacks: WhatauthWorkerCallbacks = {};
  private ws: WebSocket | null = null;
  private sdkSessionJwt: string | null = null;
  private codeVerifier: string | null = null;
  private currentAuthCode: string | null = null;

  constructor(config: WhatauthWorkerConfig) {
    this.config = config;
  }

  setCallbacks(callbacks: WhatauthWorkerCallbacks): void {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  /**
   * 1) Handshake: obtain sdk_session_jwt
   */
  async initSession(): Promise<void> {
    const res = await fetch(`${this.config.apiUrl}/sdk/session/init`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: this.config.clientId,
        tenant_slug: this.config.tenantSlug,
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Session init failed: ${res.status} ${err}`);
    }

    const { sdk_session_jwt } = (await res.json()) as any;
    if (!sdk_session_jwt) throw new Error('Missing sdk_session_jwt');
    this.sdkSessionJwt = sdk_session_jwt;
  }

  /**
   * 2) Open WebSocket with the session token
   */
  async connectWebSocket(): Promise<void> {
    if (!this.sdkSessionJwt) throw new Error('Session not initialized');
    const wsUrl = new URL('/ws', this.config.apiUrl);
    wsUrl.searchParams.set('tenant_slug', this.config.tenantSlug);
    wsUrl.searchParams.set('token', this.sdkSessionJwt);
    this.ws = new WebSocket(wsUrl.toString());

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('WebSocket connection timeout'));
      }, 10000);

      this.ws!.onopen = () => {
        clearTimeout(timeout);
        resolve();
      };

      this.ws!.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          devConsole.log('WebSocket message received:', msg);
          this.handleMessage(msg);
        } catch (e) {
          devConsole.error('Failed to parse WebSocket message:', event.data, e);
        }
      };

      this.ws!.onclose = (event) => {
        devConsole.log('WebSocket closed:', event.code, event.reason);
        if (event.code !== 1000) {
          this.callbacks.onError?.(new NetworkError('WebSocket connection closed unexpectedly'));
        }
      };

      this.ws!.onerror = (error) => {
        clearTimeout(timeout);
        this.callbacks.onError?.(new NetworkError('WebSocket error'));
        reject(new NetworkError('WebSocket error'));
      };
    });
  }

  private handleMessage(msg: any): void {
    devConsole.log('Handling message type:', msg.type, msg);
    switch (msg.type) {
      case 'pin_registered':
        devConsole.log('PIN registered callback:', msg.loginCode, msg.expiresIn);
        this.callbacks.onPinRegistered?.(msg.loginCode, msg.expiresIn);
        break;
      case 'pin_expired':
        devConsole.log('PIN expired callback');
        this.callbacks.onExpired?.();
        break;
      case 'auth_code_issued':
        devConsole.log('Auth code issued callback:', msg.auth_code, msg.expiresIn);
        this.currentAuthCode = msg.auth_code;
        this.callbacks.onAuthCodeIssued?.(msg.auth_code, msg.expiresIn);
        break;
      case 'error':
        devConsole.error('Error message received:', msg.error);
        this.callbacks.onError?.(new AuthenticationError(msg.error || 'Unknown error'));
        break;
      default:
        devConsole.warn('Unknown message type:', msg.type);
    }
  }

  /**
   * 3) Register a PIN (generates PKCE code_challenge)
   */
  async registerPin(): Promise<void> {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      throw new Error('WebSocket not connected');
    }

    this.codeVerifier = generateCodeVerifier();
    const codeChallenge = await sha256Base64Url(this.codeVerifier);
    
    devConsole.log('Registering PIN with code challenge:', codeChallenge.substring(0, 20) + '...');
    
    this.ws.send(
      JSON.stringify({
        type: 'register_pin',
        code_challenge: codeChallenge,
        code_challenge_method: 'S256',
      })
    );
    
    devConsole.log('PIN registration message sent');
  }

  /**
   * Cancel auth (optional)
   */
  cancelAuth(loginCode: string): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'cancel_auth', loginCode }));
  }

  /**
   * 4) Exchange auth_code + code_verifier for login_proof_jwt
   */
  async exchangeAuthCode(): Promise<AuthResponse> {
    if (!this.currentAuthCode || !this.codeVerifier || !this.sdkSessionJwt) {
      throw new Error('Missing auth_code or verifier');
    }

    const res = await fetch(`${this.config.apiUrl}/sdk/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.sdkSessionJwt}`,
      },
      body: JSON.stringify({
        auth_code: this.currentAuthCode,
        code_verifier: this.codeVerifier,
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Token exchange failed: ${res.status} ${err}`);
    }

    const { login_proof_jwt } = (await res.json()) as any;
    if (!login_proof_jwt) throw new Error('Missing login_proof_jwt');

    // Decode minimal payload for UI (you can also trust the backend)
    const payload = JSON.parse(atob(login_proof_jwt.split('.')[1]));
    const user: User = {
      id: payload.sub || 'unknown',
      name: payload.name || 'Usuario',
      phone: payload.phone,
    };

    const authResponse: AuthResponse = {
      success: true,
      verified: true,
      token: login_proof_jwt,
      user,
    };

    this.callbacks.onSuccess?.(authResponse);
    return authResponse;
  }

  /**
   * Disconnect WebSocket
   */
  disconnect(): void {
    this.ws?.close();
    this.ws = null;
    this.sdkSessionJwt = null;
    this.codeVerifier = null;
    this.currentAuthCode = null;
  }
}
