export interface RequestConfig {
  headers?: Record<string, string>;
  token?: string;
}

export interface HttpClient {
  post<T>(url: string, body: unknown, config?: RequestConfig): Promise<T>;
  get<T>(url: string, config?: RequestConfig): Promise<T>;
}

export class FetchHttpClient implements HttpClient {
  constructor(private baseURL: string) {}

  private createHeaders(config?: RequestConfig): HeadersInit {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...config?.headers,
    };

    if (config?.token) {
      headers['Authorization'] = `Bearer ${config.token}`;
    }

    return headers;
  }

  private async handleResponse<T>(response: Response): Promise<T> {
    if (!response.ok) {
        let errorMessage = `HTTP error! status: ${response.status}`;
        try {
            const errorBody = await response.json();
            if (errorBody && errorBody.error) {
                errorMessage = errorBody.error;
            }
        } catch (e) {
            // Ignore JSON parse error
        }
        throw new Error(errorMessage);
    }
    // Handle 204 No Content or empty responses if needed, but assuming JSON for now
    if (response.status === 204) return {} as T;
    
    return response.json() as Promise<T>;
  }

  async post<T>(endpoint: string, body: unknown, config?: RequestConfig): Promise<T> {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: 'POST',
      headers: this.createHeaders(config),
      body: JSON.stringify(body),
    });
    return this.handleResponse<T>(response);
  }

  async get<T>(endpoint: string, config?: RequestConfig): Promise<T> {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: 'GET',
      headers: this.createHeaders(config),
    });
    return this.handleResponse<T>(response);
  }
}
