import type { PinGeneratorOptions, PinGenerationResult, WhatsAppLinkOptions } from './types'
import { 
  DEFAULT_PIN_LENGTH, 
  DEFAULT_PIN_CHARACTERS, 
  DEFAULT_EMOJIS,
  WHATSAPP_BASE_URL,
  WHATSAPP_MESSAGE_PREFIX
} from './constants'
import { encodeTextToEmojis } from './emoji-encoder'

function getSecureRandomInt(max: number): number {
  if (typeof window !== 'undefined' && window.crypto) {
    const array = new Uint32Array(1)
    window.crypto.getRandomValues(array)
    return array[0] % max
  }
  return Math.floor(Math.random() * max)
}

export function generatePin(options: PinGeneratorOptions = {}): string {
  const {
    length = DEFAULT_PIN_LENGTH,
    characters = DEFAULT_PIN_CHARACTERS
  } = options

  if (length <= 0) throw new Error('PIN length must be greater than 0')
  if (characters.length === 0) throw new Error('Character set cannot be empty')

  let pin = ''
  for (let i = 0; i < length; i++) {
    const randomIndex = getSecureRandomInt(characters.length)
    pin += characters[randomIndex]
  }

  return pin
}

export function encodePinToEmojis(pin: string, options: { emojis?: string[] } = {}): string[] {
  const { emojis = DEFAULT_EMOJIS } = options
  
  if (emojis.length === 0) throw new Error('Emoji list cannot be empty')

  return pin.split('').map(char => {
    const baseEmoji = emojis[getSecureRandomInt(emojis.length)]
    return encodeTextToEmojis(baseEmoji, char)
  })
}

export function generatePinWithEmojis(options: PinGeneratorOptions = {}): PinGenerationResult {
  const pin = generatePin(options)
  const emojis = encodePinToEmojis(pin)
  
  return {
    pin,
    emojis,
    emojiString: emojis.join('')
  }
}

export function formatTime(seconds: number): string {
  if (seconds < 0) seconds = 0
  
  const minutes = Math.floor(seconds / 60)
  const remainingSeconds = seconds % 60
  
  const paddedMinutes = minutes.toString().padStart(2, '0')
  const paddedSeconds = remainingSeconds.toString().padStart(2, '0')
  
  return `${paddedMinutes}:${paddedSeconds}`
}

export function generateWhatsAppLink(options: WhatsAppLinkOptions): string {
  const { phoneNumber, message, prefix = WHATSAPP_MESSAGE_PREFIX } = options
  
  // Limpiar el número de teléfono (quitar +, espacios, etc.)
  const cleanPhone = phoneNumber.replace(/\D/g, '')
  
  // Construir el mensaje
  const fullMessage = prefix ? `${prefix} ${message || ''}` : (message || '')
  
  // Codificar el mensaje para URL
  const encodedMessage = encodeURIComponent(fullMessage)
  
  return `${WHATSAPP_BASE_URL}/${cleanPhone}?text=${encodedMessage}`
}

export function generateQRCodeUrl(whatsappLink: string, size: number = 200): string {
  // Usar una API de QR gratuita
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(whatsappLink)}`
}

export function generateAuthLink(
  phoneNumber: string, 
  emojiString: string, 
  options: { prefix?: string; includeQR?: boolean; qrSize?: number } = {}
): { whatsappLink: string; qrCodeUrl: string | null; fullMessage: string } {
  const { prefix = WHATSAPP_MESSAGE_PREFIX, includeQR = true, qrSize = 300 } = options
  
  const fullMessage = `${prefix} ${emojiString}`
  const whatsappLink = generateWhatsAppLink({
    phoneNumber,
    message: emojiString,
    prefix
  })
  
  const qrCodeUrl = includeQR ? generateQRCodeUrl(whatsappLink, qrSize) : null
  
  return {
    whatsappLink,
    qrCodeUrl,
    fullMessage
  }
}
