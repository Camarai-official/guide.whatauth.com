import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { CamarauthClient } from './client';

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });
}

describe('CamarauthClient contracts', () => {
  const fetchMock = vi.fn();

  beforeEach(() => {
    fetchMock.mockReset();
    vi.stubGlobal('fetch', fetchMock);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('sends pin and emojiString to /register-pin', async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse({ success: true }));
    const client = new CamarauthClient({ apiUrl: 'http://localhost:3001' });

    await client.registerPin('ABC123');

    const [url, requestInit] = fetchMock.mock.calls[0] as [string, RequestInit];
    const body = JSON.parse(String(requestInit.body));

    expect(url).toBe('http://localhost:3001/register-pin');
    expect(requestInit.method).toBe('POST');
    expect(body.pin).toBe('ABC123');
    expect(typeof body.emojiString).toBe('string');
    expect(body.emojiString.length).toBeGreaterThan(0);
  });

  it('refreshes token with POST payload', async () => {
    fetchMock.mockResolvedValueOnce(
      jsonResponse({ success: true, token: 'new-token', refreshToken: 'refresh-token' })
    );
    const client = new CamarauthClient({ apiUrl: 'http://localhost:3001' });

    await client.refreshToken('refresh-token');

    const [url, requestInit] = fetchMock.mock.calls[0] as [string, RequestInit];
    const body = JSON.parse(String(requestInit.body));

    expect(url).toBe('http://localhost:3001/refresh-token');
    expect(requestInit.method).toBe('POST');
    expect(body).toEqual({ refreshToken: 'refresh-token' });
  });

  it('sends logout payload with userId', async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse({ success: true, message: 'Logout exitoso' }));
    const client = new CamarauthClient({ apiUrl: 'http://localhost:3001' });

    await client.logout('access-token', 'user-123');

    const [url, requestInit] = fetchMock.mock.calls[0] as [string, RequestInit];
    const body = JSON.parse(String(requestInit.body));
    const headers = requestInit.headers as Record<string, string>;

    expect(url).toBe('http://localhost:3001/logout');
    expect(requestInit.method).toBe('POST');
    expect(body).toEqual({ userId: 'user-123' });
    expect(headers.Authorization).toBe('Bearer access-token');
  });
});
