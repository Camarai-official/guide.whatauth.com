import { Command } from 'commander';
import { WhatauthBackend } from './backend/index';

const program = new Command();

program
  .name('whatauth-sdk')
  .description('Whatauth SDK - Autenticación WhatsApp para Node.js y React')
  .version('3.0.0');

program
  .command('init')
  .description('Muestra la guía de configuración')
  .action(async () => {
    console.log(`
\x1b[36m⚡ Whatauth SDK - Guía de Configuración\x1b[0m

\x1b[33m1. Instala el SDK:\x1b[0m
   npm install whatauth-sdk

\x1b[33m2. Configura el Backend (Node.js):\x1b[0m
   
   \x1b[2mimport { WhatauthBackend } from 'whatauth-sdk/backend';\x1b[0m
   \x1b[2m\x1b[0m
   \x1b[2mconst backend = new WhatauthBackend({\x1b[0m
   \x1b[2m  port: 3001,\x1b[0m
   \x1b[2m  evolutionApiUrl: 'https://tu-evolution-api.com',\x1b[0m
   \x1b[2m  evolutionApiKey: 'tu-api-key',\x1b[0m
   \x1b[2m  evolutionInstanceName: 'mi-instancia-whatsapp'\x1b[0m
   \x1b[2m});\x1b[0m
   \x1b[2m\x1b[0m
   \x1b[2mbackend.start();\x1b[0m

\x1b[33m3. Configura el Frontend (React):\x1b[0m
   
   \x1b[2mimport { AuthProvider } from 'whatauth-sdk/react';\x1b[0m
   \x1b[2m\x1b[0m
   \x1b[2mfunction App() {\x1b[0m
   \x1b[2m  return (\x1b[0m
   \x1b[2m    <AuthProvider apiUrl="http://localhost:3001">\x1b[0m
   \x1b[2m      <LoginPage />\x1b[0m
   \x1b[2m    </AuthProvider>\x1b[0m
   \x1b[2m  );\x1b[0m
   \x1b[2m}\x1b[0m

\x1b[33m4. Usa el hook usePinAuth:\x1b[0m
   
   \x1b[2mimport { usePinAuth } from 'whatauth-sdk/react';\x1b[0m
   \x1b[2m\x1b[0m
   \x1b[2mfunction LoginPage() {\x1b[0m
   \x1b[2m  const { pin, emojis, status, generate, user } = usePinAuth({\x1b[0m
   \x1b[2m    apiUrl: 'http://localhost:3001',\x1b[0m
   \x1b[2m    onSuccess: (user) => console.log('Login:', user)\x1b[0m
   \x1b[2m  });\x1b[0m
   \x1b[2m  // ...\x1b[0m
   \x1b[2m}\x1b[0m

\x1b[32mIniciar el servidor backend:\x1b[0m
   npx whatauth-sdk backend --port 3001

\x1b[33mVariables de Entorno:\x1b[0m
   - PORT: Puerto del servidor (default: 3001)
   - JWT_SECRET: Clave secreta para JWT
   - EVOLUTION_WEBHOOK_SECRET: Secreto para firma webhook
   - EVOLUTION_API_URL: URL de tu Evolution API
   - EVOLUTION_API_KEY: API Key de Evolution
   - EVOLUTION_INSTANCE_NAME: Nombre de la instancia WhatsApp
   - PIN_EXPIRATION_MINUTES: Minutos de expiración del PIN
   - CORS_ORIGINS: Orígenes permitidos (separados por coma)

\x1b[36mRequisitos:\x1b[0m
   - Tener Evolution API corriendo
   - Instancia de WhatsApp configurada y conectada
   - Configurar webhook en Evolution: http://TU_IP:3001/webhook/evolution
     `);
  });

program
  .command('backend')
  .description('Inicia el servidor backend de Whatauth')
  .option('-p, --port <number>', 'Puerto', '3001')
  .option('-s, --secret <string>', 'JWT secret')
  .option('--evolution-url <url>', 'Evolution API URL (requerido)')
  .option('--evolution-key <key>', 'Evolution API Key (requerido)')
  .option('--evolution-instance <name>', 'Nombre de la instancia (requerido)')
  .option('--webhook-secret <secret>', 'Secreto para validar firma webhook')
  .option('--pin-expiry <minutes>', 'Expiración del PIN en minutos', '3')
  .option('--cors-origins <origins>', 'Orígenes CORS (separados por coma)')
  .action((options) => {
    const port = parseInt(options.port, 10);
    const pinExpirationMinutes = parseInt(options.pinExpiry, 10);
    
    const evolutionUrl = options.evolutionUrl || process.env.EVOLUTION_API_URL;
    const evolutionKey = options.evolutionKey || process.env.EVOLUTION_API_KEY;
    const evolutionInstance = options.evolutionInstance || process.env.EVOLUTION_INSTANCE_NAME;
    
    if (!evolutionUrl || !evolutionKey || !evolutionInstance) {
      console.error('\n\x1b[31m❌ Error: Faltan parámetros requeridos\x1b[0m\n');
      console.log('El backend requiere configuración de Evolution API:\n');
      console.log('Opciones:');
      console.log('  1. Variables de entorno:');
      console.log('     EVOLUTION_API_URL, EVOLUTION_API_KEY, EVOLUTION_INSTANCE_NAME');
      console.log('  2. Parámetros CLI:');
      console.log('     --evolution-url, --evolution-key, --evolution-instance\n');
      console.log('Ejemplo:');
      console.log('  npx whatauth-sdk backend \\\n');
      console.log('    --evolution-url https://api.evolution.com \\\n');
      console.log('    --evolution-key mi-api-key \\\n');
      console.log('    --evolution-instance mi-whatsapp\n');
      process.exit(1);
    }
    
    try {
      const backend = new WhatauthBackend({
        port,
        jwtSecret: options.secret || process.env.JWT_SECRET,
        webhookSecret: options.webhookSecret || process.env.EVOLUTION_WEBHOOK_SECRET || process.env.WEBHOOK_SECRET,
        evolutionApiUrl: evolutionUrl,
        evolutionApiKey: evolutionKey,
        evolutionInstanceName: evolutionInstance,
        pinExpirationMinutes,
        corsOrigins: options.corsOrigins || process.env.CORS_ORIGINS
      });
      
      backend.start();
    } catch (error: any) {
      console.error('\n\x1b[31m❌ Error al iniciar el backend:\x1b[0m', error.message);
      process.exit(1);
    }
  });

program.parse();
