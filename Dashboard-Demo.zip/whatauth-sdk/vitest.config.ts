import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    coverage: {
      provider: 'v8',
      all: false,
      reporter: ['text', 'json', 'html'],
      thresholds: {
        lines: 79,
        functions: 80,
        statements: 79,
        branches: 70
      },
      exclude: [
        'node_modules/',
        'dist/',
        '**/*.d.ts',
        '**/*.test.ts',
        '**/*.test.tsx',
        'examples/',
        'src/e2e/'
      ]
    },
    globals: true,
    environment: 'node'
  }
});
