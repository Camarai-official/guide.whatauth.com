/**
 * Ejemplo básico: Servidor Node.js con Whatauth Backend
 * 
 * Este ejemplo muestra cómo configurar un servidor Express
 * con autenticación por PIN de WhatsApp usando Whatauth SDK.
 */

import { WhatauthBackend } from 'whatauth-sdk/backend';
import dotenv from 'dotenv';

// Cargar variables de entorno
dotenv.config();

// Validar variables requeridas
const requiredEnv = [
  'EVOLUTION_API_URL',
  'EVOLUTION_API_KEY',
  'EVOLUTION_INSTANCE_NAME',
  'JWT_SECRET'
];

for (const env of requiredEnv) {
  if (!process.env[env]) {
    console.error(`❌ Error: Falta variable de entorno ${env}`);
    process.exit(1);
  }
}

// Crear y configurar el backend
const backend = new WhatauthBackend({
  port: parseInt(process.env.PORT || '3001'),
  host: process.env.HOST || '0.0.0.0',
  jwtSecret: process.env.JWT_SECRET,
  webhookSecret: process.env.EVOLUTION_WEBHOOK_SECRET,
  evolutionApiUrl: process.env.EVOLUTION_API_URL!,
  evolutionApiKey: process.env.EVOLUTION_API_KEY!,
  evolutionInstanceName: process.env.EVOLUTION_INSTANCE_NAME!,
  pinExpirationMinutes: parseInt(process.env.PIN_EXPIRATION_MINUTES || '3'),
  corsOrigins: process.env.CORS_ORIGINS?.split(',') || ['http://localhost:3000']
});

// Manejar eventos de autenticación
backend.on('auth:verified', (data) => {
  console.log('✅ Usuario autenticado:', {
    userId: data.userId,
    phoneNumber: data.phoneNumber,
    nombre: data.userData.nombre
  });
});

// Iniciar servidor
backend.start();

// Manejar señales de terminación
process.on('SIGTERM', async () => {
  console.log('\n👋 Cerrando servidor...');
  await backend.stop();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('\n👋 Cerrando servidor...');
  await backend.stop();
  process.exit(0);
});
