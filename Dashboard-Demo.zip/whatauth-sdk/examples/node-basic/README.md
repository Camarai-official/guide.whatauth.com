# Camarauth SDK - Node.js Basic Example

Ejemplo básico de uso del backend de Camarauth SDK en Node.js.

## Instalación

```bash
npm install
```

## Configuración

Copia `.env.example` a `.env` y configura tus variables:

```bash
cp .env.example .env
```

Edita `.env` con tus credenciales de Evolution API.

## Uso

### Desarrollo

```bash
npm run dev
```

### Producción

```bash
npm run build
npm start
```

## Endpoints disponibles

- `POST /register-pin` - Registrar un nuevo PIN
- `POST /check-login` - Verificar estado de login
- `POST /webhook/evolution` - Webhook para Evolution API
- `POST /refresh-token` - Refrescar token
- `GET /profile` - Obtener perfil
- `POST /logout` - Cerrar sesión

## Estructura

- `src/server.ts` - Servidor Express con CamarauthBackend
- `src/routes.ts` - Rutas adicionales (opcional)

## Variables de entorno

Ver `.env.example` para todas las opciones disponibles.
