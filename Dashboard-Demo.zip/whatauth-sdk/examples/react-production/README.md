# Whatauth SDK - React Production Example

Ejemplo completo de implementación en producción usando `WhatauthWorkerClient` con soporte multi-tenant y WebSocket.

## Características

- ✅ **WhatauthWorkerClient** - Cliente optimizado para producción
- ✅ **Multi-tenant Support** - Soporte para múltiples tenants
- ✅ **WebSocket Real-time** - Comunicación en tiempo real
- ✅ **Session Management** - Manejo persistente de sesiones
- ✅ **Error Handling** - Manejo robusto de errores
- ✅ **QR Code Integration** - Códigos QR para WhatsApp
- ✅ **Countdown Timer** - Temporizador con expiración automática
- ✅ **Environment Variables** - Configuración segura

## Instalación

```bash
npm install
```

## Configuración

### 1. Variables de Entorno

Crea un archivo `.env` en la raíz:

```env
# Whatauth Worker Configuration
VITE_WHATAUTH_WORKER_URL=https://your-worker.your-domain.com
VITE_WHATAUTH_CLIENT_ID=your-client-id
VITE_WHATAUTH_TENANT_SLUG=default

# WhatsApp Configuration
VITE_WHATSAPP_NUMBER=+1234567890
```

### 2. Dependencias Adicionales

```bash
npm install react-qr-code
```

## Uso

### Desarrollo

```bash
npm run dev
```

### Build

```bash
npm run build
```

## Arquitectura del Ejemplo

### Flujo de Autenticación

1. **Inicialización**: `initSession()` - Configura la sesión del cliente
2. **Conexión WebSocket**: `connectWebSocket()` - Establece conexión real-time
3. **Registro PIN**: `registerPin()` - Solicita un nuevo PIN
4. **Callbacks**: Manejo de eventos con `setCallbacks()`
5. **Intercambio de Código**: `exchangeAuthCode()` - Obtiene tokens de acceso
6. **Persistencia**: Guarda sesión en localStorage
7. **Context Update**: Actualiza estado global de autenticación

### Componentes Principales

- **LoginPage**: Componente principal con flujo completo de autenticación
- **AuthProvider**: Contexto global de autenticación
- **QRCode**: Generación de códigos QR para WhatsApp

### Estados de Autenticación

- `idle`: Estado inicial, esperando acción del usuario
- `polling`: PIN generado, esperando autenticación
- `success`: Usuario autenticado exitosamente
- `error`: Error en el proceso de autenticación
- `expired`: PIN expirado, necesita regeneración

## Manejo de Errores

El ejemplo incluye manejo robusto de errores:

- **Conexión WebSocket**: Reintentos automáticos
- **PIN Expirado**: Regeneración automática o manual
- **Errores de Red**: Mensajes amigables y reintentos
- **Validación**: Verificación de configuración requerida

## Integración con Backend

Este ejemplo está diseñado para funcionar con:

- **Whatauth Worker**: Backend basado en Cloudflare Workers
- **Multi-tenant Architecture**: Soporte para múltiples organizaciones
- **Real-time Updates**: Comunicación vía WebSocket
- **JWT Tokens**: Autenticación basada en JSON Web Tokens

## Personalización

### Tema y Estilos

El ejemplo usa Tailwind CSS para estilos. Puedes personalizar:

- Colores y branding
- Layout y responsive design
- Animaciones y transiciones
- Componentes UI

### Flujo de Autenticación

Puedes modificar:

- Tiempo de expiración del PIN
- Número máximo de regeneraciones
- Comportamiento de callbacks
- Manejo de sesiones

## Mejores Prácticas

### Seguridad

- Usa variables de entorno para datos sensibles
- Valida tokens en cada request
- Implementa logout seguro
- Limpia sesiones expiradas

### Performance

- Lazy loading de componentes
- Optimización de re-renders
- Memoización de callbacks
- Limpieza de efectos

### UX

- Indicadores de carga claros
- Mensajes de error específicos
- Feedback visual inmediato
- Accesibilidad WCAG

## Troubleshooting

### Problemas Comunes

1. **WebSocket Connection Failed**
   - Verifica URL del worker
   - Revisa configuración CORS
   - Confirma clientId y tenantSlug

2. **PIN Not Generated**
   - Verifica variables de entorno
   - Revisa conexión a internet
   - Confirma configuración del worker

3. **Session Not Persisting**
   - Verifica localStorage disponible
   - Revisa formato de datos guardados
   - Confirma token válido

### Debug Mode

Activa modo debug en desarrollo:

```typescript
// En development
if (import.meta.env.DEV) {
  console.log('Whatauth Debug:', { loginCode, authStatus, timeLeft });
}
```

## Deployment

### Vercel

```bash
npm run build
vercel --prod
```

### Netlify

```bash
npm run build
netlify deploy --prod --dir=dist
```

### Cloudflare Pages

```bash
npm run build
wrangler pages publish dist
```

## Soporte

- **Documentación**: [Whatauth SDK Docs](https://docs.whatauth.com)
- **Issues**: [GitHub Issues](https://github.com/whatauth/sdk/issues)
- **Discord**: [Comunidad Whatauth](https://discord.gg/whatauth)
