# Camarauth SDK - React Basic Example

Ejemplo básico de autenticación con PIN de WhatsApp en React.

## Instalación

```bash
npm install
```

## Configuración

Copia `.env.example` a `.env` y configura la URL del backend:

```bash
cp .env.example .env
```

## Uso

### Desarrollo

```bash
npm run dev
```

### Build

```bash
npm run build
```

## Estructura

- `src/App.tsx` - Componente principal con flujo de autenticación
- `src/main.tsx` - Punto de entrada

## Características

- Generación automática de PIN
- Código QR para WhatsApp
- Temporizador de expiración
- Regeneración automática
- Manejo de errores
