/**
 * Ejemplo básico: React con autenticación por PIN
 * 
 * Este ejemplo muestra cómo usar los hooks de Whatauth SDK
 * para implementar autenticación por PIN de WhatsApp en React.
 */

import { usePinAuth, AuthProvider } from 'whatauth-sdk/react';
import { useState } from 'react';

// Número de WhatsApp para enviar el PIN (reemplazar con el tuyo)
const WHATSAPP_NUMBER = '+34600123456';

function AuthComponent() {
  const {
    pin,
    emojiString,
    timeLeft,
    formattedTime,
    isExpired,
    status,
    user,
    error,
    whatsappLink,
    qrCodeUrl,
    generate,
    cancel,
    reset
  } = usePinAuth({
    apiUrl: import.meta.env.VITE_API_URL || 'http://localhost:3001',
    whatsappNumber: WHATSAPP_NUMBER,
    maxAutoRegenerations: 3,
    onSuccess: (user) => {
      console.log('✅ Autenticado:', user);
    },
    onError: (err) => {
      console.error('❌ Error:', err);
    }
  });

  if (user) {
    return (
      <div className="success-container">
        <h2>¡Bienvenido! 🎉</h2>
        <div className="user-info">
          <p><strong>Nombre:</strong> {user.nombre}</p>
          <p><strong>Teléfono:</strong> {user.telefono}</p>
          <p><strong>Roles:</strong> {user.roles?.join(', ')}</p>
        </div>
        <button onClick={reset} className="btn-primary">
          Cerrar Sesión
        </button>
      </div>
    );
  }

  return (
    <div className="auth-container">
      <h2>Iniciar Sesión</h2>
      
      {status === 'idle' && (
        <div className="start-section">
          <p>Haz clic para generar un PIN de verificación</p>
          <button onClick={generate} className="btn-primary">
            Generar PIN
          </button>
        </div>
      )}

      {status === 'polling' && pin && (
        <div className="pin-section">
          <div className="pin-display">
            <span className="pin-text">{pin}</span>
            <span className="pin-emojis">{emojiString}</span>
          </div>

          <div className="timer">
            Expira en: <strong>{formattedTime}</strong>
          </div>

          <div className="whatsapp-section">
            <p>Envía el PIN por WhatsApp:</p>
            <a 
              href={whatsappLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="btn-whatsapp"
            >
              Abrir WhatsApp
            </a>
          </div>

          <button onClick={cancel} className="btn-secondary">
            Cancelar
          </button>
        </div>
      )}

      {isExpired && (
        <div className="expired-section">
          <p>El PIN ha expirado ⏰</p>
          <button onClick={generate} className="btn-primary">
            Generar Nuevo PIN
          </button>
        </div>
      )}

      {error && (
        <div className="error-section">
          <p className="error">{error.message}</p>
          <button onClick={reset} className="btn-secondary">
            Intentar de Nuevo
          </button>
        </div>
      )}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <div className="app">
        <header>
          <h1>Camarauth SDK - React Example</h1>
        </header>
        <main>
          <AuthComponent />
        </main>
      </div>
    </AuthProvider>
  );
}

export default App;
