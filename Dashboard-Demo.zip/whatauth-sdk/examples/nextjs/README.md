# Camarauth SDK - Next.js Example

Ejemplo de autenticación con PIN de WhatsApp en Next.js usando App Router.

## Instalación

```bash
npm install
```

## Configuración

Copia `.env.local.example` a `.env.local`:

```bash
cp .env.local.example .env.local
```

## Uso

### Desarrollo

```bash
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000) en tu navegador.

## Estructura

- `app/page.tsx` - Página principal con login
- `app/dashboard/page.tsx` - Página protegida
- `app/layout.tsx` - Layout con AuthProvider
- `components/LoginForm.tsx` - Formulario de login
- `middleware.ts` - Protección de rutas

## Características

- Server-side rendering compatible
- Middleware de autenticación
- Server Components protegidos
- Client Components interactivos
