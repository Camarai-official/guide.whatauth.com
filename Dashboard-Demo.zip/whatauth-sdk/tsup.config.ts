import { defineConfig } from 'tsup';

export default defineConfig([
  // Core Logic (Universal)
  {
    entry: ['src/core/index.ts'],
    format: ['esm', 'cjs'],
    dts: true,
    platform: 'neutral',
    outDir: 'dist/core',
    external: ['jwt-decode', 'socket.io-client'],
    clean: true,
  },
  // React Adapter
  {
    entry: ['src/react/index.ts'],
    format: ['esm', 'cjs'],
    dts: true,
    platform: 'browser',
    external: ['react', 'react-dom'],
    outDir: 'dist/react',
    clean: true,
  },
  // Server Utilities (Node.js)
  {
    entry: ['src/server/index.ts'],
    format: ['esm', 'cjs'],
    dts: true,
    platform: 'node',
    external: ['express', 'crypto', 'jsonwebtoken', 'socket.io', 'cors'],
    outDir: 'dist/server',
    clean: true,
  },
  // Backend Server (Node.js)
  {
    entry: ['src/backend/index.ts'],
    format: ['esm', 'cjs'],
    dts: true,
    platform: 'node',
    external: ['express', 'jsonwebtoken', 'socket.io', 'cors'],
    outDir: 'dist/backend',
    clean: true,
  },
  // CLI Tool
  {
    entry: ['src/cli.ts'],
    format: ['esm'],
    platform: 'node',
    external: ['commander', 'express', 'cors', 'socket.io', 'jsonwebtoken'],
    outDir: 'dist/cli',
    clean: true,
    banner: {
      js: '#!/usr/bin/env node',
    },
  },
]);
