#!/usr/bin/env node
/**
 * SDK-033: Install-from-pack test script (Cross-platform)
 * 
 * Este script verifica que el paquete se puede instalar desde tarball
 * Funciona en Windows, macOS y Linux
 * 
 * NOTA: Este archivo debe ejecutarse con Node.js como CommonJS
 * porque el proyecto tiene "type": "module" en package.json.
 * Usamos .cjs extension o ejecutamos con --input-type=commonjs
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';

// Obtener __dirname en ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('📦 SDK-033: Install-from-pack test (Cross-platform)');
console.log('');

// Detectar sistema operativo
const isWindows = process.platform === 'win32';

// Función para ejecutar comandos
function run(command, cwd = process.cwd()) {
  console.log(`> ${command}`);
  try {
    const result = execSync(command, { 
      cwd, 
      encoding: 'utf8',
      stdio: 'pipe'
    });
    return result.trim();
  } catch (error) {
    console.error(`Error executing: ${command}`);
    console.error(error.stderr || error.message);
    throw error;
  }
}

// Crear directorio temporal
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'whatauth-test-'));
console.log(`Creating temp directory: ${tempDir}`);

// Guardar directorio original
const originalDir = process.cwd();

try {
  // Generar tarball
  console.log('📦 Generating tarball...');
  const tarballName = run('npm pack').split('\n').pop();
  console.log(`📦 Tarball generated: ${tarballName}`);
  console.log('');

  // Copiar tarball al directorio temporal
  const tarballPath = path.join(originalDir, tarballName);
  const tempTarballPath = path.join(tempDir, tarballName);
  fs.copyFileSync(tarballPath, tempTarballPath);

  // Cambiar al directorio temporal
  process.chdir(tempDir);

  // Inicializar un nuevo proyecto npm
  console.log('📦 Initializing test project...');
  run('npm init -y');

  // Instalar el tarball
  console.log('📦 Installing tarball...');
  const installCmd = isWindows 
    ? `npm install "${tempTarballPath}"`
    : `npm install "./${tarballName}"`;
  run(installCmd);
  console.log('');

  // Verificar que los imports funcionan (CJS)
  console.log('🔍 Testing CJS imports...');
  
  const cjsTest = `
const core = require('whatauth-sdk');
console.log('✓ Core (CJS):', Object.keys(core).slice(0, 5));

const backend = require('whatauth-sdk/backend');
console.log('✓ Backend (CJS):', Object.keys(backend).slice(0, 5));

const server = require('whatauth-sdk/server');
console.log('✓ Server (CJS):', Object.keys(server).slice(0, 5));
`;
  
  fs.writeFileSync('test-cjs.js', cjsTest);
  run('node test-cjs.js');

  // Verificar que los imports funcionan (ESM)
  console.log('');
  console.log('🔍 Testing ESM imports...');
  
  const esmTest = `
import * as core from 'whatauth-sdk';
console.log('✓ Core (ESM):', Object.keys(core).slice(0, 5));

import * as backend from 'whatauth-sdk/backend';
console.log('✓ Backend (ESM):', Object.keys(backend).slice(0, 5));

import * as server from 'whatauth-sdk/server';
console.log('✓ Server (ESM):', Object.keys(server).slice(0, 5));

console.log('');
console.log('✅ All imports successful!');
`;
  
  fs.writeFileSync('test-esm.mjs', esmTest);
  
  // Agregar type: module para ESM
  const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  packageJson.type = 'module';
  fs.writeFileSync('package.json', JSON.stringify(packageJson, null, 2));
  
  run('node test-esm.mjs');

  console.log('');
  console.log('✅ SDK-033: Install-from-pack test PASSED!');
  
} catch (error) {
  console.error('');
  console.error('❌ SDK-033: Install-from-pack test FAILED!');
  process.exit(1);
} finally {
  // Limpiar
  process.chdir(originalDir);
  
  // Eliminar tarball generado
  try {
    const tarballName = fs.readdirSync(originalDir).find(f => f.startsWith('whatauth-sdk-') && f.endsWith('.tgz'));
    if (tarballName) {
      fs.unlinkSync(path.join(originalDir, tarballName));
    }
  } catch (e) {
    // Ignorar errores de limpieza
  }
  
  // Eliminar directorio temporal
  try {
    fs.rmSync(tempDir, { recursive: true, force: true });
  } catch (e) {
    // Ignorar errores de limpieza
  }
}
