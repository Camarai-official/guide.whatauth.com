import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

const ALLOWED_IMPORTS = new Set([
  'whatauth-sdk',
  'whatauth-sdk/react',
  'whatauth-sdk/server',
  'whatauth-sdk/backend'
]);

function findDocs(dir, files = []) {
  const items = readdirSync(dir);

  for (const item of items) {
    const fullPath = join(dir, item);
    const stat = statSync(fullPath);

    if (stat.isDirectory()) {
      if (item === 'node_modules' || item === '.git' || item === 'dist') {
        continue;
      }

      findDocs(fullPath, files);
      continue;
    }

    if (item.endsWith('.md') || item.endsWith('.mdx')) {
      files.push(fullPath);
    }
  }

  return files;
}

function extractSdkImports(content) {
  const regex = /from\s+['"](whatauth-sdk[^'"]*)['"]/g;
  const imports = [];

  let match = regex.exec(content);
  while (match) {
    imports.push(match[1]);
    match = regex.exec(content);
  }

  return imports;
}

function validateImportPath(importPath, sourceLabel) {
  if (ALLOWED_IMPORTS.has(importPath)) {
    console.log(`OK valid import in ${sourceLabel}: ${importPath}`);
    return true;
  }

  console.error(`ERROR invalid import in ${sourceLabel}: ${importPath}`);
  return false;
}

let hasErrors = false;

const docs = findDocs('.');
for (const docPath of docs) {
  const content = readFileSync(docPath, 'utf8');
  const imports = extractSdkImports(content);

  for (const importPath of imports) {
    const isValid = validateImportPath(importPath, docPath);
    if (!isValid) {
      hasErrors = true;
    }
  }
}

if (existsSync('README.md')) {
  const readme = readFileSync('README.md', 'utf8');
  const blocks = [...readme.matchAll(/```(?:typescript|tsx)\n([\s\S]*?)\n```/g)];

  console.log(`Found ${blocks.length} TypeScript/TSX blocks in README`);

  for (let index = 0; index < blocks.length; index += 1) {
    const code = blocks[index][1] ?? '';
    const imports = extractSdkImports(code);

    for (const importPath of imports) {
      const sourceLabel = `README.md#block-${index + 1}`;
      const isValid = validateImportPath(importPath, sourceLabel);
      if (!isValid) {
        hasErrors = true;
      }
    }
  }
}

if (hasErrors) {
  process.exit(1);
}

console.log('OK all documentation imports are valid');
