import { useEffect, useState } from "react";
import { WhatauthWorkerClient } from "whatauth-sdk";
import QRCode from 'qrcode';

// Configuración desde variables de entorno
const WHATSAPP_NUMBER = import.meta.env.VITE_WHATSAPP_NUMBER;
const BACKEND_URL = import.meta.env.VITE_WHATAUTH_WORKER_URL;
const CLIENT_ID = import.meta.env.VITE_WHATAUTH_CLIENT_ID;
const TENANT_SLUG = import.meta.env.VITE_WHATAUTH_TENANT_SLUG;

// Función para formatear el tiempo
const formatTime = (seconds: number): string => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
};

interface User {
  id: string;
  name?: string;
  phone?: string;
}

interface AuthData {
  token: string;
  user: User;
}

const LoginExample = () => {
  // Estados del componente
  const [hasStarted, setHasStarted] = useState(false);
  
  // Estados de Whatauth
  const [workerClient] = useState(() => new WhatauthWorkerClient({
    apiUrl: BACKEND_URL,
    clientId: CLIENT_ID,
    tenantSlug: TENANT_SLUG,
  }));
  
  const [loginCode, setLoginCode] = useState<string | null>(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(180);
  const [authStatus, setAuthStatus] = useState<'idle' | 'polling' | 'success' | 'error' | 'expired'>('idle');
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Configurar callbacks del cliente Whatauth
  useEffect(() => {
    workerClient.setCallbacks({
      onPinRegistered: async (code, ttl) => {
        setLoginCode(code);
        setTimeLeft(ttl);
        setAuthStatus('polling');
        console.log('PIN registrado:', code);
        
        // Generar QR Code
        try {
          const qrUrl = `https://wa.me/${WHATSAPP_NUMBER.replace('+', '')}?text=${encodeURIComponent(code)}`;
          const qrDataUrl = await QRCode.toDataURL(qrUrl, {
            width: 200,
            margin: 1,
            color: {
              dark: '#000000',
              light: '#FFFFFF'
            }
          });
          setQrCodeDataUrl(qrDataUrl);
        } catch (error) {
          console.error('Error generando QR Code:', error);
        }
      },
      onAuthCodeIssued: async (authCode: string, expiresIn: number) => {
        try {
          console.log("Auth code issued:", authCode, "expires in:", expiresIn);
          const auth = await workerClient.exchangeAuthCode();
          console.log("Autenticación exitosa:", auth);
          
          const userObj: User = {
            id: auth.user?.id || 'unknown',
            name: auth.user?.name || 'Usuario',
            phone: auth.user?.phone,
          };
          
          // Guardar sesión en localStorage
          if (auth.token) {
            const sessionData: AuthData = {
              token: auth.token,
              user: auth.user || {
                id: 'unknown',
                name: 'Usuario',
                phone: undefined
              }
            };
            localStorage.setItem('whatauth_session', JSON.stringify(sessionData));
            console.log("Sesión guardada en localStorage");
          }
          
          setUser(userObj);
          setIsAuthenticated(true);
          setAuthStatus('success');
        } catch (error) {
          console.error("Error intercambiando código de autorización:", error);
          setAuthStatus('error');
        }
      },
      onError: (err) => {
        console.error("Error en autenticación:", err);
        setAuthStatus('error');
      },
      onExpired: () => {
        console.log("PIN expirado");
        setAuthStatus('expired');
      },
    });
  }, [workerClient]);

  // Efecto para el countdown
  useEffect(() => {
    if (authStatus !== 'polling' || timeLeft <= 0) return;
    const timer = setTimeout(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);
    return () => clearTimeout(timer);
  }, [authStatus, timeLeft]);

  // Auto-expirar cuando el tiempo llega a 0
  useEffect(() => {
    if (timeLeft === 0 && authStatus === 'polling') {
      setAuthStatus('expired');
    }
  }, [timeLeft, authStatus]);


  // Verificar si ya hay una sesión activa al cargar
  useEffect(() => {
    const savedSession = localStorage.getItem('whatauth_session');
    if (savedSession) {
      try {
        const sessionData: AuthData = JSON.parse(savedSession);
        setUser(sessionData.user);
        setIsAuthenticated(true);
        setAuthStatus('success');
      } catch (error) {
        console.error("Error leyendo sesión guardada:", error);
        localStorage.removeItem('whatauth_session');
      }
    }
  }, []);

  // Iniciar automáticamente el flujo de login
  useEffect(() => {
    if (
      !isAuthenticated &&
      !hasStarted &&
      (authStatus === "idle" || authStatus === "error")
    ) {
      startWorkerFlow();
      setHasStarted(true);
    }
  }, [isAuthenticated, hasStarted, authStatus]);

  const startWorkerFlow = async () => {
    try {
      setAuthStatus('idle');
      console.log("Iniciando flujo de autenticación...");
      
      await workerClient.initSession();
      console.log("Sesión iniciada");
      
      await workerClient.connectWebSocket();
      console.log("WebSocket conectado");
      
      // Esperar un momento para asegurar que el WebSocket esté completamente conectado
      await new Promise(resolve => setTimeout(resolve, 100));
      
      await workerClient.registerPin();
      console.log("PIN registrado");
    } catch (err) {
      console.error("Error iniciando flujo:", err);
      setAuthStatus('error');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('whatauth_session');
    setUser(null);
    setIsAuthenticated(false);
    setAuthStatus('idle');
    setLoginCode(null);
    setQrCodeDataUrl(null);
    setTimeLeft(180);
    setHasStarted(false);
  };

  // Si está autenticado, mostrar dashboard simple
  if (isAuthenticated && user) {
    return (
      <div className="font-['Inter',sans-serif] w-full min-h-screen flex justify-center items-center bg-gray-50">
        <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">
            ¡Bienvenido, {user.name}!
          </h1>
          <div className="space-y-2 text-gray-600 mb-6">
            <p><strong>ID:</strong> {user.id}</p>
            {user.phone && <p><strong>Teléfono:</strong> {user.phone}</p>}
          </div>
          <button
            onClick={handleLogout}
            className="w-full bg-red-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-red-600 transition-colors"
          >
            Cerrar sesión
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="font-['Inter',sans-serif] w-full min-h-screen flex justify-center items-center bg-gray-50">

      <div className="flex justify-center w-full relative z-[1] p-4">

        {/* TARJETA PRINCIPAL */}
        <div className="
          flex
          flex-col md:flex-row
          items-center md:items-stretch
          bg-white
          p-2
          border border-gray-200
          rounded-3xl
          w-full max-w-4xl
          relative
          overflow-hidden
          shadow-lg
        ">

          {/* --- IZQUIERDA (Logo/Info) --- */}
          <div className="relative flex flex-col justify-center items-center md:w-1/2 w-full text-center border-b md:border-b-0 md:border-r border-gray-200">

            <div className="relative z-10 flex flex-col justify-center items-center py-6">
              <div className="relative flex justify-center items-center mb-4">
                <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-3xl">📱</span>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-800">
                Whatauth
              </h2>
              <p className="text-gray-600 mt-2">
                Inicia sesión con WhatsApp usando emojis
              </p>
            </div>
          </div>

          {/* --- DERECHA (Flujo Login) --- */}
          <div className="flex flex-col justify-center md:w-1/2 w-full p-6">

            {/* Estado de autenticación por PIN */}
            {(authStatus === "polling" || authStatus === "expired") && loginCode && (
              <div className="space-y-4">
                
                {/* QR Code - con difuminado si expiró */}
                <div className="flex justify-center mb-4 relative">
                  <div className="bg-white p-3 rounded-lg relative border border-gray-200">
                    {qrCodeDataUrl ? (
                      <img 
                        src={qrCodeDataUrl} 
                        alt="QR Code para WhatsApp" 
                        width={200}
                        height={200}
                        className="rounded"
                      />
                    ) : (
                      <div className="w-[200px] h-[200px] flex items-center justify-center bg-gray-100 rounded">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-300"></div>
                      </div>
                    )}
                    
                    {/* Overlay difuminado cuando expira */}
                    {authStatus === "expired" && (
                      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm rounded-lg flex flex-col items-center justify-center">
                        <button 
                          onClick={startWorkerFlow}
                          className="bg-white/90 p-3 rounded-full mb-2 hover:bg-white transition-colors cursor-pointer"
                        >
                          <svg className="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                          </svg>
                        </button>
                        <span className="text-white text-sm font-medium">Código expirado</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <p className="text-sm text-gray-600 mb-3 text-center">
                  {authStatus === "expired" 
                    ? "El código ha expirado. Genera uno nuevo para continuar." 
                    : "Escanea el QR para enviar el código automáticamente"
                  }
                </p>

                {/* Código PIN - con difuminado si expiró */}
                <div className={`bg-gray-50 px-6 py-4 rounded-xl text-center relative ${authStatus === "expired" ? 'opacity-50' : ''}`}>
                  <p className="text-sm text-gray-600 mb-2">O envía manualmente:</p>
                  <div className="text-3xl tracking-wider font-mono mb-2 text-green-600">
                    {loginCode}
                  </div>
                  {authStatus === "expired" && (
                    <div className="absolute inset-0 bg-gray-50/80 backdrop-blur-sm rounded-xl flex items-center justify-center">
                      <span className="text-sm text-orange-500">Código expirado</span>
                    </div>
                  )}
                </div>

                {/* Botón de WhatsApp o regenerar */}
                <div className="flex justify-center">
                  {authStatus === "expired" ? (
                    <button
                      onClick={startWorkerFlow}
                      className="inline-flex items-center bg-green-500 text-white font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-green-600 transition-colors"
                    >
                      🔄 Generar nuevo código
                    </button>
                  ) : (
                    <a
                      href={`https://wa.me/${WHATSAPP_NUMBER.replace('+', '')}?text=${encodeURIComponent(loginCode)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center bg-green-500 text-white font-semibold px-4 py-2 rounded-lg shadow-md hover:bg-green-600 transition-colors"
                    >
                      📱 Enviar por WhatsApp
                    </a>
                  )}
                </div>

                {/* Temporizador */}
                <div className="flex items-center justify-center text-sm text-gray-600 mb-4">
                  <span className={authStatus === "expired" ? "text-orange-500" : ""}>
                    {authStatus === "expired" 
                      ? "⏰ Tiempo expirado" 
                      : <>⏱️ Expira en: <strong>{formatTime(timeLeft)}</strong></>
                    }
                  </span>
                </div>

                {/* Botón para generar nuevo PIN (solo cuando expiró) */}
                {authStatus === "expired" && (
                  <div className="flex justify-center">
                    <button
                      onClick={() => {
                        setHasStarted(false);
                        setAuthStatus('idle');
                      }}
                      className="inline-flex items-center bg-blue-500 text-white font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-blue-600 transition-colors"
                    >
                      🔄 Generar nuevo código
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Mensajes de estado */}
            {authStatus === "error" && (
              <div className="text-center">
                <div className="text-red-500 mb-4">
                  ❌ Ocurrió un error al conectar
                </div>
                <button 
                  onClick={startWorkerFlow}
                  className="bg-blue-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Intentar de nuevo
                </button>
              </div>
            )}

            {/* Mensaje inicial */}
            {authStatus === "idle" && !loginCode && (
              <div className="text-center text-gray-600">
                <div className="animate-pulse">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-green-500 mb-4"></div>
                  <p>Generando código de acceso...</p>
                </div>
              </div>
            )}

            {/* Estado de éxito */}
            {authStatus === "success" && !isAuthenticated && (
              <div className="text-center text-green-600">
                <div className="text-2xl mb-4">✅</div>
                <p>¡Autenticación exitosa!</p>
                <p className="text-sm text-gray-600 mt-2">Redirigiendo...</p>
              </div>
            )}

          </div>

        </div>
      </div>
    </div>
  );
};

export default LoginExample;
