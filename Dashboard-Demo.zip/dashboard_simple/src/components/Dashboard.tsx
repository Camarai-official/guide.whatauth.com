import { useEffect, useState } from 'react';

interface User {
  id: string;
  name?: string;
  phone?: string;
}

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedSession = localStorage.getItem('whatauth_session');
    if (savedSession) {
      try {
        const sessionData = JSON.parse(savedSession);
        setUser(sessionData.user);
      } catch (error) {
        console.error("Error leyendo sesión guardada:", error);
      }
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('whatauth_session');
    window.location.href = '/';
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold text-gray-900 text-center mb-8">
          Dashboard
        </h1>
        
        <div className="space-y-4 mb-8">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h2 className="text-lg font-semibold text-blue-900 mb-2">
              Información del Usuario
            </h2>
            <div className="space-y-2">
              <p className="text-gray-700">
                <span className="font-medium">Nombre:</span> {user.name}
              </p>
              {user.phone && (
                <p className="text-gray-700">
                  <span className="font-medium">Teléfono:</span> {user.phone}
                </p>
              )}
              <p className="text-gray-700">
                <span className="font-medium">ID:</span> {user.id}
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleLogout}
          className="w-full bg-red-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-red-700 transition-colors duration-200"
        >
          Cerrar Sesión
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
