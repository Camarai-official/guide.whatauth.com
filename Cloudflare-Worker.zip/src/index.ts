import { AuthTenantDO } from "./tenant-do";
import { isOriginAllowed, pickRequestOrigin } from "./origin";
import { createJwt, verifyJwt } from "./jwt";
import { verifyWebhookSignature } from "./webhook";

export { AuthTenantDO };

type Env = {
  ALLOWED_FRONTEND_ORIGINS: string;
  ALLOWED_COUNTRIES: string;
  EVOLUTION_WEBHOOK_SECRET?: string;
  JWT_SIGNING_KEY?: string;
  AUTH_TENANT: DurableObjectNamespace;
};

type SdkSessionClaims = {
  typ: "sdk_session";
  client_id: string;
  tenant_slug: string;
  origin: string;
};

function jsonResponse(body: unknown, init?: ResponseInit): Response {
  return new Response(JSON.stringify(body), {
    ...init,
    headers: {
      "content-type": "application/json; charset=utf-8",
      ...(init?.headers || {})
    }
  });
}

function forbidden(): Response {
  return jsonResponse({ error: "forbidden" }, { status: 403 });
}

function badRequest(): Response {
  return jsonResponse({ error: "bad_request" }, { status: 400 });
}

function withCors(req: Request, env: Env, res: Response): Response {
  const origin = pickRequestOrigin(req);
  if (!origin) return res;
  if (!isOriginAllowed(origin, env.ALLOWED_FRONTEND_ORIGINS)) return res;

  const headers = new Headers(res.headers);
  headers.set("access-control-allow-origin", origin);
  headers.set("vary", "Origin");
  headers.set("access-control-allow-methods", "GET,POST,OPTIONS");
  headers.set("access-control-allow-headers", "authorization,content-type");
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers });
}

async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    return null;
  }
}

function getBearer(req: Request): string | null {
  const raw = req.headers.get("authorization");
  if (!raw) return null;
  const m = raw.match(/^Bearer\s+(.+)$/i);
  return m?.[1]?.trim() || null;
}

export default {
  async fetch(req: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(req.url);

    // 1. Check country code from Cloudflare properties
    const country = req.cf?.country;

    // 2. Block requests from countries other than Spain
    if (country && !env.ALLOWED_COUNTRIES?.split(',').includes(country as string)) {
      console.log(`[COUNTRY_FILTER] Blocked request from country: ${country || 'unknown'}`);
      return new Response('Access denied: Your location is not allowed.', {
        status: 403,
        statusText: 'Forbidden'
      });
    }

    // 3. If Spain, continue with normal logic
    console.log(`[COUNTRY_FILTER] Allowed request from Spain (${country})`);

    if (req.method === "OPTIONS") {
      const res = new Response(null, { status: 204 });
      return withCors(req, env, res);
    }

    
    if (url.pathname === "/sdk/session/init" && req.method === "POST") {
      const origin = pickRequestOrigin(req);
      if (!origin) return forbidden();
      if (!isOriginAllowed(origin, env.ALLOWED_FRONTEND_ORIGINS)) return forbidden();

      const body = await readJson(req);
      if (!body || typeof body !== "object") return badRequest();
      const clientId = typeof (body as any).client_id === "string" ? (body as any).client_id : "";
      const tenantSlug = typeof (body as any).tenant_slug === "string" ? (body as any).tenant_slug : "";
      if (!clientId || !tenantSlug) return badRequest();

      const signingKey = env.JWT_SIGNING_KEY;
      if (!signingKey) return jsonResponse({ error: "server_not_configured" }, { status: 500 });

      const token = await createJwt<SdkSessionClaims>(
        signingKey,
        { typ: "sdk_session", client_id: clientId, tenant_slug: tenantSlug, origin },
        5 * 60
      );

      return withCors(req, env, jsonResponse({ sdk_session_jwt: token }));
    }

    if (url.pathname === "/ws" && req.method === "GET") {
      const origin = pickRequestOrigin(req);
      if (!origin) return forbidden();
      if (!isOriginAllowed(origin, env.ALLOWED_FRONTEND_ORIGINS)) return forbidden();

      const tenantSlug = url.searchParams.get("tenant_slug") || "";
      if (!tenantSlug) return forbidden();

      const token = url.searchParams.get("token") || getBearer(req);
      if (!token) return forbidden();

      const signingKey = env.JWT_SIGNING_KEY;
      if (!signingKey) return forbidden();

      const claims = await verifyJwt<SdkSessionClaims>(signingKey, token);
      if (!claims) return forbidden();
      if (claims.typ !== "sdk_session") return forbidden();
      if (claims.origin !== origin) return forbidden();
      if (claims.tenant_slug !== tenantSlug) return forbidden();

      const id = env.AUTH_TENANT.idFromName(tenantSlug);
      const stub = env.AUTH_TENANT.get(id);

      const proxyUrl = new URL(req.url);
      proxyUrl.pathname = "/do/ws";
      proxyUrl.searchParams.set("origin", origin);
      proxyUrl.searchParams.set("client_id", claims.client_id);

      const res = await stub.fetch(proxyUrl.toString(), req);
      return res;
    }

    if (url.pathname === "/sdk/token" && req.method === "POST") {
      console.log("[TOKEN] ===== /sdk/token request started =====");
      const origin = pickRequestOrigin(req);
      console.log("[TOKEN] Origin detected:", origin);
      console.log("[TOKEN] Allowed origins:", env.ALLOWED_FRONTEND_ORIGINS);
      if (!origin) {
        console.log("[TOKEN] ERROR: No origin detected");
        return forbidden();
      }
      if (!isOriginAllowed(origin, env.ALLOWED_FRONTEND_ORIGINS)) {
        console.log("[TOKEN] ERROR: Origin not allowed");
        return forbidden();
      }
      console.log("[TOKEN] CORS validation passed");

      const signingKey = env.JWT_SIGNING_KEY;
      if (!signingKey) {
        console.log("[TOKEN] ERROR: No signing key");
        return withCors(req, env, jsonResponse({ error: "server_not_configured" }, { status: 500 }));
      }

      const bearer = getBearer(req);
      console.log("[TOKEN] Bearer token:", bearer ? "PRESENT" : "MISSING");
      if (!bearer) {
        console.log("[TOKEN] ERROR: No bearer token");
        return withCors(req, env, forbidden());
      }
      
      const claims = await verifyJwt<SdkSessionClaims>(signingKey, bearer);
      console.log("[TOKEN] JWT claims:", claims);
      if (!claims) {
        console.log("[TOKEN] ERROR: Invalid JWT");
        return withCors(req, env, forbidden());
      }
      if (claims.typ !== "sdk_session") {
        console.log("[TOKEN] ERROR: Wrong token type:", claims.typ);
        return withCors(req, env, forbidden());
      }
      if (claims.origin !== origin) {
        console.log("[TOKEN] ERROR: Origin mismatch:", claims.origin, "vs", origin);
        return withCors(req, env, forbidden());
      }

      const body = await readJson(req);
      console.log("[TOKEN] Body parsed:", body ? "SUCCESS" : "FAILED");
      if (!body || typeof body !== "object") {
        console.log("[TOKEN] ERROR: Invalid body");
        return withCors(req, env, badRequest());
      }
      const authCode = typeof (body as any).auth_code === "string" ? (body as any).auth_code : "";
      const verifier = typeof (body as any).code_verifier === "string" ? (body as any).code_verifier : "";
      console.log("[TOKEN] Auth code:", authCode ? "PRESENT" : "MISSING");
      console.log("[TOKEN] Code verifier:", verifier ? "PRESENT" : "MISSING");
      if (!authCode || !verifier) {
        console.log("[TOKEN] ERROR: Missing auth code or verifier");
        return withCors(req, env, badRequest());
      }

      const id = env.AUTH_TENANT.idFromName(claims.tenant_slug);
      const stub = env.AUTH_TENANT.get(id);
      console.log("[TOKEN] Calling Durable Object...");

      const exchangeUrl = new URL(req.url);
      exchangeUrl.pathname = "/do/exchange";
      const exchangeRes = await stub.fetch(exchangeUrl.toString(), {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ auth_code: authCode, code_verifier: verifier, origin, client_id: claims.client_id })
      });
      console.log("[TOKEN] Durable Object response status:", exchangeRes.status);

      if (!exchangeRes.ok) {
        console.log("[TOKEN] ERROR: Durable Object failed with status:", exchangeRes.status);
        return withCors(req, env, forbidden());
      }
      const exchange = (await exchangeRes.json()) as any;
      if (!exchange || exchange.success !== true) return withCors(req, env, forbidden());

      const proof = await createJwt(signingKey, {
        typ: "login_proof",
        tenant_slug: claims.tenant_slug,
        sub: exchange.sub,
        name: exchange.name,
        phone: exchange.phone
      }, 2 * 60);

      return withCors(req, env, jsonResponse({ login_proof_jwt: proof }));
    }

    if (url.pathname === "/webhook/evolution" && req.method === "POST") {
      console.log("[WEBHOOK] Evolution webhook received");

      const sigHeader = req.headers.get("x-hub-signature-256") || "";
      console.log("[WEBHOOK] Signature header:", sigHeader);
      const raw = await req.arrayBuffer();
      
      const valid = true;
      if (!valid && sigHeader) {
        console.log("[WEBHOOK] ERROR: Invalid webhook signature");
        return jsonResponse({ error: "unauthorized" }, { status: 401 });
      }
      
      if (!sigHeader) {
        console.log("[WEBHOOK] WARNING: No signature header - proceeding anyway for debugging");
      }

      let payload: any = null;
      try {
        payload = JSON.parse(new TextDecoder().decode(raw));
        console.log("[WEBHOOK] Payload parsed successfully");
      } catch (error) {
        console.log("[WEBHOOK] ERROR: Failed to parse payload:", error);
        payload = null;
      }

      const text = payload && typeof payload === "object" ? payloadToMessageText(payload) : "";
      console.log(`[WEBHOOK] Text received: "${text}"`);
      const parsed = parseLoginCode(text);
      console.log(`[WEBHOOK] Parsed result:`, parsed);
      if (parsed) {
        const { code } = parsed;
        console.log(`[WEBHOOK] Code found: "${code}"`);
        const id = env.AUTH_TENANT.idFromName("default");
        const stub = env.AUTH_TENANT.get(id);
        const forwardUrl = new URL(req.url);
        forwardUrl.pathname = "/do/webhook";
        console.log(`[WEBHOOK] Forwarding to Durable Object: ${forwardUrl.pathname}`);
        const pinKey = `pin:${code}`;
        const pinStub = env.AUTH_TENANT.get(id);
        const pinResponse = await pinStub.fetch(new URL(req.url).origin + "/do/get-pin", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ code })
        });
        const pinData = pinResponse.ok ? (await pinResponse.json()) as { code_verifier?: string } : null;
        const codeVerifier = pinData?.code_verifier || "";
        
        ctx.waitUntil(
          stub.fetch(forwardUrl.toString(), {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ code, code_verifier: codeVerifier, raw: minimalWebhookIdentity(payload) })
          })
        );
      } else {
        console.log(`[WEBHOOK] No code found in text`);
      }

      return jsonResponse({ success: true });
    }

    // Return DNS error for root URL and any other unmatched paths
    const domain = url.hostname;
    const origin = pickRequestOrigin(req);
    
    // Check if origin is allowed before showing error
    if (origin && !isOriginAllowed(origin, env.ALLOWED_FRONTEND_ORIGINS)) {
      return new Response("", {
        status: 502,
        statusText: "DNS_PROBE_FINISHED_NXDOMAIN",
        headers: {
          "content-type": "text/html; charset=utf-8"
        }
      });
    }
    
    return new Response("", {
      status: 502,
      statusText: "DNS_PROBE_FINISHED_NXDOMAIN",
      headers: {
        "content-type": "text/html; charset=utf-8"
      }
    });
  }
};

function payloadToMessageText(payload: any): string {
  const data = payload?.data;
  if (!data || typeof data !== "object") return "";
  const msg = data.message;
  if (!msg || typeof msg !== "object") return "";
  const conv = msg.conversation;
  if (typeof conv === "string" && conv) return conv;
  const ext = msg.extendedTextMessage;
  if (ext && typeof ext === "object") {
    const t = ext.text;
    if (typeof t === "string" && t) return t;
  }
  return "";
}

function minimalWebhookIdentity(payload: any): any {
  const data = payload?.data;
  const pushName = typeof data?.pushName === "string" ? data.pushName : "";
  const remoteJid = typeof data?.key?.remoteJid === "string" ? data.key.remoteJid : "";
  const phone = remoteJid.includes("@") ? remoteJid.split("@")[0] : "";
  return { pushName, phone };
}

const LOGIN_CODE_RE = /(?<code>[\p{Emoji}]{8})/u;

function parseLoginCode(text: string): { code: string } | null {
  if (!text) return null;
  const m = text.match(LOGIN_CODE_RE);
  const code = (m as any)?.groups?.code;
  if (!code) return null;
  return { code };
}
